---
title: Letta 记忆系统完整流程总结
summary: 整合六个模块的学习内容，串联一次完整"用户发消息 → agent 处理 → 返回结果"过程中记忆系统的完整生命周期，涵盖三种记忆定位、静态结构、写入路径、压缩保护、端到端流程与五大设计原则
project: letta
tags: [letta, memory, core-memory, archival-memory, recall-memory, summarizer, tool-routing, end-to-end]
created: 2026-07-04
updated: 2026-07-04
status: completed
confidence: high
---

# ⭐ Letta 记忆系统完整流程总结

> 整合六个模块的学习内容，串联成一次完整"用户发消息 → agent 处理 → 返回结果"过程中记忆系统的完整生命周期。所有细节均已对照 letta-ai/letta 主分支源码核实。

---

## 一、总览：三种记忆的定位

| 记忆类型                | 本质             | 存储位置                             | 进入 LLM 上下文的方式                                         | 生命周期                                  |
| ------------------- | -------------- | -------------------------------- | ----------------------------------------------------- | ------------------------------------- |
| **Core Memory**     | 少量、结构化、恒定可见的状态 | `Block` 对象，持久化到关系型 DB            | 直接编译进 system message，**每次请求必带**                       | 手动/工具修改，除非被删除否则永久存在                   |
| **Archival Memory** | 海量、按需检索的外部知识库  | 向量数据库（pgvector 或 turbopuffer）    | LLM 主动调用 `archival_memory_search` 后，以**工具返回消息**形式临时出现 | 检索结果随对话推进被 summarizer 自然淘汰；原始数据永久存在库里 |
| **Recall Memory**   | 完整对话历史的可搜索索引   | 消息表（message history），向量+FTS 混合索引 | LLM 主动调用 `conversation_search` 后，以**工具返回消息**形式临时出现    | 同上，检索结果是临时的，原始消息受 summarizer 管理       |

一句话区分：**Core Memory 是"agent 的人格与用户画像"，必须每次都在场；Archival/Recall 是"agent 的图书馆和日记本"，需要的时候才去翻。**

---

## 二、静态结构：数据怎么组织

### 2.1 Core Memory 的数据结构（模块一）

- 最小单元是 `Block`（`letta/schemas/block.py`），核心字段：`label`（如 `persona`/`human`）、`value`（文本内容）、`limit`（字符上限）、`read_only`。
- `Memory` 类（`letta/schemas/memory.py`）持有一组 `blocks` + `file_blocks`，提供 `get_block()`/`set_block()`/`update_block_value()` 等操作接口。
- **渲染方式有三种分支**，由 `compile()` 统一调度：
  - **standard**：`<label>...</label>` 形式的 XML 块，附带 `chars_current`/`chars_limit`（暴露给 LLM 让它感知自己还能写多少）。
  - **line-numbered**：每行带 `N→` 行号前缀，配合按行号定位编辑的工具（`memory_replace`/`memory_insert`）使用。
  - **git-enabled**（`git_enabled=True`）：只渲染 `label` 以 `system/` 开头的 block，渲染时去掉前缀——是一种带命名空间的标签机制，不是真正的版本控制。
- 选哪种渲染分支，由 `agent_type` + 是否 Anthropic 模型共同决定（`is_line_numbered` 判断逻辑）。
- `ChatMemory`/`BasicBlockMemory` 是默认的 persona+human 两块结构的封装。

### 2.2 Archival Memory 的数据结构（模块三）

- 最小单元是 `Passage`（`letta/schemas/passage.py`），字段：`text`、`embedding`、`embedding_config`、`tags`、`archive_id`。
- 向量后端有两种：**pgvector**（默认）和 **turbopuffer**（`should_use_tpuf()` 判断走哪个）。
- Embedding 在**写入时（insert）生成**，不是搜索时才生成（`get_openai_embedding_async`，带 `@async_redis_cache` 缓存）。
- padding 逻辑（对齐到 `MAX_EMBEDDING_DIM`）只在**使用 pgvector 且（是 archival 或是非-turbopuffer 的 file）**时触发——这是为了让不同维度的 embedding 能存进同一张定长的向量列。

### 2.3 Recall Memory 的数据结构（模块四）

- 就是完整的 `Message` 表（`letta/schemas/message.py`，2710 行的大文件，实际只需定位到 `Message` 主类）。
- 检索支持四种模式：`vector`/`fts`/`hybrid`/`timestamp`，`hybrid` 模式用 **RRF（Reciprocal Rank Fusion）** 融合向量排名和全文检索排名，得到 `vector_rank`、`fts_rank`、`rrf_score`。
- 有 agent 级别（`search_messages_async`）和组织级别（`search_messages_org_async`）两种检索范围。
- 检索结果里会**过滤掉 tool 消息**，避免递归嵌套问题（工具调用/返回本身也是消息，若不过滤会污染搜索相关性）。

---

## 三、写入路径：内存怎么被修改（模块二）

Core Memory 的修改必须通过工具，工具体系分两层：

1. **`letta/functions/function_sets/base.py`**：LLM 看到的函数签名 + docstring，这是"接口层"，只是让模型知道有哪些工具、参数是什么。
2. **`letta/services/tool_executor/core_tool_executor.py`**：真正的执行逻辑，通过 `function_map` 路由表把工具名映射到具体方法。

工具集本身按**版本**分层，创建 agent 时根据 `agent_type` 二选一挂载（源码 `agent_manager.py`）：

| 版本 | 包含工具 | 对应场景 |
|------|---------|---------|
| **V1**（`BASE_MEMORY_TOOLS`） | `core_memory_append`、`core_memory_replace`、`memory`、`memory_apply_patch` | 默认 agent 类型 |
| **V2**（`BASE_MEMORY_TOOLS_V2`） | `memory_replace`、`memory_insert` | `memgpt_v2_agent`、`letta_v1_agent`，配合行号渲染的 prompt |
| **V3**（`BASE_MEMORY_TOOLS_V3`） | 只有一个万能工具 `memory` | 目前主要给 Anthropic 模型准备，暂无自动挂载路径，需手动指定 |
| **独立 sleeptime 集合**（`BASE_SLEEPTIME_TOOLS`） | `memory_replace`、`memory_insert`、`memory_rethink`、`memory_finish_edits` | 专供 sleeptime agent（后台整理内存的角色） |

此外还有一套**按字符串定位**而非按行号定位的编辑工具：`memory_str_replace`/`memory_str_insert`，跟 `memory_replace`/`memory_insert` 是平行的两套接口，服务于不同的工具集组合。

Block 的创建/删除是 **attach/detach**（`memory_create`/`memory_delete`/`memory_rename`/`memory_update_description`），不是简单的增删——因为 Block 可能被多个 agent 共享，所以操作的是"关联关系"而不是直接销毁数据本身。

**Archival/Recall 的写入路径不同**：`archival_memory_insert` 是显式工具调用，调用 `passage_manager.insert_passage` 写入向量库后，会主动触发 `rebuild_system_prompt_async(force=True)`（因为 archival 数量变化会影响 system message 里展示的 `archival_memory_size` 统计信息，即使内容本身不进 system message）。Recall Memory 则完全被动——只要普通对话消息产生，就自动进入消息表，不需要专门的"写入"工具。

---

## 四、上下文压缩时的保护机制（模块五）

当对话历史超过 token 预算，`Summarizer`（`letta/services/summarizer/summarizer.py`）会触发压缩：

- `SummarizationMode` 定义压缩模式。
- 触发条件、`message_buffer_limit`（保留多少条不压缩）在 `Summarizer.__init__`/`summarize()` 里定义。
- 实际压缩逻辑在 `compact.py`：把旧消息折叠成一条 summary 消息，保留最近若干条原始消息不动。

**关键点：Core Memory blocks 完全不受 summarizer 影响**——因为它根本不在 `in_context_messages` 里，而是单独存在 `agent_state.memory` 里，每次通过 `_rebuild_memory_async` 编译进 system message 的第一条消息。summarizer 压缩的是普通对话消息（用户说的话、LLM 的回复、工具调用/返回），system message 永远保持完整，不会被折叠。这就是"记忆保留机制"的核心——**Core Memory 靠"结构上不参与压缩"来保证持久性，而不是靠某种豁免规则。**

---

## 五、端到端完整流程（模块六：串联全部）

下面用一次完整的用户交互，把六个模块串起来。

### 场景

Xavier 发消息："帮我查一下我之前提到过的关于负荷预测的笔记，另外记住我现在换到对冲基金工作了。"

### 流程

**第 1 步：请求进入，Agent 开始 step 循环**

`LettaAgent`（继承自 `BaseAgent`）拿到用户消息，进入主循环。**第一次要发起 LLM 请求之前**，`_create_llm_request_data_async` 被调用，触发**第 1 次 `_rebuild_memory_async`**：

- 刷新 `agent_state.memory.blocks`（从 DB 拉最新的）。
- 编译 `curr_memory_str = agent_state.memory.compile(...)`。
- 用子串检查 `memory_changed = curr_memory_str not in curr_system_message_text` 快速判断——这时候内存还没被本轮对话修改，判定"没变化"，直接返回原 `in_context_messages`，零数据库写入。

**第 2 步：LLM 决定调用工具**

模型看到用户请求里有两个意图：①检索历史笔记 → 应该调用 `archival_memory_search`（或 `conversation_search`，取决于笔记存在哪）；②更新用户状态 → 应该调用内存修改工具（`memory_replace` 或 `core_memory_replace`，取决于该 agent 挂的是 V1 还是 V2 工具集）。

假设模型先选择调用 `archival_memory_search`。

**第 3 步：工具路由与执行**

- Step 循环层先检查该工具是否命中 `ToolRulesSolver` 定的规则、是否需要审批。假设不需要审批，直接放行。
- `execute_tool_async` 根据 `tool.tool_type`（`LETTA_CORE`）从工厂拿到 `LettaCoreToolExecutor`，调用其 `archival_memory_search` 实现。
- 该实现委托给 `agent_manager.search_agent_archival_memory_async`，带上 `tags`/`tag_match_mode`/`top_k` 等参数，去 pgvector（或 turbopuffer）里做向量检索。
- 检索结果（Passage 的 text 内容）打包成一条 **tool 返回消息**，追加进 `in_context_messages`——注意：**这一步完全不碰 Core Memory blocks**，只是普通对话历史多了一条消息。

**第 4 步：流程未结束，进入下一轮循环**

因为还要针对检索结果 + 用户的第二个意图（记住换工作）继续处理，agent 没有立即结束这个 step。进入下一轮，再次要发起 LLM 请求之前，触发**第 2 次 `_rebuild_memory_async`**——因为上一步 archival 检索没有修改 Core Memory，这次判断结果依然是"没变化"，继续走快速跳过路径。

**第 5 步：LLM 调用内存修改工具**

模型这次决定调用 `memory_replace`（假设该 agent 挂的是 V2 工具集），把 human block 里 "Xavier works on time series forecasting" 替换成 "Xavier switched jobs to a hedge fund"。

- 同样经过审批检查（内存修改工具通常不需要审批，除非管理员特意配置了）→ `execute_tool_async` 路由到 `LettaCoreToolExecutor.memory_replace` → 实际调用 `block_manager` 更新数据库里对应 Block 的 `value` 字段。
- 工具返回一条成功消息，追加进对话历史。

**第 6 步：本轮最后一次 LLM 调用前，触发第 3 次 `_rebuild_memory_async`**

这次不一样了：

1. 刷新 `agent_state.memory.blocks`——human block 的 `value` 已经变成新内容。
2. 重新编译 `curr_memory_str`，因为内容变了，编译出的整段字符串跟旧 system message 里存的那段**逐字符不同**。
3. `memory_changed = True`，触发重建：
   - 计算 `num_messages`（对话总消息数）、`num_archival_memories`（archival 总条数，此时可能因为之前的 insert 操作而增加过）。
   - 调用 `PromptGenerator.get_system_message_from_compiled_memory(...)`，把新内存文本、时间戳、`previous_message_count`、`archival_memory_size`、`archive_tags` 等拼成完整新 system message。
   - `united_diff` 精确比对新旧文本，确认真的有差异。
   - `message_manager.update_message_by_id_async` 把新内容写回数据库里 system message 那条记录。
   - 返回 `[new_system_message, *in_context_messages[1:]]`，替换掉列表第一条。

**第 7 步：LLM 生成最终回复**

这时候 LLM 拿到的 system message 里，human block 已经是"换到对冲基金"的最新版本，同时对话历史里带着刚才检索到的负荷预测笔记内容和内存修改成功的确认消息。模型据此生成回复，调用 `send_message` 结束这一 step。

**第 8 步：整个用户轮次结束后的后台维护**

如果这一轮加上历史消息的总 token 数超过了阈值，`Summarizer` 会在合适的时机把较早的对话消息折叠成 summary，但**刚更新的 system message 不受影响**——它本来就不在 `in_context_messages` 的压缩范围里，是通过 `_rebuild_memory_async` 独立维护的"第 0 条特殊消息"。

---

## 六、贯穿全流程的关键设计原则

1. **"恒定状态"与"按需检索"分离**：Core Memory 追求"永远同步、永远在场"，Archival/Recall 追求"体量可以无限增长、但只在被主动检索时才短暂出现"。这个分离是整个记忆系统设计的根基。

2. **写路径与读路径解耦**：Archival 在 `insert` 时就生成 embedding（写时计算），检索时直接做向量运算，不需要临时生成；Core Memory 修改后不会立刻侵入 system message，而是等到下一次真正要发起 LLM 请求时才统一检查、按需重建——都是"提前做好准备工作，避免在高频路径上做重活"的思路。

3. **轻量检查 + 精确校验的两级判断**：`_rebuild_memory_async` 内部先用廉价的子串包含检查做粗筛，只有怀疑"可能变了"才会走计算量更大的 `united_diff` 精确比对，最后才落库——层层递进，避免在没有变化的绝大多数请求里浪费开销。

4. **工具即接口，版本化演进**：记忆的读写能力全部通过"工具"暴露给 LLM，而工具集合本身按 agent 类型（v1/v2/v3 + sleeptime 专用）分层演进，允许不同 prompt 版本、不同模型厂商使用不同的最优交互方式，而不用推倒重来。

5. **压缩机制默认不碰 Core Memory**：这不是靠"额外加一条排除规则"实现的，而是从数据结构上——Core Memory 从来就不在 `in_context_messages` 序列里，它是被单独管理、单独重建的"系统消息前缀"，天然免疫于对话历史的压缩逻辑。
---
title: GPT-Researcher Agent 入口全面分析
created: 2026-06-17
updated: 2026-06-18
type: analysis
tags: [gpt-researcher, agent, architecture, conduct_research, deep-research, image-generator, mcp]
sources: [gpt_researcher/agent.py, gpt_researcher/skills/researcher.py, gpt_researcher/skills/writer.py, gpt_researcher/skills/deep_research.py, gpt_researcher/skills/image_generator.py, gpt_researcher/context/compression.py, gpt_researcher/skills/context_manager.py]
project: gpt-researcher
confidence: high
---

# GPT-Researcher Agent 入口全面分析

> [!info] 源码定位
> 基于 `D:\timeModel\gpt-researcher\gpt_researcher\agent.py` (741 行) 源码的逐行分析。

## 1. 类的定位与职责

`GPTResearcher` 是整个项目的**唯一公共入口类**。所有上层调用（CLI、FastAPI Server、DeepResearch 后端、BasicReport 后端、DetailedReport 后端）最终都通过实例化这个类并调用其异步方法来完成工作。

它的核心职责是**编排**——不自己干任何活，而是协调下面 6 个 Skill 组件：

```
GPTResearcher (agent.py, 741行) ← 编排者
  ├── ResearchConductor    (skills/researcher.py, 1013行)  → 研究执行
  ├── ReportGenerator      (skills/writer.py, 254行)       → 报告撰写
  ├── ContextManager       (skills/context_manager.py, 154行) → 上下文管理与压缩
  ├── BrowserManager       (skills/browser.py)              → 网页抓取
  ├── SourceCurator        (skills/curator.py, 96行)        → 来源质量评估
  ├── DeepResearchSkill    (skills/deep_research.py, 600行) → 深度递归研究
  └── ImageGenerator       (skills/image_generator.py)      → 图片预生成
```

此外还依赖：
- `Config` (config.py) — 配置管理
- `Memory` (memory.py) — 向量记忆/嵌入
- `GenericLLMProvider` (llm_provider.py) — LLM 调用封装
- `VectorStoreWrapper` (vector_store.py) — 向量库适配

## 2. 构造函数 __init__ 全解析

### 2.1 初始化参数分类

| 类别           | 参数                                                                                                                            | 说明                     |
| ------------ | ----------------------------------------------------------------------------------------------------------------------------- | ---------------------- |
| **必传**       | `query`                                                                                                                       | 研究问题                   |
| **报告控制**     | `report_type`, `report_format`, `report_source`, `tone`                                                                       | 决定走什么流程                |
| **数据源**      | `source_urls`, `document_urls`, `documents`, `vector_store`, `vector_store_filter`, `complement_source_urls`, `query_domains` | 指定从哪获取信息               |
| **Agent 预设** | `agent`, `role`, `parent_query`, `subtopics`, `visited_urls`                                                                  | 子报告传入，跳过自动选择           |
| **通信**       | `websocket`, `log_handler`, `headers`                                                                                         | WebSocket 推送、日志、HTTP 头 |
| **MCP**      | `mcp_configs`, `mcp_max_iterations`(废弃), `mcp_strategy`                                                                       | MCP 服务器配置              |
| **其他**       | `verbose`, `context`, `max_subtopics`, `prompt_family`, `**kwargs`                                                            | 杂项                     |

### 2.2 关键初始化逻辑

**1) 配置加载与 Prompt 家族选择** (line 140-168)
```python
self.cfg = Config(config_path)
self.prompt_family = get_prompt_family(prompt_family or self.cfg.prompt_family, self.cfg)
```
Prompt family 决定了整个系统的提示词模板风格。

**2) MCP 配置处理** (line 170-174, 284-311)
- 传入 `mcp_configs` 后调用 `_process_mcp_configs()`
- 将 `"mcp"` 追加到 `self.cfg.retrievers` 列表
- **刻意不修改 `os.environ`**，避免进程级环境变量污染（修复 issue #1676）

**3) Retriever 注册** (line 176)
```python
self.retrievers = get_retrievers(self.headers, self.cfg)
```
根据 `cfg.retrievers` 配置实例化对应的搜索引擎/检索器。

**4) 记忆与嵌入** (line 177-179)
```python
self.memory = Memory(
    self.cfg.embedding_provider, self.cfg.embedding_model, **self.cfg.embedding_kwargs
)
```
用于向量相似度搜索和上下文压缩。

**5) 编码处理** (line 181-183)
```python
self.encoding = kwargs.get('encoding', 'utf-8')
self.kwargs.pop('encoding', None)
```
把 `encoding` 从 kwargs 中移除，避免传给 LLM API 导致报错。

**6) Skill 组件实例化** (line 186-198)
- `ResearchConductor(self)` — 研究执行器
- `ReportGenerator(self)` — 报告生成器
- `ContextManager(self)` — 上下文管理器
- `BrowserManager(self)` — 浏览器管理器
- `SourceCurator(self)` — 来源策展人
- `DeepResearchSkill(self)` — 仅当 `report_type == DeepResearch` 时实例化
- `ImageGenerator(self)` — 图片生成器（可选）

### 2.3 MCP 策略解析器 `_resolve_mcp_strategy()` (line 217-282)

四级优先级，支持新旧名称兼容：

```
优先级 1: 参数 mcp_strategy  ("fast"/"deep"/"disabled")
  - 旧名 "optimized" → 警告 + "fast"
  - 旧名 "comprehensive" → 警告 + "deep"

优先级 2: 参数 mcp_max_iterations (废弃兼容)
  - 0 → "disabled"
  - 1 → "fast"
  - -1 → "deep"

优先级 3: 配置文件 cfg.mcp_strategy

优先级 4: 默认 "fast"
```

## 3. 核心方法：conduct_research() — 研究流程总调度

### 3.1 完整流程图

```
conduct_research(on_progress=None)
    │
    ├─ [日志] step=start: 记录 query, report_type, agent, role
    │
    ├─ 分支1: report_type == DeepResearch ?
    │     └─ YES → _handle_deep_research(on_progress) → 返回 context
    │     └─ NO  → 继续
    │
    ├─ 分支2: agent 和 role 未预设 ?
    │     └─ YES → choose_agent(query, ...) → 自动选择 agent + role
    │     └─ NO  → 跳过（子报告由父报告传入）
    │
    ├─ 分支3: 执行研究
    │     └─ self.research_conductor.conduct_research()
    │         → 内部调用 _get_context_by_urls / _get_context_by_vectorstore / _get_context_by_web_search
    │         → 返回 self.context (list of strings)
    │
    ├─ [日志] step=research_completed: 记录 context 长度
    │
    ├─ 分支4: 图片预生成（新增功能）
    │     └─ image_generator.is_enabled()?
    │         └─ YES → plan_and_generate_images(context, query, research_id)
    │             → 生成 self.available_images (list of image dicts)
    │         └─ NO  → 跳过
    │
    └─ 返回 self.context
```

### 3.2 两个关键分支

**分支1: Deep Research vs 普通研究**

`conduct_research()` 本身是统一入口。当 `report_type == "deep_research"` 时，直接委托给 `_handle_deep_research()`，后者调用 `self.deep_researcher.run()` 执行树形递归搜索。

这意味着：
- **普通报告**走 `research_conductor.conduct_research()`（6个子查询并发）
- **深度报告**走 `deep_researcher.run()`（breadth×depth 递归树）

**分支2: Agent 自动选择 vs 预设**

当 `agent` 和 `role` 都已预设时（子报告场景），跳过 `choose_agent()` 调用，节省一次 LLM 请求。

### 3.3 图片预生成逻辑 (line 388-401)

这是一个**新增功能**，在研究完成后、报告生成前执行：

```python
self.available_images = []
if self.image_generator and self.image_generator.is_enabled():
    context_str = "\n\n".join(self.context) if isinstance(self.context, list) else str(self.context)
    self.available_images = await self.image_generator.plan_and_generate_images(
        context=context_str,
        query=self.query,
        research_id=self._generate_research_id(),
    )
```

关键点：
- 发生在 `conduct_research()` 末尾，`write_report()` 之前
- 将 context 列表拼接为字符串供图片分析
- 生成的图片在 `write_report()` 时被嵌入到报告中

### 3.4 conduct_research() 是否被 research 替代？

**没有被替代，它仍然是核心入口。** 从调用链看：

| 调用方 | 调用方式 | 说明 |
|--------|----------|------|
| `basic_report.py:73` | `await self.gpt_researcher.conduct_research()` | 基础报告 |
| `detailed_report.py:94,165` | `await researcher.conduct_research()` | 详细报告（主报告+子报告） |
| `deep_research/main.py:23` | `await researcher.conduct_research(on_progress=on_progress)` | DeepResearch 后端 |
| `cli.py:315` | `await researcher.conduct_research()` | CLI 入口 |
| `server_utils.py:98` | `await self.researcher.conduct_research()` | FastAPI Server |
| `evals/hallucination_eval/run_eval.py:88` | `await researcher.conduct_research()` | 评测 |
| `evals/simple_evals/run_eval.py:43` | `await researcher.conduct_research()` | 评测 |

`conduct_research()` 是**对外暴露的统一接口**，内部再根据 `report_type` 分发到不同路径。不存在"被替代"的情况。

## 4. 报告生成方法群

### 4.1 write_report() (line 453-494)

```
write_report(existing_headers=[], relevant_written_contents=[], ext_context=None, custom_prompt="")
    │
    ├─ 使用 conduct_research() 预生成的 self.available_images
    ├─ 调用 self.report_generator.write_report(...)
    │   → 传入 existing_headers (避免子主题重复)
    │   → 传入 relevant_written_contents (WrittenContentCompressor 去重)
    │   → 传入 ext_context or self.context (上下文来源)
    │   → 传入 custom_prompt (自定义提示词)
    │   → 传入 available_images (预生成图片)
    └─ 返回 Markdown 报告字符串
```

`ext_context` 参数允许外部传入上下文（子报告场景），否则使用 `self.context`。

### 4.2 write_report_conclusion() (line 496-508)

委托给 `report_generator.write_report_conclusion(report_body)`。

### 4.3 write_introduction() (line 510-519)

委托给 `report_generator.write_introduction()`。

### 4.4 get_subtopics() (line 555-561)

```python
return await self.report_generator.get_subtopics()
```
LLM 根据主查询自动生成子主题列表，用于 DetailedReport 的多段式写作。

### 4.5 get_draft_section_titles() (line 563-572)

```python
return await self.report_generator.get_draft_section_titles(current_subtopic)
```
为某个子主题生成草稿章节标题。

### 4.6 get_similar_written_contents_by_draft_section_titles() (line 574-597)

```python
return await self.context_manager.get_similar_written_contents_by_draft_section_titles(
    current_subtopic, draft_section_titles, written_contents, max_results
)
```
**去重机制**：在写子报告时，查找之前已写过的相似内容，避免不同子主题间重复。这是 `WrittenContentCompressor` 的入口点，详见 [[已写内容相似度检索（WrittenContentCompressor）]]。

## 5. 快捷方法：quick_search() (line 521-553)

不经过完整研究流程，直接执行单次搜索：

```
quick_search(query, query_domains=None, aggregated_summary=False)
    │
    ├─ get_search_results(query, self.retrievers[0], query_domains)
    │
    ├─ aggregated_summary=False → 返回原始搜索结果列表
    │
    └─ aggregated_summary=True → LLM 综合摘要
        ├─ 格式化结果为 [1] title: content (url) 格式
        ├─ prompt_family.generate_quick_summary_prompt(query, context)
        └─ create_chat_completion(model=smart_llm_model, ...)
```

用途：快速回答简单问题，或作为 Deep Research 中 `generate_research_plan()` 的初步调研。

## 6. 辅助方法

### 6.1 研究 ID 生成 `_generate_research_id()` (line 203-215)

```python
unique_str = f"{self.query}_{time.time()}"
self._research_id = f"research_{hashlib.md5(unique_str.encode()).hexdigest()[:12]}"
```
基于 query + 时间戳的 MD5 截断，用于图片生成的命名空间隔离。

### 6.2 日志系统 `_log_event()` (line 313-331)

三种事件类型：
- `tool` → `log_handler.on_tool_start()`
- `action` → `log_handler.on_agent_action()`
- `research` → `log_handler.on_research_step()`

同时有 backup 日志：`logging.getLogger('research').info/error`。

### 6.3 成本管理 `add_costs()` (line 720-741)

```python
self.research_costs += cost
self.step_costs[self._current_step] += cost
```
按当前 step 分账统计，支持 `get_costs()` 和 `get_step_costs()` 查询。

### 6.4 数据访问器

| 方法 | 返回 | 说明 |
|------|------|------|
| `get_research_images(top_k=10)` | `list[dict]` | 研究过程中收集的图片 |
| `add_research_images(images)` | `None` | 添加图片 |
| `get_research_sources()` | `list[dict]` | 所有抓取的来源（title+content+images） |
| `add_research_sources(sources)` | `None` | 添加来源 |
| `get_source_urls()` | `list[str]` | 所有访问过的 URL |
| `get_research_context()` | `list` | 累积的研究上下文 |
| `get_step_costs()` | `dict[str, float]` | 各步骤成本 |

### 6.5 文本处理工具

| 方法 | 功能 |
|------|------|
| `add_references(report_markdown, visited_urls)` | 添加参考文献部分 |
| `extract_headers(markdown_text)` | 提取 Markdown 标题 |
| `extract_sections(markdown_text)` | 提取 Markdown 段落 |
| `table_of_contents(markdown_text)` | 生成目录 |

## 7. 数据流总结

```
GPTResearcher.__init__()
    │
    ├─ 构建 retrievers (搜索引擎)
    ├─ 构建 memory (向量嵌入)
    ├─ 构建 6 个 Skill 组件
    └─ 解析 MCP 策略
    │
    ├─ conduct_research()          → 填充 self.context
    │     ├─ 选 Agent (如未预设)
    │     ├─ ResearchConductor 执行研究
    │     └─ ImageGenerator 预生成图片
    │
    ├─ write_report()              → 生成主报告/子报告
    │     └─ ReportGenerator 写入，嵌入 pre-generated images
    │
    ├─ write_introduction()        → 生成引言
    ├─ write_report_conclusion()   → 生成结论
    └─ get_subtopics()             → 生成子主题列表
```

## 8. 设计模式与架构特点

### 8.1 Skill 模式

每个 Skill 是一个独立的 class，持有对父 `GPTResearcher` 的引用 (`self.researcher`)，通过它访问配置、retrievers、memory 等共享资源。这是一种**组合优于继承**的设计——没有复杂的继承链，每个 Skill 职责单一。

### 8.2 委托而非实现

`agent.py` 本身**不执行任何具体研究逻辑**。所有实质工作委托给 Skill 组件：
- 研究 → `research_conductor.conduct_research()`
- 写作 → `report_generator.write_report()`
- 上下文压缩 → `context_manager.get_similar_written_contents_by_draft_section_titles()`

### 8.3 状态集中管理

所有中间状态都在 `GPTResearcher` 实例上：
- `self.context` — 研究上下文
- `self.visited_urls` — 已访问 URL
- `self.research_sources` — 抓取来源
- `self.research_images` — 收集图片
- `self.research_costs` / `self.step_costs` — 成本
- `self.agent` / `self.role` — 选择的 Agent

### 8.4 向后兼容设计

- MCP 策略支持新旧两种命名（`optimized`/`comprehensive` → `fast`/`deep`）
- `mcp_max_iterations` 参数仍可用但发警告
- `encoding` 从 kwargs 中剥离避免 LLM API 报错
- 子报告通过预设 `agent`+`role`+`subtopics` 复用父报告配置

## 9. 代码质量问题

| 问题 | 位置 | 说明 |
|------|------|------|
| 注释语言混用 | line 173, 268, 300 | `_process_mcp_configs` 中有中文注释，建议统一 |
| 冗余注释 | line 360-361, 370 | `filtered_kwargs` 被注释掉但保留，应清理 |
| 重复导入 | line 325, 330 | `_log_event` 中每次都 `import logging`，应移到文件顶部 |
| 类型不一致 | researcher.py:236,269 | `_get_context_by_vectorstore` 返回 tuple，`_get_context_by_web_search` 返回 str 或 list |
| 缺少错误处理 | curator.py:74 | `curate_sources` 直接 `json.loads(LLM响应)`，无 try/except |
| 硬编码阈值 | compression.py:159 | 8000字符跳过压缩硬编码在环境变量，无文档说明 |
| 日志打印 | curator.py:49 | 直接 `print` 大列表到 stdout，生产环境可能干扰日志 |

## 10. 与其他笔记的关系

- [[ResearchConductor 深度分析]] — `conduct_research()` 的核心委托对象
- [[已写内容相似度检索（WrittenContentCompressor）]] — `get_similar_written_contents_by_draft_section_titles()` 的实现
- [[GPT-Researcher 核心架构笔记]] — 全局架构概览（本笔记是其 agent.py 部分的深化）
- [[Phase 1 进度记录]] — 学习进度追踪

---
title: GPT-Researcher 核心架构笔记
created: 2026-06-13
updated: 2026-06-18
type: concept
tags: [gpt-researcher, architecture, agent, scraper, context, mcp, deep-research, research-conductor]
sources: [GPT-Researcher源码, gpt_researcher/agent.py, gpt_researcher/skills/researcher.py, gpt_researcher/actions/query_processing.py, gpt_researcher/retrievers/mcp/retriever.py]
project: gpt-researcher
confidence: high
up: "[[GPT-Researcher + MemGPT 学习计划]]"
---

# GPT-Researcher 核心架构笔记

> [!info] 分析基础
> 基于 `D:\timeModel\gpt-researcher\` 源码的完整架构分析，标注了代码位置和发现的问题。

---

## 整体架构概览

```
GPTResearcher (agent.py) 核心入口
  ├── ResearchConductor (skills/researcher.py, 1013行)    → 研究协调器
  ├── ReportGenerator (skills/writer.py, 254行)           → 报告生成器
  ├── ContextManager (skills/context_manager.py, 154行)   → 上下文管理器
  ├── BrowserManager/ScraperManager (skills/browser.py)   → 浏览器管理器
  ├── SourceCurator (skills/curator.py, 96行)             → 来源策展
  ├── DeepResearchSkill (skills/deep_research.py, 600行)  → 深度研究
  └── ImageGenerator (skills/image_generator.py)          → 图片生成
```

> [!note]- 深入阅读
> 架构概览的详细分析见 [[GPT-Researcher Agent 入口全面分析]]（agent.py 逐行解析），本笔记聚焦整体架构和各模块关系。

## 完整研究流程

```
用户输入问题
    ↓
[report_type=DeepResearch] → DeepResearchSkill.run()
  - 生成研究计划(追问问题)
  - 递归深度研究: breadth × depth 树形搜索
  - 每层: 生成搜索词 → 并发研究 → 提取learnings → 递归深入
    ↓
[report_type=ResearchReport/DetailedReport]
    ↓
Agent选择 → choose_agent() 选角色和专业领域
    ↓
上下文获取 (三选一+组合):
  1) _get_context_by_urls()      → 指定URL抓取
  2) _get_context_by_vectorstore() → 本地向量库检索
  3) _get_context_by_web_search()  → 网络搜索(最复杂)
  4) source_urls + complement_source_urls → URL+网络补充
  5) report_source=Local/Hybrid/Azure/LangChainDocuments/VectorStore
    ↓
Source Curator (可选) → LLM评估来源质量
    ↓
图片预生成 (可选) → plan_and_generate_images()
    ↓
报告生成 → ReportGenerator.write_report()
    ↓
附加引言/结论/目录/参考文献
```

---

## 模块详解

### 1. Scraper 模块

**文件**: `scraper/scraper.py` (214行)

职责: 只做一件事，给定 URL 列表，把页面内容取回来。

```
Scraper.__init__()      URL去重(dict.fromkeys保序)
    ↓
run()                   asyncio.gather并发抓取所有URL
    ↓
extract_data_from_url() 单个URL抓取，过滤短内容(<100字符)
    ↓
get_scraper()           根据链接类型选后端
                        .pdf      → PyMuPDFScraper
                        arxiv.org → ArxivScraper
                        其他      → 用户配置的后端
```

返回格式: `{ url, raw_content, image_urls, title }`

### 2. Context 获取模块

**⚠️ 实际位置**: `skills/researcher.py` → ResearchConductor 类（不是 context/ 目录）

三种来源，对应三个方法:

```
_get_context_by_urls()          指定URL抓取(line 216)
_get_context_by_vectorstore()   本地向量库检索(line 236)
_get_context_by_web_search()    网络搜索(最复杂,line 269)
```

#### `_get_context_by_web_search()` 内部流程

```
原始 query
    ↓
MCP策略处理(fast/deep/disabled)
    ↓
plan_research() 拆分子查询(line 334)
    ↓
asyncio.gather并发处理所有子查询(line 353-358)
    ↓
每个子查询: _process_sub_query()
    ├→ MCP: fast用缓存 / deep逐个执行 / disabled跳过
    ├→ 网络搜索: _scrape_data_by_urls()
    ├→ 向量相似度匹配: get_similar_content_by_query()
    └→ 合并MCP+Web结果
    ↓
过滤空结果 → " ".join(context) 合并为字符串返回
```

#### `_get_context_by_urls()` 补充

**`complement_source_urls` 开关**: 开启后在指定 URL 内容基础上，额外做一次网络搜索补充，实现"私有资料 + 公开网络"结合。

#### 子查询处理 `_process_sub_query()`

```
识别MCP retrievers vs 非MCP retrievers
    ↓
MCP处理:
  fast且缓存可用 → 直接用缓存
  deep           → 每个子查询都执行
  disabled       → 跳过
    ↓
网络搜索: _scrape_data_by_urls() → _search_relevant_source_urls() → browse_urls()
    ↓
向量相似度: get_similar_content_by_query(sub_query, scraped_data)
    ↓
_combine_mcp_and_web_context() → Web上下文在前，MCP在后，带引用格式
```

#### `_get_context_by_vectorstore()` 返回类型

返回 `asyncio.gather(...)` 的结果，技术上是 **tuple**（非 list）。

### 3. MCP 检索模块

**位置**: 嵌套在 `_get_context_by_web_search()` 内部

#### 三种策略

```
disabled  →  跳过MCP，只走普通网络搜索(line 290)
fast      →  只用原始query执行一次，结果缓存复用(line 300，默认值)
deep      →  每个子查询都单独执行，更全面但更慢(line 315)
```

配置优先级（`_get_mcp_strategy()` line 371）:
1. 实例级 `self.researcher.mcp_strategy`
2. 配置文件 `self.researcher.cfg.mcp_strategy`
3. 默认值 `"fast"`

#### MCP 调用链（9层调用，8次跳转）

```
_get_context_by_web_search()                    skills/researcher.py:269
    ↓ line 312
_execute_mcp_research_for_queries()             skills/researcher.py:397
    ↓ line 415（双层循环: query × retriever）
_execute_mcp_research()                         skills/researcher.py:584
    ↓ line 619
search()                                        retrievers/mcp/retriever.py:201
    ↓ line 239（开新线程处理async/sync边界）
search_async()                                  retrievers/mcp/retriever.py:116
    ↓ line 139
_get_all_tools()                                retrievers/mcp/retriever.py:300
    ↓ line 311 → client_manager.get_all_tools()
tool_selector.select_relevant_tools()           retrievers/mcp/retriever.py:147
    ↓（实现位于 mcp/tool_selector.py:35，LLM选出最相关工具，最多3个）
conduct_research_with_tools()                   retrievers/mcp/retriever.py:155
    ↓（实现位于 mcp/research.py:34，LLM绑定工具自主检索）
_process_tool_result()                          mcp/research.py:158
```

**关键设计**:
- `search()` 是同步接口（GPT-Researcher要求），内部开新线程运行 `search_async()`
- `_get_all_tools()` 有缓存（`_all_tools_cache`），避免重复获取工具清单
- Tool Selector 用 LLM 从所有 MCP 工具中选出最多 3 个最相关的
- "两阶段"指的是 MCP 内部: 阶段1=选工具, 阶段2=用工具研究（实际有3个步骤）

### 4. Deep Research 模块

**文件**: `skills/deep_research.py` (600行)

**核心流程**: 树形递归搜索

```
run()
  ├→ generate_research_plan() → LLM基于初步搜索结果生成追问
  ├→ deep_research(query, breadth=N, depth=M)
       ├→ 生成N个搜索查询
       ├→ 并发处理每个查询(concurrency_limit限制)
       │    └→ 为每个查询创建独立GPTResearcher实例
       │       └→ conduct_research() → 提取learnings+followUpQuestions
       ├→ 收集所有learnings/citations/context
       ├→ depth > 1: 递归深入(breadth减半, depth-1)
       └→ trim_context_to_word_limit() → 25000词安全上限
```

配置:
- `deep_research_breadth` (默认4)
- `deep_research_depth` (默认2)
- `deep_research_concurrency` (默认2)

### 5. Agent 选择

**文件**: `actions/agent_creator.py`

基于用户查询自动选择 Agent 类型和专业角色，支持自定义 agent 和 role 参数。

### 6. 报告生成

**文件**: `skills/writer.py` + `actions/report_generation.py`

```
ReportGenerator.write_report()
  ├→ 使用预生成的图片(如有)
  ├→ get_prompt_by_report_type() 选择报告模板
  ├→ generate_report() → LLM生成Markdown报告
  └→ 支持subtopic_report(已有header/内容去重)
```

报告类型:
- ResearchReport
- DetailedReport (含目录、子主题报告)
- ResourceReport
- OutlineReport
- SubtopicReport
- DeepResearchReport

### 7. 上下文压缩

**文件**: `context/compression.py` (255行)

三种压缩器:
- **ContextCompressor**: 从抓取页面中提取相关片段 (embedding相似度)
- **VectorstoreCompressor**: 从向量库中检索 (similarity search)
- **WrittenContentCompressor**: 从已写内容中找相似部分 (去重用)

优化: 当文档总量 < 8000字符时，跳过embedding压缩直接返回。

### 8. 来源策展

**文件**: `skills/curator.py` (96行)

可选步骤，由 `cfg.curate_sources` 控制。用 LLM 评估来源的相关性、可信度和时效性，选出最优来源。

### 9. Prompt 系统

**文件**: `prompts.py` (899行)

`PromptFamily` 类，支持派生类自定义。关键方法:
- `generate_report_prompt()` - 报告生成
- `generate_mcp_tool_selection_prompt()` - MCP工具选择
- `generate_mcp_research_prompt()` - MCP研究执行
- `generate_image_analysis_prompt()` - 图片分析
- `curate_sources()` - 来源策展
- `auto_agent_instructions()` - Agent选择指令

---

## 数据流总结

```
query → retrievers.search() → URL列表
       → scraper.browse_urls() → 页面内容
       → compression → 相关片段(RAG)
       → LLM → report

MCP路径:
query → MCP retriever
       → 获取工具清单 → LLM选工具(≤3) → LLM调用工具 → 结果
       → 合并到web_context
```

---

## 代码层面值得注意的问题

| 问题 | 位置 | 说明 |
|------|------|------|
| 重复判断 | `scraper.py:135,153` | extract_data_from_url里content<100判断了两次，第153行是死代码 |
| 重复调用 | `scraper.py:49-52` | _check_pkg用两个独立if，可合并为in("tavily_extract", "firecrawl") |
| 字典重建 | `scraper.py:190` | get_scraper里SCRAPER_CLASSES每次调用都重建，应移到__init__或类常量 |
| 类型不一致 | `researcher.py:236,269` | _get_context_by_vectorstore返回tuple，_get_context_by_web_search返回str或[] |
| 封装过深 | MCP链路9层 | 调试和阅读成本高，建议从search_async()的三阶段入口开始理解 |
| async/sync桥接 | `retriever.py:234-239` | search()开新线程+新事件循环来运行search_async()，复杂但必要 |
| LLM强依赖 | curator.py:74 | curate_sources直接json.loads(LLM响应)，无错误处理 |
| 硬编码阈值 | compression.py:159 | 8000字符跳过压缩硬编码在环境变量，无文档说明 |
| 日志打印 | curator.py:49 | 直接print大列表到stdout，生产环境可能干扰日志 |

---

## 文件索引

| 文件 | 行数 | 职责 |
|------|------|------|
|| `gpt_researcher/agent.py` | 741 | 主入口: GPTResearcher类, 研究流程编排, 详见 [[GPT-Researcher Agent 入口全面分析]] |
| `gpt_researcher/skills/researcher.py` | 1013 | 核心研究流程: 上下文获取、子查询规划、MCP策略 |
| `gpt_researcher/skills/writer.py` | 254 | 报告生成: 引言、结论、子主题管理 |
| `gpt_researcher/skills/context_manager.py` | 154 | 上下文检索、压缩、相似度匹配（含 WrittenContentCompressor 多查询调度） |
| `gpt_researcher/skills/curator.py` | 96 | 来源评估和排名 |
| `gpt_researcher/skills/deep_research.py` | 600 | 深度研究: 递归树形搜索 |
| `gpt_researcher/skills/browser.py` | - | 浏览器管理器(ScraperManager) |
| `gpt_researcher/prompts.py` | 899 | 提示词模板库 |
| `gpt_researcher/scraper/scraper.py` | 214 | URL内容抓取、后端选择、并发控制 |
| `gpt_researcher/retrievers/mcp/retriever.py` | 324 | MCP检索器: 工具获取、选择、研究执行 |
| `gpt_researcher/mcp/tool_selector.py` | ~203 | LLM驱动的工具选择(选最多3个) |
| `gpt_researcher/mcp/research.py` | ~270 | LLM驱动的研究执行 + 结果格式化 |
| `gpt_researcher/context/compression.py` | 255 | 上下文压缩(VectorstoreCompressor, ContextCompressor, WrittenContentCompressor) |
| `gpt_researcher/actions/report_generation.py` | 309 | 报告生成action: 主报告、引言、结论 |
| `gpt_researcher/actions/agent_creator.py` | - | Agent角色选择 |
| `gpt_researcher/config/config.py` | - | 配置管理 |
| `gpt_researcher/vector_store/vector_store.py` | - | 向量库封装 |
| `gpt_researcher/memory/embeddings.py` | - | Embedding模型管理 |
| `gpt_researcher/document/document.py` | - | 文档加载器 |

---

## 学习心得

> 这是 Phase 1 第一天（6/13）的架构总览。后续按数据流顺序深入:
> - ~~6/14: `skills/researcher.py` 核心流程(1019行) → 已完成，见[[ResearchConductor 深度分析]]~~
> - 6/15: `report_generation.py` + `prompts.py`
> - 6/16: `deep_research.py` + `agent_creator.py`
> - ~~6/17: 对比 Hello-Agents 第14章 → 改为 agent.py 全面分析~~
> - 6/18: `multi_agents/`

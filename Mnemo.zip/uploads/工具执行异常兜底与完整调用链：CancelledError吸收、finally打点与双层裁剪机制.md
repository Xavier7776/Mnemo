---
title: 工具执行异常兜底与完整调用链：CancelledError吸收、finally打点与双层裁剪机制
summary: 深入拆解 execute_tool_async 的三段异常处理（CancelledError / Exception / finally 打点）、从 LLM tool_call 到结果回写对话历史的完整调用链、ToolExecutionManager 一次性实例化设计、异常不跨越边界的 Result 类型思路、func_return 双层裁剪保险
project: letta
tags: [letta, tool-executor, exception-handling, observability, call-chain, source-code]
created: 2026-07-03
updated: 2026-07-03
status: completed
confidence: high
---

# 工具执行异常兜底与完整调用链：CancelledError吸收、finally打点与双层裁剪机制

## 一、异常处理三段式

**源码位置**：`letta/services/tool_executor/tool_execution_manager.py` → `execute_tool_async`

### 1. `except asyncio.CancelledError`

```python
except asyncio.CancelledError as e:
    self.logger.error(...)
    error_message = get_friendly_error_msg(...)
    return ToolExecutionResult(status="error", func_return=error_message, stderr=[traceback.format_exc()])
```

| 要点 | 说明 |
|------|------|
| 触发场景 | 外部通过 `task.cancel()` 主动取消协程（用户断开、请求超时、agent step 被打断） |
| 继承链 | `CancelledError` 继承自 `BaseException`（Python 3.8+），不是 `Exception`——必须单独捕获，下面的 `except Exception` 捕不到 |
| 日志级别 | `error`——系统级中断，比业务异常更严重 |
| 是否 re-raise | **不 raise**——吞掉异常，返回 `ToolExecutionResult(status="error")` |
| 设计意图 | 上层 step 循环不用单独处理"工具被取消"，统一按 error 结果处理 |

> [!warning] 吞掉 CancelledError 的权衡
> 这里不 re-raise 意味着取消信号不会传播到上层。好处是调用方代码简单；代价是如果上层依赖 `CancelledError` 来做清理逻辑（比如回滚事务），这里会打断那个链条。Letta 选择的 trade-off 是"工具执行层自己吸收一切异常"。

### 2. `except Exception as e`

```python
except Exception as e:
    status = "error"
    self.logger.info(...)
    error_message = get_friendly_error_msg(...)
    return ToolExecutionResult(status="error", func_return=error_message, stderr=[traceback.format_exc()])
```

| 要点 | 说明 |
|------|------|
| 触发场景 | 所有其他运行时异常（工具代码报错、沙箱内部错误等） |
| 日志级别 | `info`——业务预期内的常规失败，刻意调低避免污染 error 告警 |
| `status = "error"` | 显式设置，防御性写法（默认值也是 error，防止未来有人改默认值后忘记同步） |
| `get_friendly_error_msg` | 把 `函数名 + 异常类名 + 异常消息` 拼成友好字符串，格式如 `Error executing function get_weather: KeyError: 'city'`，有长度截断（`MAX_ERROR_MESSAGE_CHAR_LIMIT`） |
| `stderr` | 完整堆栈存 `stderr` 字段，**不发给 LLM**（LLM 只看 `func_return`），用于人工调试 |

> [!note] 两个 except 分支的对比
> 两个分支代码几乎重复，唯一区别是日志级别（`error` vs `info`）和有没有手动设 `status`。有意拆开而不是合并，用来区分"系统级取消"和"业务级报错"两种严重程度。

### 3. `finally` 块

```python
finally:
    metric_attrs = {"tool.name": tool.name, "tool.execution_success": status == "success"}
    if status == "error" and step_id:
        metric_attrs["step.id"] = step_id
    MetricRegistry().tool_execution_counter.add(1, dict(get_ctx_attributes(), **metric_attrs))
```

| 要点 | 说明 |
|------|------|
| 执行保证 | `finally` 在任何 `return` 之前插入执行，无论成功失败都跑 |
| 指标类型 | `tool_execution_counter`（调用次数计数器），区别于 `AsyncTimer`（耗时直方图） |
| 标签 `tool.execution_success` | 布尔值，监控系统可按成功/失败分组统计成功率 |
| `step.id` 条件打标签 | **只有失败 + 有 step_id 时才打**——避免给大量成功调用打高基数标签，防止 cardinality explosion |

> [!tip] 高基数标签防护
> `step.id` 是每次 agent step 都不同的值，如果给所有调用都打上，监控系统（Prometheus/OTel）的指标基数会爆炸。只在失败时打，既保留了排查能力，又控制了标签基数——这是可观测性领域的经典实践。

---

## 二、完整调用链：从 LLM tool_call 到结果回写

```
Agent.step()  ← agent 主循环，每一步先调 LLM 拿响应
   │
   └─▶ _handle_ai_response(...)          # 解析 LLM 返回的 tool_call
           │  1. 解析 tool_call_name / tool_args
           │  2. 校验 tool_rules（是否允许调用、是否需要审批）
           │
           └─▶ self._execute_tool(tool_name, tool_args, agent_state, ...)   # 1922行
                   │  1. 在 agent_state.tools 里查到对应的 Tool 对象（target_tool）
                   │  2. 组装 sandbox_env_vars（从 agent 的 secrets 解密来的环境变量）
                   │  3. 构造一个新的 ToolExecutionManager 实例
                   │
                   └─▶ tool_execution_manager.execute_tool_async(...)
                           │
                           ├─▶ ToolExecutorFactory.get_executor(tool.tool_type, ...)
                           │       # 按 tool_type 查表拿到具体的 Executor 类并实例化
                           │
                           ├─▶ executor.execute(function_name, function_args, tool, actor,
                           │                     agent_state, sandbox_config, sandbox_env_vars)
                           │       # LettaCoreToolExecutor: 直接改内存 block
                           │       # SandboxToolExecutor: 在隔离环境跑用户 Python 代码
                           │       # ExternalMCPToolExecutor: 通过 MCP 协议调外部服务
                           │       # 返回 ToolExecutionResult(status, func_return, stdout, stderr, ...)
                           │
                           ├─▶ 按 tool.return_char_limit 裁剪 func_return
                           │
                           └─▶ 返回 ToolExecutionResult 给 _execute_tool
                   │
                   ◀── tool_execution_result 返回，_execute_tool 往 agent_step_span 打两个 event
                           （tool_execution_started / tool_execution_completed，用于 tracing）
           │
           ◀── tool_execution_result 返回，_handle_ai_response 继续：
                   3. validate_function_response(...)：func_return 转成最终字符串（再截断/格式化）
                   4. 把结果包装成一条 tool 角色的 Message，加进 messages_to_persist
                   5. 根据 tool_rules_solver 判断是否 continue_stepping
           │
   ◀── Agent.step() 拿到更新后的消息列表，决定结束还是继续（心跳/多步工具链）
```

---

## 三、四个关键设计点

### 1. 谁负责"选执行器"

`ToolExecutorFactory.get_executor` 是整条链路里**唯一做路由决策**的地方。之上（`_handle_ai_response`、`_execute_tool`）和之下（`executor.execute`）的代码都不关心具体是哪种工具类型。

### 2. ToolExecutionManager 是"一次性"的

每次 `_execute_tool` 调用都 `ToolExecutionManager(...)` 重新实例化，不复用。说明它被设计成**无状态、轻量级的调用封装**——`sandbox_env_vars` 等参数每次都是当次 step 现取的，不存在跨 step 的状态泄漏。

### 3. 异常永远不跨越 execute_tool_async 边界

```
try:      executor.execute(...)
except asyncio.CancelledError: → ToolExecutionResult(status="error")
except Exception:              → ToolExecutionResult(status="error")
finally:   打点上报
```

无论工具本身报错还是被取消，最终都被**吸收**成 `ToolExecutionResult(status="error")`。上层 `_execute_tool` 和 `_handle_ai_response` 完全不需要写 `try/except`——只检查 `status` / `success_flag` 就行。

> [!note] Result 类型思路
> 这是"让错误变成正常返回值的一部分"的设计（类似 Rust 的 `Result<T, E>`），而不是用异常做流程控制。好处是调用方代码线性、无嵌套 try/except；代价是调用方必须记得检查返回值的 status 字段，否则会忽略错误。

### 4. 两层裁剪保险

| 裁剪层 | 位置 | 依据 | 说明 |
|:---:|------|------|------|
| 第一层 | `execute_tool_async` 内部 | `tool.return_char_limit` | 工具级别的字符上限，执行完立刻裁 |
| 第二层 | `_handle_ai_response` 里 `validate_function_response` | `return_char_limit` | 再截断一次，且对几个 search 类工具 `truncate=False` 跳过 |

两道保险防止超长内容塞进对话历史、爆掉上下文窗口。search 类工具跳过第二层裁剪是因为搜索结果需要完整返回给 LLM 做判断。

---

## 快速参考卡

| 问题 | 答案 |
|------|------|
| CancelledError 为什么单独捕获？ | 继承 `BaseException` 不是 `Exception`，`except Exception` 捕不到 |
| CancelledError 捕获后 re-raise 吗？ | 不 raise，吞掉返回 error 结果，上层统一处理 |
| Exception 分支为什么用 info 不用 error？ | 工具报错是业务预期内的常规失败，不是系统级故障 |
| finally 块打什么指标？ | `tool_execution_counter`（调用次数），标签含 `tool.name` + `tool.execution_success` |
| step.id 标签什么时候打？ | 只有失败 + 有 step_id 时才打，防止 cardinality explosion |
| 异常会跨越 execute_tool_async 吗？ | 不会——全部吸收成 `ToolExecutionResult(status="error")` |
| func_return 被裁剪几次？ | 两次：execute_tool_async 内部一次 + validate_function_response 一次 |
| ToolExecutionManager 是单例吗？ | 不是，每次 _execute_tool 调用都 new 一个新实例 |

---

## 踩坑清单

1. **CancelledError 吞掉后上层无法感知"被取消"**：如果上层的清理逻辑依赖 `CancelledError` 传播（比如回滚事务、释放资源），这里会打断那个链条。Letta 选择的 trade-off 是工具层自己吸收一切，但如果未来加了需要取消感知的功能（比如工具执行中途的清理回调），这里需要重新评估。

2. **两个 except 分支代码重复**：唯一的区别是日志级别和 `status` 设置。如果未来需要增加第三个 except 分支（比如 `asyncio.TimeoutError` 单独处理），注意保持同样的返回结构，否则上层 `ToolExecutionResult` 的消费者会因为字段不一致出问题。

3. **`get_friendly_error_msg` 有长度截断**：`MAX_ERROR_MESSAGE_CHAR_LIMIT` 会截断超长错误消息。如果工具报的错本身就很长（比如返回了一个巨大的 JSON 报错），LLM 看到的 `func_return` 是被截断的——模型可能因为看不到完整错误信息而无法正确判断重试策略。

4. **search 类工具跳过第二层裁剪**：`validate_function_response` 对 search 类工具 `truncate=False`。如果搜索返回了大量结果（比如 archival_memory_search 命中几百条 passage），只有第一层 `tool.return_char_limit` 在守——如果工具级别的 limit 设得很大，可能一次性塞爆上下文。

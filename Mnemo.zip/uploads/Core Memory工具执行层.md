---
title: Core Memory工具执行层：接口与执行分离、写操作三层状态与三代工具集
summary: base.py 接口声明层与 core_tool_executor.py 执行层的分工、写操作三层状态、三代记忆工具集选型、attach/detach 设计、调用链路三段论
project: letta
tags: [letta, memory, module2, core-tools, block, tool-execution]
created: 2026-07-01
updated: 2026-07-01
status: completed
confidence: high
---

# Core Memory工具执行层：接口与执行分离、写操作三层状态与三代工具集

> 基于 letta-ai/letta 主分支源码核实,配合本轮问答整理

---

## 一、两个文件的分工

| 文件 | 角色 | 关键证据 |
|------|------|---------|
| `letta/functions/function_sets/base.py` | **接口声明层**——LLM 看到的工具说明书 | 函数体几乎都是 `raise NotImplementedError("This should never be invoked directly...")`,没有真实逻辑,真正有价值的是签名 + docstring,会被编译进 LLM 看到的 tool schema |
| `letta/services/tool_executor/core_tool_executor.py` | **执行层**——真正落地的代码 | `function_map`(41~55行)是名称到方法的路由表,所有记忆工具的实际逻辑都在这个类的方法里 |

拆成两个文件的原因:接口文档(给 LLM 看)和执行逻辑(给系统跑)是两件需要独立演进的事,糅在一起容易在改其中一边时误伤另一边。

---

## 二、写操作收尾必须经历的三层状态

任何一个"写"类型的记忆工具(append/replace/insert/create/delete...),改完之后都要让改动在三个独立的状态副本里保持一致,**少做哪一层都会出问题,但出问题的时机和现象不同**:

| 层级 | 含义 | 缺失后果 |
|------|------|---------|
| ① DB 里 Block 表记录 | 跨请求的真相来源,agent 下次被重新加载时只认这份 | 不写 → 这次修改在进程重启/换 worker 后彻底丢失 |
| ② 当前进程内存里的 `agent_state.memory` 对象 | 这一轮 step 循环里的工作副本,`compile()` 直接读这份生成 system prompt | 不同步 → 这一轮重新渲染时新内容进不去,即使①已经写库 |
| ③ system message 里实际存的、已编译好的文本 | 真正喂给 LLM 看的内容 | 不重新 compile/写回 → 前两层都对了,LLM 这一轮甚至下一轮看到的还是旧 prompt |

常见收尾函数对应关系:
- `update_memory_if_changed_async`:先 diff 比对②和③,真的变了才触发①的写库 + ③的重新渲染(`core_memory_append`、`memory_create`、`memory_rethink` 等用这条路径)
- `rebuild_system_prompt_async(force=True)`:跳过 diff 比对,无条件强制重渲染(`memory_rename`、`memory_update_description`、`memory_str_replace` 用的是这条路径)

→ **同一件事("改完要不要重渲染")在不同方法里走了两套判断策略,这是源码里一处尚未统一的设计**,读代码时别假设所有写方法收尾逻辑都一样。

---

## 三、三代记忆工具集(v1/v2/v3)+ sleeptime 专用集

| 工具集 | 成员 | 绑定条件 |
|--------|------|---------|
| `BASE_MEMORY_TOOLS`(v1) | `core_memory_append`、`core_memory_replace`、`memory`、`memory_apply_patch` | 最早的一套,字符串替换用原生 `.replace()`,不校验唯一性 |
| `BASE_MEMORY_TOOLS_V2` | `memory_replace`、`memory_insert` | 配合 `memgpt_v2` prompt,新增唯一性校验 + 行号防呆 guardrail |
| `BASE_MEMORY_TOOLS_V3` | 只有一个统一入口 `memory` | **专门给 Anthropic 模型用**(源码注释明确写了 "currently just a omni memory tool for anthropic") |
| `BASE_SLEEPTIME_TOOLS` | `memory_replace`、`memory_insert`、`memory_rethink`、`memory_finish_edits` | sleeptime 架构专用,独立于上面三代 |

**选型标准不是"哪个版本号最新"**,而是看:
1. 目标模型厂商是否是 Anthropic(决定能不能用 v3 这种"单工具多分支命令"模式,也决定 compile() 时是否会走 line-numbered 渲染——这点和模块一的 `git_enabled`/line-numbered 判断逻辑是配套的)
2. agent_type 是否是 sleeptime 架构(决定要不要切到独立的 sleeptime 工具集)

v1→v2 的核心升级点:`memory_replace` 比 `core_memory_replace` 多了唯一性校验(出现>1次直接报错要求消歧)和"禁止携带行号前缀/警告横幅"的 guardrail,后者是因为 v2 配合 line-numbered 渲染界面使用,要防止 LLM 把界面上看到的 `12→` 当成内容字面量传进来。

---

## 四、Block 的"attach/detach"而非"直接增删"

**设计要解决的问题**:Block 不是某个 agent 私有的数据,而是**可以被多个 agent 共享引用的独立实体**。证据:`attach_block_async()` 里如果 agent 属于 sleeptime 分组,会自动把同一个 block 也 attach 给同组的另一个 agent(主从 agent 共享同一份记忆)。

**如果做成直接增删会有什么麻烦**:
- 数据生命周期被绑死在单个 agent 身上,没法在多个 agent 间复用同一份内容
- "从这个 agent 的上下文里移除"和"彻底销毁这条数据"这两件事被混为一谈

**attach/detach 把两件事拆开**:detach 只解除"这个 agent 和这条数据"的关系,数据本身可能还活着(被别的 agent 引用,或者以后还能重新挂回来)。

---

## 五、调用链路三段论(从自然语言到 Block 真正被改)

```
LLM 知道有哪些工具可调
  ↓ (base.py 的 docstring 被编译进 tool schema)
LLM 发起调用,系统按工具名路由
  ↓ (function_map 路由到 core_tool_executor.py 里真正有逻辑的方法)
方法内做校验 + 算出新值
  ↓ (read_only 检查、唯一性匹配、行号防呆…)
持久化 + 重新渲染
  (写 DB + 重新 compile + 同步回 system message,这一步不做,前面全白做)
```

---

## 六、读代码时发现的几处跨方法不一致(留作后续验证存档)

这些不是文档里写好的内容,是逐行核对源码时发现的,记下来防止以后被绕进去:

1. **label 路径解析不统一**:六个 v3 方法(`create`/`delete`/`rename`/`update_description`/`str_replace`/`str_insert`)里,`create` 和 `str_replace` 对 `path` 参数只做 `removeprefix`,不做 `/`→`_` 替换;另外四个做了替换。嵌套路径(如 `/memories/project/notes`)场景下,用 `create` 建的 block 和用 `delete` 去找的 label 字符串不一致,会查不到。
2. **`memory()` 统一入口里没有独立的 `update_description` command**,这个功能被塞进了 `command="rename"` 分支,靠"传 `path`+`description` 还是 `old_path`+`new_path`" 隐式区分意图,且 `if path and description` 永远优先于 `elif old_path and new_path` 被判断,四个参数都传时会静默只执行改描述,不执行改名,没有任何报错提示。
3. **写操作收尾路径不统一**(见第二节),`update_memory_if_changed_async` 和 `rebuild_system_prompt_async(force=True)` 两条路径在不同方法里混用,没有抽成一致的模式。
4. **guardrail 校验代码重复**:`memory_replace`/`memory_insert`/`memory_rethink` 三者开头的"行号前缀检查 + 行号警告横幅检查"几乎逐字重复,没有抽成共享函数。

---

## 模块二自查清单

- [ ] 能不看代码讲清楚 base.py 和 core_tool_executor.py 的分工
- [ ] 能讲清楚写操作收尾的三层状态,以及为什么顺序/层级不能少
- [ ] 能讲清楚 v1/v2/v3 选型该看什么标准,而不是"哪个最新"
- [ ] 能讲清楚 attach/detach 设计解决的具体问题
- [ ] 能脱离函数名,用自己的话复述一遍调用链路三段论

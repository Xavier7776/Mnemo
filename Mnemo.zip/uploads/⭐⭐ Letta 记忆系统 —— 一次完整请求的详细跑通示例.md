---
title: Letta 记忆系统 —— 一次完整请求的详细跑通示例
summary: 模拟一次用户消息同时触发"检索 Archival + 检索 Recall + 修改 Core Memory + token 接近阈值"的复杂场景，逐步走通 4 轮 step 循环中 _rebuild_memory_async 的调用时机、子串过滤的迟滞更新特性、以及三种记忆生命周期分离的核心机制
project: letta
tags: [letta, memory, end-to-end, walkthrough, archival, recall, core-memory, _rebuild_memory_async, summarizer, step-loop]
created: 2026-07-04
updated: 2026-07-04
status: completed
confidence: high
---

# ⭐⭐ Letta 记忆系统 —— 一次完整请求的详细跑通示例

> 场景比之前的总结更复杂：一次用户消息里包含"检索 Archival + 检索 Recall + 修改 Core Memory + 触发一次接近阈值的 token 检查"四件事，模拟真实场景下多个记忆子系统在同一个 step 循环里交织工作的情况。所有函数名、字段名均已对照 letta-ai/letta 源码核实。

> [!note] 相关笔记（按本文涉及的知识点）
> - 内存重建时机与子串/精确 diff：`[[_rebuild_memory_async场景走读：内存刷新、System Message重建与轻量diff过滤]]`
> - Archival / Recall 检索与工具路由：`[[Archival Memory双存储与概念纠偏]]`、`[[Recall Memory混合检索：双入口架构、Turbopuffer降级与RRF分数融合]]`、`[[工具执行器工厂：ToolType七类映射、沙箱兜底默认与策略注入解耦设计]]`
> - Core Memory 工具修改（memory_replace / block_manager）：`[[Core Memory工具执行层]]`
> - 上下文压缩保护：`[[Agent自压缩：Prompt Cache复用与三级降级兜底的上下文管理机制]]`、`[[compact_messages收尾：摘要结构化包装与消息列表拼装的四步收束]]`

---

## 0. 初始状态快照（请求进来之前）

**Agent 基本信息**

```
agent_id      = "agent-7f3a"
agent_type    = memgpt_v2_agent          # → 挂载 BASE_MEMORY_TOOLS_V2，渲染走 line-numbered 分支（因为搭配 Anthropic 模型）
llm_config.model_endpoint_type = "anthropic"
conversation_id = "conv-9c21"
actor(User)   = Xavier
```

**Core Memory（数据库里已有的两个 Block）**

| block_id | label | value | limit | read_only |
|----------|-------|-------|-------|-----------|
| blk-001 | persona | "I am Sam, a research assistant specialized in time series forecasting and deep learning." | 2000 | False |
| blk-002 | human | "User's name is Xavier. Xavier works on time series forecasting. Xavier's main project is GRDIformer." | 2000 | False |

**Archival Memory（该 agent 绑定的默认 archive 里已有的 passage，部分列出）**

| passage_id | text（节选） | tags |
|-----------|------|------|
| pas-101 | "GRDIformer 使用门控趋势分解 + Inverted Transformer 结构，核心创新点是..." | ["grdiformer", "architecture"] |
| pas-102 | "分位数回归概率预测框架里，pinball loss 的实现细节..." | ["grdiformer", "quantile-regression"] |
| pas-103 | "关于 newsvendor 模型的成本函数推导笔记..." | ["newsvendor", "decision-theory"] |

archive 的 `archive_tags`（去重后的全部 tag）目前是：`["grdiformer", "architecture", "quantile-regression", "newsvendor", "decision-theory"]`

**Recall Memory（对话历史）**

- 数据库里该 agent 的历史消息总数：`num_messages = 187`
- 当前加载进上下文窗口的 `in_context_messages`：只有最近 22 条（更早的已经被 summarizer 压缩过一次，折叠成了一条 summary 消息）
- 因此 `previous_message_count = 187 - 22 = 165`（这个数字会被写进 system message 的 metadata 里，让 LLM 知道"还有 165 条更早的历史没在我眼前，需要的话可以用 conversation_search 去找"）

**当前存储在 DB 里的 system message 全文**（`curr_system_message_text`，也就是 `in_context_messages[0].content[0].text`）：

```
You are Sam, a helpful research assistant.

<memory_blocks>
<persona>
1→ I am Sam, a research assistant specialized in time series forecasting and deep learning.
</persona>
<human>
1→ User's name is Xavier. Xavier works on time series forecasting. Xavier's main project is GRDIformer.
</human>
</memory_blocks>

<tool_usage_rules>
Rule: use send_message as the last step to end your turn.
</tool_usage_rules>

<memory_metadata>
- last_modified: 2026-07-03T22:10:00Z
- previous_message_count: 164
- archival_memory_size: 3
- archive_tags: grdiformer, architecture, quantile-regression, newsvendor, decision-theory
</memory_metadata>
```

（注意行号前缀 `1→`，因为 `memgpt_v2_agent` + Anthropic 命中了 `is_line_numbered = True` 分支，走的是 `_render_memory_blocks_line_numbered()`）

（也注意 `previous_message_count: 164` 和 `archival_memory_size: 3`——这是**上一轮**重建时的数字，跟这一轮实际的 165 / 3 已经有 1 的偏差，因为上一轮结束后又有一条消息落库了，但内存内容本身没变，所以没有触发重建，metadata 里的数字就没更新。这个偏差本身很正常，等下会看到本轮重建时如何被修正。）

---

## 1. 用户发来这条消息

> "帮我查一下之前存的关于 GRDIformer 分位数回归的笔记，另外搜一下我们上次聊天时提到的实习计划表的事，最后记住一下：我这周正式入职那家对冲基金了，职位是量化研究员。"

这一条消息里同时包含三个意图：
1. 检索 **Archival Memory**（分位数回归笔记）
2. 检索 **Recall Memory**（上次聊天中提到的实习计划表）
3. 修改 **Core Memory**（更新工作状态）

这决定了整个 step 循环需要跑好几轮 LLM 调用。

---

## 2. Step 循环 · 第 1 轮：发起第一次 LLM 请求

### 2.1 `_create_llm_request_data_async` 被调用，触发第 1 次 `_rebuild_memory_async`

```python
in_context_messages = await self._rebuild_memory_async(
    in_context_messages, agent_state,
    num_messages=187, num_archival_memories=3,
    tool_rules_solver=tool_rules_solver,
)
```

内部执行：

1. `refresh_memory_async` 刷新 blocks —— persona/human 内容跟 DB 里一致，没变。
2. 编译新的 `curr_memory_str`：

```
<memory_blocks>
<persona>
1→ I am Sam, a research assistant specialized in time series forecasting and deep learning.
</persona>
<human>
1→ User's name is Xavier. Xavier works on time series forecasting. Xavier's main project is GRDIformer.
</human>
</memory_blocks>

<tool_usage_rules>
Rule: use send_message as the last step to end your turn.
</tool_usage_rules>
```

3. 子串检查：

```python
memory_changed = curr_memory_str not in curr_system_message_text
# curr_memory_str 里的 persona/human 内容跟旧 system message 里存的完全一致（一字未改）
# → False，判定"没变化"
```

4. `(not system_prompt_changed) and (not memory_changed)` = `True` → **直接 return，不重新计算 metadata，不碰数据库**。哪怕 `num_messages`/`num_archival_memories` 实际已经跟旧 metadata 里的数字有偏差，这一步也完全不理会——因为触发重建的唯一条件是"内存内容变了"，metadata 数字的漂移会等到**下一次内存真正变化**时被一并修正。

### 2.2 LLM 拿到的请求

system message 用的还是旧版（带着 `previous_message_count: 164` 这个略微过期的数字），22 条历史消息 + 这条新用户消息一起发给模型。工具列表包含（因为是 `memgpt_v2_agent`）：

```
BASE_TOOLS - DEPRECATED_LETTA_TOOLS = { send_message, conversation_search }
∪ BASE_MEMORY_TOOLS_V2 = { memory_replace, memory_insert }
```

（注意：`archival_memory_insert`/`archival_memory_search` 在 `DEPRECATED_LETTA_TOOLS` 里被剔除了——这版 agent 类型下这两个工具可能是通过别的方式挂载，或者被替换成了别的检索工具名。这里假设该 agent 额外显式挂载了 `archival_memory_search`。）

### 2.3 LLM 返回

模型的 reasoning：先处理检索类需求，决定第一步调用 `archival_memory_search`。

```json
{
  "tool_call_name": "archival_memory_search",
  "tool_args": {
    "query": "分位数回归 pinball loss",
    "tags": ["quantile-regression"],
    "tag_match_mode": "any",
    "top_k": 3
  }
}
```

### 2.4 Step 循环层：规则 + 审批检查

- `ToolRulesSolver` 检查：当前没有强制"只能调用 X 工具"的规则，`archival_memory_search` 允许被调用。
- 审批检查：该工具未被标记为需要审批，直接放行，不生成 approval 消息。

### 2.5 `execute_tool_async` 路由执行

```python
executor = ToolExecutorFactory.get_executor(ToolType.LETTA_CORE, ...)
# → LettaCoreToolExecutor
result = await executor.execute("archival_memory_search", {...}, tool, actor, agent_state, ...)
```

`LettaCoreToolExecutor.archival_memory_search` 委托给 `agent_manager.search_agent_archival_memory_async`，带着 `tags=["quantile-regression"]` 去 pgvector 里做向量检索，命中 `pas-102`。

返回结果打包成一条 tool 消息追加进 `in_context_messages`：

```json
{
  "role": "tool",
  "name": "archival_memory_search",
  "content": "[1 result] pas-102: 分位数回归概率预测框架里，pinball loss 的实现细节..."
}
```

**注意**：Core Memory blocks 完全没被碰，`agent_state.memory` 原封不动。

---

## 3. Step 循环 · 第 2 轮：还没结束，继续发起 LLM 请求

### 3.1 触发第 2 次 `_rebuild_memory_async`

跟第 1 次逻辑完全一样：`refresh_memory_async` → 编译 `curr_memory_str` → 子串比对。因为上一步 archival 搜索没有改动 blocks，`memory_changed = False`，**再次跳过重建**，直接返回。

### 3.2 LLM 返回第二个工具调用

模型接着处理第二个意图（实习计划表），决定调用 `conversation_search`：

```json
{
  "tool_call_name": "conversation_search",
  "tool_args": {
    "query": "实习计划表",
    "search_mode": "hybrid",
    "limit": 5
  }
}
```

### 3.3 执行 `conversation_search`

路由到同一个 `LettaCoreToolExecutor`，内部调用 `message_manager.search_messages_async`：

- `hybrid` 模式：同时做向量检索和全文检索（FTS），再用 RRF 融合两个排名。
- 内部会**过滤掉 role 为 tool 的消息**（避免刚才那条 archival 检索结果被递归检索进来，造成噪音）。
- 命中一条 3 天前的历史消息："我完成了内部数据分析岗位的实习计划表填写"。

返回结果：

```json
{
  "role": "tool",
  "name": "conversation_search",
  "content": "[1 result, rrf_score=0.87] 2026-07-01: 我完成了内部数据分析岗位的实习计划表填写"
}
```

这条也只是普通追加进对话历史，Core Memory 依旧没有变化。

---

## 4. Step 循环 · 第 3 轮：处理第三个意图，Core Memory 真正被修改

### 4.1 触发第 3 次 `_rebuild_memory_async`

前两步的检索都没碰 blocks，所以这一次依然是"没变化，跳过"——这是本轮流程里**最后一次快速跳过**。

### 4.2 LLM 返回第三个工具调用

模型现在处理"记住我换工作了"这个意图。因为是 `memgpt_v2_agent`，挂的是 V2 工具集里的 `memory_replace`（按行号定位编辑）：

```json
{
  "tool_call_name": "memory_replace",
  "tool_args": {
    "label": "human",
    "line_number": 1,
    "old_text": "User's name is Xavier. Xavier works on time series forecasting. Xavier's main project is GRDIformer.",
    "new_text": "User's name is Xavier. Xavier works on time series forecasting. Xavier's main project is GRDIformer. Xavier just started as a Quant Researcher at a hedge fund this week."
  }
}
```

### 4.3 执行 `memory_replace`

- 审批检查：内存修改工具默认不需要审批（除非管理员额外配置），放行。
- `execute_tool_async` 路由到 `LettaCoreToolExecutor.memory_replace`：
  - 先做**行号校验**——确认 `line_number=1` 在当前 human block 的合法范围内，且 `old_text` 与该行当前内容匹配（防止基于过期视图做编辑）。
  - 校验通过，调用 `block_manager` 更新数据库里 `blk-002` 的 `value` 字段为新文本。
- 返回一条成功消息追加进对话历史：

```json
{
  "role": "tool",
  "name": "memory_replace",
  "content": "Successfully replaced line 1 in block 'human'."
}
```

此时数据库里的 `blk-002.value` 已经是：

```
User's name is Xavier. Xavier works on time series forecasting. Xavier's main project is GRDIformer. Xavier just started as a Quant Researcher at a hedge fund this week.
```

---

## 5. Step 循环 · 第 4 轮：最后一次 LLM 调用前，触发真正的重建

### 5.1 触发第 4 次 `_rebuild_memory_async` —— 这次会真的重写数据库

1. `refresh_memory_async` 拉到的 `blk-002.value` 已经是新内容。
2. 重新编译：

```python
curr_memory_str = agent_state.memory.compile(
    tool_usage_rules=tool_constraint_block,
    sources=agent_state.sources,
    max_files_open=agent_state.max_files_open,
    llm_config=agent_state.llm_config,
)
```

得到：

```
<memory_blocks>
<persona>
1→ I am Sam, a research assistant specialized in time series forecasting and deep learning.
</persona>
<human>
1→ User's name is Xavier. Xavier works on time series forecasting. Xavier's main project is GRDIformer. Xavier just started as a Quant Researcher at a hedge fund this week.
</human>
</memory_blocks>

<tool_usage_rules>
Rule: use send_message as the last step to end your turn.
</tool_usage_rules>
```

3. 子串检查：

```python
memory_changed = curr_memory_str not in curr_system_message_text
# 新文本里多了 "Xavier just started as a Quant Researcher..." 这一整段
# 旧的 curr_system_message_text 里根本没有这段，找不到匹配
# → True，检测到变化！
```

4. `(not system_prompt_changed) and (not memory_changed)` = `False` → **进入重建流程**：

```python
num_messages = await self.message_manager.size_async(...)
# 这一轮已经产生了 4 条新消息（用户消息 + 3 条 tool 返回），加上之前的 187 → 191
# 但由于外部预先传入 num_messages=187（本 step 开始时缓存的值），这里若未强制刷新，
# 实际使用的是 step 开始时缓存的 self.num_messages（Letta 的实现选择在一个 step 内复用缓存值，
# 避免每一轮工具调用后都重新查一次数据库），所以这里仍是 187。

num_archival_memories = 3  # 本轮没有新增 archival passage，数字不变
```

5. 调用 `PromptGenerator.get_system_message_from_compiled_memory(...)` 拼出完整新文本：

```
You are Sam, a helpful research assistant.

<memory_blocks>
<persona>
1→ I am Sam, a research assistant specialized in time series forecasting and deep learning.
</persona>
<human>
1→ User's name is Xavier. Xavier works on time series forecasting. Xavier's main project is GRDIformer. Xavier just started as a Quant Researcher at a hedge fund this week.
</human>
</memory_blocks>

<tool_usage_rules>
Rule: use send_message as the last step to end your turn.
</tool_usage_rules>

<memory_metadata>
- last_modified: 2026-07-04T09:42:17Z
- previous_message_count: 165
- archival_memory_size: 3
- archive_tags: grdiformer, architecture, quantile-regression, newsvendor, decision-theory
</memory_metadata>
```

（这里 `previous_message_count` 从上一轮遗留的 164 更新为了 165 = 187 - 22，顺带修正了之前提到的那个"漂移"）

6. `united_diff(curr_system_message_text, new_system_message_str)` 输出非空 diff（human block 那一行 + metadata 时间戳/计数都变了）。

7. 落库：

```python
new_system_message = await self.message_manager.update_message_by_id_async(
    curr_system_message.id,
    message_update=MessageUpdate(content=new_system_message_str),
    actor=self.actor, project_id=agent_state.project_id,
)
return [new_system_message, *in_context_messages[1:]]
```

数据库里 system message 那一行被原地更新，**消息 ID 不变**，只是 content 换了；`in_context_messages` 列表返回给上层继续用。

### 5.2 LLM 生成最终回复

这一次请求带上的是**全新**的 system message（human block 已经是最新工作状态），加上前面几轮追加的 3 条 tool 返回消息，模型据此生成一段总结性的回复，调用 `send_message` 结束这一 step：

```json
{
  "tool_call_name": "send_message",
  "tool_args": {
    "message": "找到了！关于分位数回归的 pinball loss 实现细节笔记我帮你调出来了……实习计划表那边你上周已经填完了……另外已经把你入职对冲基金做量化研究员的事更新进我的记忆了。"
  }
}
```

`send_message` 命中 `ToolRulesSolver` 里的终止规则，step 循环结束。

---

## 6. 请求结束后：Summarizer 是否介入？

这一轮总共新增了 5 条消息（用户消息 + 3 条 tool 返回 + 1 条最终回复），加上之前的 187 条，总数变成 192 条。假设这一轮消息累计的 token 数刚好压过 `llm_config.context_window` 的阈值：

```python
new_in_context_messages, _updated = await self.summarizer.summarize(
    in_context_messages=in_context_messages,
    new_letta_messages=new_letta_messages,
    run_id=run_id, step_id=step_id,
)
```

`Summarizer.summarize()` 检查 `message_buffer_limit`，决定把当前 22+5=27 条消息里最早的一批（比如最早的 15 条）折叠成一条新的 summary 消息，保留最近 12 条 + 这条 summary。

**关键点**：这次折叠操作的输入是 `in_context_messages`，而这个列表的**第一条（system message）在上一步已经被替换成了刚重建的新版本**，`compact.py` 里的压缩逻辑只处理"用户/助手/工具"这几类角色的消息，**永远不会把 system message 纳入压缩范围**——所以无论压缩发生在 `_rebuild_memory_async` 之前还是之后，Core Memory 都不受影响。

---

## 7. 状态变化总览表（本轮请求前 vs 后）

| 项目 | 请求前 | 请求后 |
|------|--------|--------|
| `blk-002.value`（human block） | "...main project is GRDIformer." | "...main project is GRDIformer. Xavier just started as a Quant Researcher at a hedge fund this week." |
| system message 内容 | 旧版（换工作前） | 新版（换工作后），**同一条消息记录被原地更新**，非新增 |
| `in_context_messages` 长度 | 22 条 | 先变成 27 条（新增 5 条），summarizer 触发后压缩为 13 条（12 条原始 + 1 条新 summary） |
| Archival passage 总数 | 3 | 3（本轮只检索，没有 insert） |
| Recall 检索结果 | — | 命中 `pas-102`（archival）+ 1 条历史消息（conversation_search），均以临时 tool 消息形式出现，之后随 summarizer 一起被折叠进历史摘要 |
| `_rebuild_memory_async` 调用次数 | — | **4 次**（每次发起 LLM 请求前各一次），前 3 次判定"无变化"快速跳过，第 4 次检测到 human block 变化，触发真正重建并写库 |

---

## 8. 这个例子体现的核心机制

1. **多工具调用共享同一个 step 循环**：一次用户消息可以在一个 step 里连续触发多次工具调用（先查 archival，再查 recall，最后改 core memory），`_rebuild_memory_async` 在**每一次**即将调用 LLM 前都会检查一遍，但只有真正修改了 blocks 的那一次才会触发落库。

2. **子串检查的"迟滞更新"特性**：只要 blocks 内容没变，即使 metadata 里的统计数字（`previous_message_count`）已经跟真实值有偏差，也不会单独触发重建——这个偏差会在下一次内存真正变化时被一并修正，是一种"懒更新"的设计取舍。

3. **检索结果与恒定状态的生命周期完全分离**：`archival_memory_search`/`conversation_search` 的结果只是普通对话消息，会随 summarizer 一起被折叠、老化；而 `memory_replace` 改动的 blocks 内容通过 system message 的重建机制持久保留，且**不受 summarizer 影响**——因为它压根不在 `in_context_messages` 的压缩候选范围内。

4. **工具的执行环境统一由 `ToolType` 决定**：本例中 `archival_memory_search`、`conversation_search`、`memory_replace` 三个工具虽然功能完全不同，但因为都属于 `LETTA_CORE`/`LETTA_MEMORY_CORE` 类型，全部路由到同一个 `LettaCoreToolExecutor`，执行路径统一、开销最低；如果换成一个自定义 Python 工具或 MCP 工具，则会分别路由到 `SandboxToolExecutor` 或 `ExternalMCPToolExecutor`，执行成本和隔离级别完全不同。
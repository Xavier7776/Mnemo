---
title: 审批挂起机制：request_heartbeat回塞重放、approval消息持久化与step循环挂起
summary: 深入拆解高风险工具调用的审批请求流程——is_requires_approval_tool 判断、request_heartbeat 为什么必须塞回 tool_args（为了审批通过后原样重放不丢失心跳意图）、thinking 不塞回的原因、approval 消息持久化与 stop_reason 设置、审批通过/拒绝两条恢复路径
project: letta
tags: [letta, approval, tool-execution, heartbeat, replay, step-loop, source-code]
created: 2026-07-04
updated: 2026-07-04
status: completed
confidence: high
---

# 审批挂起机制：request_heartbeat回塞重放、approval消息持久化与step循环挂起

## 一句话结论

这段代码是"高风险工具调用 → 暂停等人审批"链路的起点。核心动作是把临时摘出来的 `request_heartbeat` 补回参数字典，完整保存这次调用请求，为将来"审批通过后原样重放执行"做准备，同时把 step 循环挂起等待人工决定。

---

## 一、前因：走到这里时 tool_args 已经被清理过

```python
tool_args = _safe_load_tool_call_str(tool_call.function.arguments)
request_heartbeat = _pop_heartbeat(tool_args)      # 已弹出，存到变量里
tool_args.pop(INNER_THOUGHTS_KWARG, None)          # thinking 已丢弃
```

走到审批判断时，`tool_args` 是"干净"的——只剩工具函数真正需要的业务参数。

---

## 二、判断是否需要审批

```python
if not is_approval and tool_rules_solver.is_requires_approval_tool(tool_call_name):
```

| 条件 | 含义 |
|------|------|
| `not is_approval` | 这不是"审批已通过后重放"的调用——防止死循环，已批准过的不需要再审批 |
| `is_requires_approval_tool(...)` | 查 agent 配置里这个工具是否被标记为"高风险/需要人工确认"（如发消息、执行代码等有副作用的操作） |

两个条件同时满足 = **全新的、需要暂停并请求人工审批的工具调用**。

---

## 三、为什么要把 request_heartbeat 塞回去

```python
tool_args[REQUEST_HEARTBEAT_PARAM] = request_heartbeat
```

### 核心原因：审批通过后要原样重放

这次 tool_call **不会被执行**，而是被**原样持久化存起来**，等用户审批通过后，从历史记录里重新读出来**重放（replay）**执行。

重放的证据（同文件 248 行附近）：

```python
if in_context_messages[-1].role == "approval":
    approval_request_message = in_context_messages[-1]
    ...
    _handle_ai_response(
        approval_request_message.tool_calls[0],   # ← 直接拿出上次存的 tool_call 原样重放
        ...
        is_approval=input_messages[0].approve,     # 这次带上 True
        ...
    )
```

审批通过后，Letta 把 approval 消息里存的 `tool_calls[0].function.arguments` 当作原始 LLM 输出，重新走一遍 `_handle_ai_response` 的完整流程：`_safe_load_tool_call_str` → `_pop_heartbeat` → ... → `executor.execute()`。

### 如果不塞回去会怎样

| 场景 | 后果 |
|------|------|
| 不塞回 `request_heartbeat` | 重放时 `_pop_heartbeat(tool_args)` 拿到默认值 `False`——**丢失模型最初对"要不要继续跑"的原始意图** |
| 塞回 `request_heartbeat` | 重放时 pop 出来的是模型最初的值，心跳意图完整保留 |

所以必须把之前临时摘出来存到变量里的值，重新塞回 `tool_args`，保证序列化存档的参数是"完整原始"的。

### thinking 为什么不塞回去

`INNER_THOUGHTS_KWARG`/`thinking` 的内容早在更早的地方就单独存到 `reasoning_content` 里，传给 `create_approval_request_message_from_llm_response` 了——不需要留在 `arguments` 字符串里重复存一份。

> [!note] 两个字段的不同处理
> - `request_heartbeat`：**塞回去**——因为重放时需要再 pop 一次拿到值，不塞就会丢
> - `thinking`：**不塞回去**——因为内容已经存在 `reasoning_content` 里了，不需要重复存

---

## 四、构造并持久化审批请求消息

```python
approval_messages = create_approval_request_message_from_llm_response(
    ...
    requested_tool_calls=[
        ToolCall(id=tool_call_id,
                 function=FunctionCall(name=tool_call_name,
                                       arguments=json.dumps(tool_args)))
    ],
    reasoning_content=reasoning_content,
    ...
)
messages_to_persist = (initial_messages or []) + approval_messages
```

| 步骤 | 说明 |
|------|------|
| `json.dumps(tool_args)` | 把补全了 `request_heartbeat` 的参数字典重新序列化成 JSON 字符串 |
| 包成 `ToolCall` 对象 | 含 `id`、`function.name`、`function.arguments`，完整保留原始调用信息 |
| `create_approval_request_message_from_llm_response` | 生成一条 `role == "approval"` 的消息，发给客户端展示"是否批准调用工具 X？"的 UI |
| `messages_to_persist` | 存入对话历史，将来审批通过时从这里取出重放 |

---

## 五、停止 step 循环

```python
continue_stepping = False
stop_reason = LettaStopReason(stop_reason=StopReasonType.requires_approval.value)
```

| 设置 | 含义 |
|------|------|
| `continue_stepping = False` | 审批请求**必须暂停**——不能既没执行工具、又没等人确认就自己瞎猜结果继续推理 |
| `stop_reason = requires_approval` | 明确标记停下来的原因是"等待审批"，方便客户端 UI 渲染"批准/拒绝"按钮，也方便日后从此状态恢复 |

> [!warning] 与 denial 分支的对比
> 审批请求 = `continue_stepping = False`（必须暂停等人决定）
> 审批被拒绝 = `continue_stepping = True`（不执行工具，但合成错误结果塞回历史，agent 可以继续跑）
> 
> 区别在于：审批请求时 agent 还不知道结果，不能继续；拒绝时 agent 已经知道"被拒了"，可以拿着错误信息继续推理。

---

## 六、完整流程串联

```
LLM 想调用高风险工具
   │
   ▼
检测到 is_requires_approval_tool = True
   │
   ▼
把 request_heartbeat 塞回参数、连同 reasoning_content 一起
打包成一条 role="approval" 的消息存进数据库
   │
   ▼
continue_stepping = False，stop_reason = requires_approval
→ 整个 step() 循环在这里"卡住"，把状态返回给客户端
   │
   ▼
（用户在前端点"同意"或"拒绝"）
   │
   ├─ 同意 → 下次请求时 in_context_messages[-1].role == "approval"
   │         → 把存好的 tool_calls[0] 原样取出重放 → is_approval=True
   │         → 跳过审批检查、调用 executor.execute() 真正执行工具
   │
   └─ 拒绝 → is_denial=True
             → 不执行工具，合成一条"被拒绝"的错误结果塞回历史
             → continue_stepping=True，agent 拿着错误信息继续推理
```

---

## 快速参考卡

| 问题 | 答案 |
|------|------|
| 为什么审批前要塞回 `request_heartbeat`？ | 审批通过后要原样重放 tool_call，重放时会再 pop 一次，不塞就会丢心跳意图 |
| `thinking` 为什么不塞回去？ | 内容已存在 `reasoning_content` 里，不需要重复存 |
| 审批消息的 role 是什么？ | `role == "approval"`，专门的角色，不是 user/assistant/tool |
| 审批请求时 `continue_stepping` 是什么？ | `False`——必须暂停等人工决定 |
| 审批被拒绝时 `continue_stepping` 是什么？ | `True`——不执行工具但 agent 拿错误信息继续推理 |
| 重放时怎么跳过审批检查？ | `is_approval=True`，`not is_approval` 为 False，不进审批分支 |
| `stop_reason` 设为什么？ | `StopReasonType.requires_approval` |
| approval 消息存在哪里？ | 对话历史（`messages_to_persist`），重放时从 `in_context_messages[-1]` 取 |

---

## 踩坑清单

1. **`request_heartbeat` 回塞是重放正确性的关键**：如果未来有人重构这段代码，把 `request_heartbeat` 的回塞去掉（觉得"反正 pop 时有默认值 False"），审批通过后重放执行的工具调用会丢失模型原始的心跳意图——agent 本该继续跑的结果停了。这个 bug 不会报错，只是行为静默变化，很难排查。

2. **`is_approval` 参数防止死循环**：重放时传 `is_approval=True`，`not is_approval` 为 False，跳过审批检查。如果忘记传这个参数，重放又会触发审批请求 → 存新 approval 消息 → 下次又重放 → 又触发审批 → 死循环。

3. **approval 消息的 `tool_calls` 必须是完整原始数据**：包括 `tool_call_id`、`function.name`、`function.arguments`。重放时直接用这些字段重新走 `_handle_ai_response`，任何一个字段缺失或被篡改都会导致重放失败。

4. **审批超时/用户不响应的兜底**：代码里 `continue_stepping = False` 后 step 循环就停了，但如果用户一直不点"同意"或"拒绝"，这条 approval 消息会一直留在对话历史里。下次用户发新消息时，`in_context_messages[-1].role == "approval"` 仍然成立——如果新消息没带 `approve` 字段，可能会走到意外的分支。

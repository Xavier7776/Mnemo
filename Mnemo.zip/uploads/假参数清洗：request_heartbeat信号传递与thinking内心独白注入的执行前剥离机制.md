---
title: 假参数清洗：request_heartbeat信号传递与thinking内心独白注入的执行前剥离机制
summary: 深入拆解 _handle_ai_response 里两行 pop 代码背后的设计——request_heartbeat 作为"心跳续跑"控制信号被动态注入每个工具 schema、thinking 作为不支持原生 reasoning 的模型的 CoT 替代品被强制注入参数列表、两者必须在 executor.execute 之前从 tool_args 字典弹出否则 TypeError、_pop_heartbeat 的字符串兼容处理
project: letta
tags: [letta, tool-execution, heartbeat, inner-thoughts, schema-injection, source-code]
created: 2026-07-04
updated: 2026-07-04
status: completed
confidence: high
---

# 假参数清洗：request_heartbeat信号传递与thinking内心独白注入的执行前剥离机制

## 一句话结论

LLM 返回的 tool_call 参数里混进了两个"假参数"——`request_heartbeat` 和 `thinking`（inner thoughts）。它们不是工具函数真正需要的入参，只是 Letta 用来跟模型"传信号"的字段，必须在真正执行工具之前从参数字典里摘掉，否则会当作真实参数传给工具函数报 `TypeError`。

---

## 一、为什么会有这两个"假参数"混进来

Letta 给 LLM 提供的工具 schema（function calling schema）不是"干净"的——会被**动态注入额外字段**：

### 1. `request_heartbeat`

| 要点 | 说明 |
|------|------|
| 常量 | `REQUEST_HEARTBEAT_PARAM = "request_heartbeat"` |
| 用途 | Letta agent 是"多步自循环"的：一次工具调用完后，可以选择不等用户说话、自己接着推理下一步 |
| 注入方式 | 被塞进**每一个工具**的 function schema 里，作为一个额外的 boolean 参数 |
| 效果 | LLM 在调用任何工具时，顺便告诉 Letta："我这次调用完，要不要继续跑（true）还是先停下来（false）" |
| 问题 | 这跟工具函数本身的业务逻辑无关——比如 `send_email(to, subject, body, request_heartbeat)` 里最后这个参数用户写的函数根本不需要 |

### 2. `thinking` / `INNER_THOUGHTS_KWARG`

| 要点 | 说明 |
|------|------|
| 常量 | `INNER_THOUGHTS_KWARG = "thinking"`（见 `settings.py`） |
| 用途 | 不支持原生"思考/reasoning content"字段分离输出的模型，无法像 Claude extended thinking 那样单独输出"内心独白" |
| 注入方式 | 把"写一段思考过程"也伪装成 function schema 里的一个参数，强制模型在调用工具时先写下"我为什么要这么做" |
| 注入位置 | `anthropic_client.py`、`google_vertex_client.py` 在构造工具 schema 时往 `properties` 里注入，且强制设为 `required` |
| 效果 | 即使模型只会做 tool call，也能间接获得 CoT / 可解释性 |

> [!note] 设计意图
> 这两个字段本质上是 Letta 在"工具调用协议"上叠加的两层控制信号：
> - `request_heartbeat` = **控制流信号**（agent 要不要继续自循环）
> - `thinking` = **可观测性信号**（模型为什么决定这么做）
>
> 它们利用了 function calling 的参数通道来"搭便车"传输，而不是走独立的协议字段——这样即使是最基础只支持 tool calling 的模型也能用。

---

## 二、两行 pop 代码做了什么

```python
tool_args = _safe_load_tool_call_str(tool_call.function.arguments)   # JSON 字符串 → dict
request_heartbeat = _pop_heartbeat(tool_args)   # 弹出 request_heartbeat，同时拿到布尔值
tool_args.pop(INNER_THOUGHTS_KWARG, None)       # 弹出 thinking，直接丢弃
```

### `_pop_heartbeat`

```python
def _pop_heartbeat(tool_args: dict) -> bool:
    hb = tool_args.pop("request_heartbeat", False)
    return str(hb).lower() == "true" if isinstance(hb, str) else bool(hb)
```

| 步骤 | 说明 |
|------|------|
| `dict.pop(key, default)` | **既取值又删除**——从 `tool_args` 里拿出 `"request_heartbeat"` 并从字典里删掉 |
| 字符串兼容 | 有些模型返回 `"true"`/`"false"` 字符串而非 `True`/`False` 布尔值，先判断类型再统一转 `bool` |
| 返回值 | 赋给外层 `request_heartbeat` 变量，后面用它决定 agent 是否 `continue_stepping` |

### `.pop(INNER_THOUGHTS_KWARG, None)`

| 步骤 | 说明 |
|------|------|
| `dict.pop(key, None)` | 同样是 pop，但**不关心弹出来的值** |
| `None` 兜底 | 如果这个 key 不存在，不报错、返回 None，避免 `KeyError` |
| 二次防御 | 内心独白的内容实际上在更早的地方（如 `letta/agent.py:554-555`）已经被取出来赋给 `response_message.content` 了；这里更像二次清理，确保一定从最终传给工具函数的参数里去掉 |

---

## 三、为什么一定要弹出去

`tool_args` 处理完这两行之后，**剩下的字典会被原封不动地当成关键字参数传给真正的工具函数执行**：

```python
executor.execute(function_name, function_args, ...)  # function_args 就是清理过的 tool_args
```

如果不弹出：

| 后果 | 说明 |
|------|------|
| `TypeError` | 工具函数签名里没有 `request_heartbeat` 或 `thinking` 形参，Python 直接抛 `TypeError: got an unexpected keyword argument 'request_heartbeat'` |
| 语义污染 | 即便某个工具函数恰好有同名参数（小概率），模型的"心里话"会被当成业务参数传进去 |

> [!warning] 这不是可选的清理
> 这两行 pop 是**硬性要求**——不弹就必崩。因为 `tool_args` 是从 LLM 返回的 JSON 原样解析来的，LLM 看到 schema 里有这些字段就会填值，而这些值对工具函数来说是"多余参数"。

---

## 四、数据流全景

```
LLM 收到的工具 schema（被 Letta 动态注入了额外字段）
┌──────────────────────────────────────────────┐
│  send_email(                                  │
│    to: str,           ← 真实业务参数           │
│    subject: str,       ← 真实业务参数           │
│    body: str,          ← 真实业务参数           │
│    request_heartbeat: bool,  ← Letta 控制信号  │
│    thinking: str,            ← Letta CoT 信号  │
│  )                                            │
└──────────────────────────────────────────────┘
                    │
                    ▼  LLM 填值返回
┌──────────────────────────────────────────────┐
│  tool_args = {                                │
│    "to": "alice@example.com",                 │
│    "subject": "Hello",                        │
│    "body": "Hi Alice",                        │
│    "request_heartbeat": True,  ← 假参数       │
│    "thinking": "用户让我发邮件",  ← 假参数     │
│  }                                            │
└──────────────────────────────────────────────┘
                    │
                    ▼  两行 pop 清洗
┌──────────────────────────────────────────────┐
│  request_heartbeat = True   → 给 continue_stepping 用 │
│  thinking = (丢弃)          → 已经在别处取过了        │
│                                                │
│  tool_args = {                                 │
│    "to": "alice@example.com",   ← 干净的业务参数 │
│    "subject": "Hello",                         │
│    "body": "Hi Alice",                         │
│  }                                             │
└───────────────────────────────────────────────┘
                    │
                    ▼  传给 executor.execute
            工具函数 send_email(to=..., subject=..., body=...)
            ✅ 不会 TypeError
```

---

## 快速参考卡

| 问题 | 答案 |
|------|------|
| `request_heartbeat` 是什么？ | Letta 注入每个工具 schema 的 boolean 参数，控制 agent 工具调用后是否继续自循环 |
| `thinking` 是什么？ | Letta 注入的不支持原生 reasoning 的模型的 CoT 替代品，强制模型写下"为什么这么做" |
| 为什么必须 pop？ | 不 pop 会传给工具函数导致 `TypeError: unexpected keyword argument` |
| `_pop_heartbeat` 为什么要做字符串兼容？ | 有些模型返回 `"true"` 字符串而非 `True` 布尔值 |
| `thinking` 的值 pop 后去哪了？ | 丢弃——内容在更早的地方已经取出来赋给 `response_message.content` 了 |
| 这两个字段在哪里被注入 schema？ | `anthropic_client.py`、`google_vertex_client.py` 构造工具 schema 时注入 |
| `request_heartbeat` 的值 pop 后去哪了？ | 赋给外层变量，用于决定 `continue_stepping`（agent 是否继续下一步） |

---

## 踩坑清单

1. **`request_heartbeat` 被注入到每个工具的 schema 里**：不是只有 `send_message` 才有，而是**所有工具**都有。如果自己写工具函数不小心定义了一个叫 `request_heartbeat` 的参数，会跟 Letta 注入的字段冲突——LLM 填的值会被 pop 拿走用于控制流，工具函数收不到这个值。

2. **`thinking` 在不同模型客户端的注入行为可能不同**：`anthropic_client.py` 和 `google_vertex_client.py` 会注入，但其他客户端（比如 OpenAI）可能不注入。如果代码里假设 `thinking` 一定存在，在不注入的模型上 `pop` 会安全返回 None（不报错），但下游如果依赖 `thinking` 内容做逻辑就会拿到空值。

3. **`_pop_heartbeat` 的类型兼容只处理了字符串和布尔**：如果某个模型返回了数字 `1`/`0` 或其他类型，`bool(1)` = True、`bool(0)` = False 碰巧能工作，但这是 Python 的隐式转换，不是代码显式处理的——如果模型返回 `"1"` 字符串，`str("1").lower() == "true"` 是 False，心跳信号会被误判为不续跑。

4. **pop 的顺序不能反**：`_pop_heartbeat` 内部用 `dict.pop` 拿值，如果先 `pop(INNER_THOUGHTS_KWARG)` 再 `_pop_heartbeat`，逻辑上没问题；但如果未来有人在两行之间插入依赖 `request_heartbeat` 值的代码，顺序就变得重要。当前代码里两行紧挨着，没有中间逻辑，但维护时注意不要拆开。

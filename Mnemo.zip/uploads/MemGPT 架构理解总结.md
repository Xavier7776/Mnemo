---
title: 从虚拟内存到上下文管理：MemGPT 操作系统架构设计思想
summary: 基于论文精读和架构问答，总结 MemGPT 核心设计思想、Main Context 结构、External Context、内存压力机制、Function Chaining 等
project: letta
tags: [memgpt, letta, memory, architecture, rag]
created: 2026-06-27
updated: 2026-06-27
status: completed
confidence: high
---

# 从虚拟内存到上下文管理：MemGPT 操作系统架构设计思想

> 基于论文：*MemGPT: Towards LLMs as Operating Systems*（Packer et al., 2024）

---

## 一、核心设计思想

**Q：MemGPT 的设计灵感来自哪里？核心类比是什么？**

MemGPT 借鉴操作系统的虚拟内存（virtual memory）机制：

| MemGPT 概念 | OS 类比 |
|---|---|
| Main context（prompt tokens） | 物理内存 / RAM |
| External context（外部存储） | 磁盘存储 |
| 数据在两者之间的移动 | Paging（换页） |
| LLM 对 context 的管理 | OS 对内存的管理 |

整体机制称为 **virtual context management**，目的是给有限 context window 的 LLM 提供"无限上下文"的幻觉。

---

## 二、Main Context 三部分结构

**Q：Main context 由哪三部分组成？各自的读写权限和用途是什么？**

| 部分 | 读写权限 | 写入者 | 用途 |
|---|---|---|---|
| System Instructions | 只读（静态） | 无（预设） | 存放 MemGPT 控制流说明、各内存层用途说明、function schema |
| Working Context | 可读可写 | LLM 通过 function call 写入 | 存放最核心的用户关键信息（名字、偏好、重要事件等），跨会话持久存在 |
| FIFO Queue | 可读可写 | Queue Manager 写入 | 存放滚动的消息历史，包括用户消息、LLM 回复、system messages、function call 输入输出；第一条位置固定存放递归摘要 |

---

## 三、External Context 两种存储

**Q：Recall Storage 和 Archival Storage 有什么区别？**

| | Recall Storage | Archival Storage |
|---|---|---|
| 存什么 | 历史对话消息记录 | 任意长文本对象（文档、笔记、知识库等） |
| 写入者 | Queue Manager **自动**写入 | LLM **主动** function call 写入 |
| 读取方式 | LLM function call 搜索 | LLM function call 搜索 |
| 典型场景 | 多轮对话记忆检索 | 文档分析、长期知识存储 |

**关键区别**：Recall storage 是被动积累的，对话自然产生就自动存入；Archival storage 是 LLM 主动管理的，由 LLM 自主判断何时写入。

---

## 四、两阶段内存压力机制

**Q：上下文快满时 Queue Manager 会做什么？分几个阶段？**

| 阈值 | 触发方 | 行为 |
|---|---|---|
| 70%（warning） | Queue Manager | 向 FIFO 插入 system message（内存压力警告），提示 LLM 主动用 function call 将重要内容存入 working context 或 archival storage |
| 100%（flush） | Queue Manager | 强制驱逐约 50% 的消息，用「旧递归摘要 + 被驱逐消息」生成新递归摘要写回 FIFO 第一条，被驱逐消息永久存入 recall storage |

**注意**：70% 触发的是 system message，不是 function call。是 LLM 响应警告后自主决定是否调用 function。

---

## 五、递归摘要更新机制

**Q：递归摘要是如何更新的？"递归"体现在哪里？**

每次 flush 时：

```
旧递归摘要 + 被驱逐的消息 → LLM → 新递归摘要
```

"递归"的含义：每次生成新摘要时，都把上一次的摘要也纳入输入，保证历史信息不会因多次清理而层层丢失。新摘要写回 FIFO 队列第一条位置。

---

## 六、Function Executor 与 Completion Tokens

**Q：LLM 输出的 completion tokens 是如何被处理的？**

1. LLM 输出内容**永远是 function call 格式的字符串**（不是直接的自然语言）
2. **Function Executor** 解析输出，验证 function 名称和参数合法性
3. 验证通过后执行对应 function
4. 执行结果（包括报错）写回 main context，形成反馈闭环
5. 判断控制流：有 `request_heartbeat=true` → 立刻再次触发推理；否则等待下一个 event

**注意**：LLM 想回复用户也要通过 `send_message()` function 实现。

---

## 七、Function Chaining

**Q：Function Chaining 解决什么问题？如何触发？**

**解决的问题**：很多任务需要连续调用多个 function 才能完成（如多跳检索、翻页搜索），如果每次都要等用户消息才能继续则无法完成。Function chaining 让 LLM 在不返回给用户的情况下连续执行多个 function。

**触发机制**：LLM 在 function call 中带上 `request_heartbeat=true` 参数，MemGPT 执行完该 function 后立刻将结果写回 main context 并再次触发 LLM 推理。

**不带该参数（yield）**：MemGPT 等待下一个外部 event 才会再次推理。

---

## 八、Event 驱动的控制流

**Q：MemGPT 中有哪几种 event 类型？**

1. **User messages**：用户发送消息
2. **System messages**：系统内部产生的消息（如内存压力警告、文档上传完成通知）
3. **User interactions**：用户行为事件（如用户登录、用户完成文档上传）
4. **Timed events**：按固定时间表自动触发，**不需要用户任何操作**，允许 MemGPT 自主运行

---

## 九、完整消息处理流程

从用户发送一条消息到 MemGPT 返回回复的完整流程：

```
用户消息
   ↓
Queue Manager 接收 → 自动写入 recall storage
   ↓
检查 token 数量（70% 警告 / 100% flush）
   ↓
拼接完整 prompt tokens → 触发 LLM Processor 推理
   ↓
LLM 输出 completion tokens（function call 格式）
   ↓
Function Executor 解析并执行 function
   ↓
执行结果写回 main context
   ↓
有 request_heartbeat=true？
   ├── 是 → 再次触发 LLM 推理（function chaining）
   └── 否 → 等待下一个 event
   ↓
LLM 调用 send_message() → 返回给用户
```

---

## 十、MemGPT vs 传统 RAG

| | 传统 RAG | MemGPT |
|---|---|---|
| 检索触发 | 每次提问自动检索 | LLM 自主决定何时检索 |
| 检索次数 | 单次 | 可多次、翻页、多跳 |
| 写入外部存储 | 通常只读 | LLM 可主动写入 |
| 上下文管理 | 固定塞入 context | 动态分层管理 |
| 控制权 | 系统控制 | LLM 自主控制 |

**本质区别**：传统 RAG 是系统驱动的被动检索，MemGPT 是 LLM 自主驱动的主动记忆管理。

---

## 十一、局限性

- **延迟**：function chaining 导致多轮 LLM 推理，响应时间显著增加
- **成本**：多轮推理 + 完整 prompt tokens，token 消耗远高于普通对话
- **检索质量瓶颈**：依赖向量相似度搜索，LLM 有时会在找到答案前就停止翻页
- **LLM 能力依赖**：系统高度依赖 function calling 能力，能力弱的模型（如 GPT-3.5）性能大幅下降
- **Working context 容量固定**：核心用户信息存储空间有限，复杂用户信息会成为瓶颈

---

*总结整理于 2026 年 6 月，基于论文精读和架构问答。*
---
title: Agent自压缩：Prompt Cache复用与三级降级兜底的上下文管理机制
summary: Letta 中 "Claude Code 风格" self-summarize 的核心函数 self_summarize_all 完整解析，包括三级降级链条、滑动窗口变体、token 计数机制
project: letta
tags: [letta, summarizer, self-compact, context-window, prompt-cache, source-code]
created: 2026-07-03
updated: 2026-07-03
status: completed
confidence: high
---

# Agent自压缩：Prompt Cache复用与三级降级兜底的上下文管理机制

## 一句话概括

`self_summarize_all` 做的事情：**不用一个独立的"总结器 LLM"去看对话记录写摘要，而是让 agent 自己的 LLM（带着自己的 system prompt、工具定义、prompt cache）在对话末尾追加一条"请总结"的 user 消息，把自己"骗"成继续对话一样生成一段总结文本**——这样可以复用 prompt cache，总结风格也更贴近 agent 本身（这正是 Claude Code 用的套路，注释里也写了 "Claude Code-style summarization"）。

---

## 完整流程

### 上游触发（`compact.py` 的 `compact_messages`）

1. 当 `compaction_settings.mode == "self_compact_all"` 时才会走到这个函数（还有 `self_compact_sliding_window`、`all`、`sliding_window` 三种模式）。
2. 外层用 `build_summarizer_llm_config` 决定总结用哪个模型（但注意：`self_summarize_all` 这条路径其实**不用**这个单独配置的总结模型，而是直接用 `agent_llm_config`——也就是 agent 自己的模型，这是"self"模式和其他模式最本质的区别）。
3. 如果 `self_summarize_all` 抛异常 → 降级到 `self_summarize_sliding_window` → 再失败 → 最终兜底到独立总结模型的 `summarize_all`。

### `self_summarize_all` 内部步骤

1. **保护消息切分**（`_get_protected_messages`）：第一条 system message 永远保留；如果最后一条消息是 `approval`（等待批准的工具调用），连同它和它对应的那条 assistant 消息（同一个 `step_id`）一起保护起来不参与总结——否则客户端会因为孤立的 approval 请求报错。

2. **构造总结请求消息**：
   - 用 `compaction_settings.prompt`（没设的话用 `SELF_ALL_PROMPT` 默认提示词，内容大意是"详细总结对话，不要继续对话/回答问题/调用工具，要保留技术细节、代码模式、架构决策"）包成一条 `role=user` 的消息。
   - 如果待总结消息列表的最后一条不是 assistant 消息，会插入一条假的 `"I understand. Let me summarize."` assistant 消息占位，防止 LLM 顺着最后一条消息把对话继续下去，然后再接总结请求。

3. **设置遥测上下文**：把 `agent_id`、`run_id`、`step_id`、`call_type="summarization"` 等塞进 `llm_client`，方便后续追踪这次调用是"总结"而不是正常一步。

4. **构造请求体**（`llm_client.build_request_data`）：关键在于用的是 `agent_type` + `agent_llm_config` + agent 原本的 `tools`，刻意"复刻"正常 agent 请求的参数结构，目的是**命中 prompt cache**（尤其是 Anthropic/Bedrock，还专门对齐了 `parallel_tool_calls`/`disable_parallel_tool_use` 这类细节，保证 cache key 一致）。
   - `force_tool_call=None`：不强制模型调工具，让它老老实实输出总结文本。

5. **发起请求**（`_run_summarizer_request` → `_execute_summarizer_request`）：
   - Anthropic/Bedrock 走**流式**（因为超长请求可能超过 provider 的非流式超时限制），累积文本内容。
   - 其他 provider 走非流式，转成 chat completion 格式取 `content`。
   - 如果失败，会尝试 `llm_client.handle_llm_error` 转换成明确的错误类型（比如 context window 超限），并有 provider 过载时的降级重试（Anthropic→Bedrock、ZAI→Baseten）。

6. **裁剪**：如果总结文本超过 `compaction_settings.clip_chars`，直接硬截断并加后缀。

7. **拼装最终消息列表**：`[system_message] + protected_messages`（不包括总结文本本身——插入 summary message 这一步是在上一层 `compact_messages` 里做的，用 `role=summary` 或 `role=user` 包装后拼接：`[system, summary_message, ...protected_messages]`）。

---

## 三级降级链条

```
try:
    self_summarize_all(...)                    # 第1级:agent自己的LLM,一次性总结全部历史
except Exception:
    try:
        self_summarize_sliding_window(...)      # 第2级:agent自己的LLM,滑动窗口
    except Exception:
        summarize_all(...)                      # 第3级:独立总结模型,一次性总结
```

### 第2级：`self_summarize_sliding_window`

**触发时机**：第1级 `self_summarize_all` 抛异常了（比如超长历史导致 agent 自己模型的上下文窗口都装不下"全部历史+总结请求"）。

**做了什么**：
- `fallback_config` 是把 `mode` 改成 `"self_compact_sliding_window"`、`prompt` 换成对应默认提示词（`SELF_SLIDING_PROMPT`）后的配置副本。
- 仍然用 **agent 自己的 LLM**（`agent_llm_config` / `llm_client` / `agent_type` / `tools` 都没变），但不再一口气总结全部消息，而是走滑动窗口逻辑：
  - 从后往前找一个 assistant/approval 边界作为 cutoff，按 `sliding_window_percentage` 逐步增大驱逐比例，边算 token 边找，直到 cutoff 之前的部分能塞进目标 token 预算。
  - cutoff **之前**的部分丢给 `self_summarize_all` 去总结（内部复用第1级的函数，但输入消息量小了很多，更不容易再超限）。
  - cutoff **之后**的部分原样保留（`post_summarization_buffer`），拼回最终消息列表。
- 之所以先降级到这一步而不是直接跳到"all"模式，是因为**注释里写的**：两种 self 模式提示词风格接近，而且都能保留"agent 自己视角"的总结质感，优先级比换模型高。
- 成功后 `summarization_mode_used = "self_compact_sliding_window"`，记录这次实际用的是第2级策略。

### 第3级：`summarize_all`（fallback 到 `"all"` 模式）

**触发时机**：第2级 `self_summarize_sliding_window` 也失败了（比如即使砍到只剩很少的近期消息，单条消息本身也超限，或者根本找不到合法的 assistant/approval cutoff 点）。

**做了什么**（和前两级本质不同）：
1. `fallback_config` 直接把 `mode` 设为 `"all"`，`prompt` 换成通用的 `ALL_PROMPT`（不再是"self"系列提示词）。
2. 调用的是**完全独立的总结路径**——`summarize_all` 内部走的是 `simple_summary`：
   - 用的不是 agent 的 `llm_client`/`agent_llm_config`，而是外层预先算好的 `summarizer_llm_config`（前面 `build_summarizer_llm_config` 挑的轻量总结模型，比如 Haiku）。
   - **不复用 agent 的 system prompt 和工具定义**，而是新建一个极简的 system+user 结构：`system=ALL_PROMPT`，可选一条 assistant ACK 消息，再加一条 `user` 消息，内容是 `simple_formatter(messages)` 把消息列表拍平成的**纯文本 transcript**（不是原始 Message 对象序列，不走 prompt cache，不带 tools）。
   - 因为完全脱离了 agent 原有的消息结构和 prompt cache，payload 更"干净"、更小，兜底成功率最高——这是三级里"最保险但成本最高（丢失 cache，总结质感也和 agent 本身脱节）"的一级。
3. 成功后 `summarization_mode_used = "all"`，告诉外层最终实际用的是完全独立总结模型完成的压缩。

### 降级链设计思路

**优先级 = "尽量像 agent 自己在总结"（省钱、复用 cache、风格一致）> "换个更保守的窗口大小但还是 agent 自己" > "彻底换成外部小模型硬总结，保证无论如何都能压下去"**，层层兜底，防止因为总结本身失败而把 agent 直接"炸"死在上下文超限上。

---

## `self_summarize_sliding_window` vs `summarize_via_sliding_window`

两者算法思路几乎一样（都是"从后往前找 assistant/approval 边界作为 cutoff，逐步增大驱逐比例直到 cutoff 之前的部分能塞进目标 token 预算"），但本质区别是**用谁的 LLM 来生成摘要文本**：

| | `self_summarize_sliding_window` | `summarize_via_sliding_window` |
|---|---|---|
| 归属模式 | `self_compact_sliding_window` | `sliding_window`（经典模式） |
| 用哪个 LLM 生成摘要 | **agent 自己的模型**（`agent_llm_config` + `llm_client`） | **独立配置的总结模型**（`llm_config` = 外层挑好的 `summarizer_llm_config`，可能是 Haiku 等轻量模型） |
| 摘要生成方式 | 把"总结请求"当作一条 user 消息**追加到原始对话消息序列末尾**，让 agent 用带 `tools`、原 system prompt 的完整请求结构去回答→复用 prompt cache（内部调 `self_summarize_all` 完成） | 把待总结消息**拍平成纯文本 transcript**（`simple_formatter`），塞进一个全新的极简 `system + [assistant ACK] + user` 三段式请求里（内部调 `simple_summary`），不带 tools，不复用 agent 的 cache |
| 需要 `tools` 参数吗 | 需要（为了跟 agent 正常请求的结构对齐，命中 cache） | 不需要 |
| 需要 `agent_type` 吗 | 需要（`build_request_data` 要按 agent 类型构造请求） | 不需要 |
| cutoff 计算用谁的 context_window | 都是用 `agent_llm_config.context_window` 算目标 token 数（这个没区别，因为最终省下来的空间要给 agent 自己用） | 同左 |

**一句话总结**：`sliding_window`（无 self）是"另找一个便宜模型，把对话转成纯文本喂给它总结"；`self_compact_sliding_window` 是"agent 自己在自己的对话历史后面加一句'请总结'，用自己的原生请求格式生成总结"。前者更省钱、更稳（不受 agent 模型本身上下文限制），后者总结质量/风格更贴合 agent 本身、能吃 prompt cache 但更容易在超大历史时也超限。这也解释了为什么降级顺序是 `self_compact_all → self_compact_sliding_window → all`——最后兜底一定是最不依赖 agent 自身上下文能力的 `all`（用独立小模型+纯文本）。

---

## `count_tokens_with_tools` 是怎么算的

它算的是**"总结/裁剪之后，这批消息+工具定义，如果原样发给 agent 的模型，大概会占用多少 token"**，分两部分相加：

```python
message_tokens = await count_tokens(actor, llm_config, messages)   # 消息部分
tool_tokens = await token_counter.count_tool_tokens(tool_definitions)  # 工具schema部分
return message_tokens + tool_tokens
```

### 消息部分 `count_tokens`

根据 `llm_config.model_endpoint_type` 用工厂函数 `create_token_counter` 选一个具体的计数器：

| Provider | 计数方式 |
|----------|----------|
| **Anthropic** | 直接调 Anthropic 官方的 `count_tokens` API（真实、精确的 token 数），会先把 `Message` 对象转成 Anthropic 格式的 dict，还带了 Redis 缓存（按内容 hash 缓存 1 小时，避免重复计算） |
| **Google Vertex/AI** | 用 Gemini 自己的 token 计数接口 |
| **其它 provider（OpenAI 等）** | 走 `ApproxTokenCounter`——**近似估算**，做法很粗暴：把消息序列化成 JSON 字符串，按 UTF-8 字节数除以 4（`bytes/4`，和 codex-cli 用的启发式一样），而不是真的跑一遍 tokenizer |

> **注意**：近似估算通常会**低估** 25%~35%（JSON 里的括号、引号、冒号等结构字符也会变成 token，但字节估算法没算进去），所以外面又乘了个 `APPROX_TOKEN_SAFETY_MARGIN = 1.3` 的安全系数进行放大修正。

### 工具部分 `count_tool_tokens`

先把传入的 `tools`（可能是 `Tool` 对象带 `.json_schema`，也可能是原始 dict）统一转成 OpenAI 风格的 `FunctionTool` schema 列表，再用同一个 `token_counter` 去数：
- Anthropic 走真实 API（`count_tokens(tools=...)`）
- 其它走同样的"JSON 序列化后按字节估算"逻辑，同样应用 1.3 倍安全系数

### 为什么要单独算 tools 的 token

因为工具定义（函数名、参数 schema、描述）是**每次请求都会附带发给模型的**，但它不在 `messages` 列表里，如果只数消息 token 会明显低估真实 prompt 大小——尤其是 agent 挂了很多工具的情况下，tools schema 本身可能就占掉几千 token。

所以 `compact_messages` 在总结完之后，要用 `count_tokens_with_tools` 而不是普通 `count_tokens`，才能跟触发压缩的 `trigger_threshold`（它本身通常也是按"消息+工具"的真实 prompt 大小算出来的）做一致的比较，判断这次总结是否真的把上下文压下去了。

---

## 相关笔记

- [[Agent每步执行的控制链]] - Agent Loop 主循环解析
- [[Agent两步推理追踪]] - Step 循环完整示例
- [[推理前上下文准备]] - 上下文消息准备机制

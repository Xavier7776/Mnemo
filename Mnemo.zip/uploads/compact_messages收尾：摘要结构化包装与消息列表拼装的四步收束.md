---
title: compact_messages收尾：摘要结构化包装与消息列表拼装的四步收束
summary: compact_messages 收尾阶段完整解析：package_summarize_message_no_counts 的 system_alert 包装、use_summary_role 新旧行为切换、final_messages 插装逻辑、CompactResult 四个字段的各自用途
project: letta
tags: [letta, summarizer, compact, message-role, system-alert, source-code]
created: 2026-07-03
updated: 2026-07-03
status: completed
confidence: high
---

# compact_messages收尾：摘要结构化包装与消息列表拼装的四步收束

## 一句话概括

`compact_messages` 收尾阶段的核心任务：把前面各策略产出的**纯文本摘要**包装成一条带身份的 `Message` 对象，插到 `system_message` 之后、剩余消息之前，拼出压缩后要写回 agent 的新上下文，最后用 `CompactResult` 把四个关键产物统一返回给调用方。

---

## 1. 整体流程

```
纯文本 summary 文本
        │
        ▼
┌─────────────────────────────────────┐
│ 第一步：package_summarize_message   │
│ _no_counts                          │
│  → 生成 system_alert JSON 字符串    │
└─────────────────────────────────────┘
        │
        ▼
┌─────────────────────────────────────┐
│ 第二步：构造 Message 对象           │
│  → use_summary_role=True:           │
│    role="summary"（新行为）          │
│  → use_summary_role=False:          │
│    role="user"（legacy 兼容）        │
└─────────────────────────────────────┘
        │
        ▼
┌─────────────────────────────────────┐
│ 第三步：拼装 final_messages         │
│  = [system, summary, ...剩余]       │
└─────────────────────────────────────┘
        │
        ▼
┌─────────────────────────────────────┐
│ 第四步：返回 CompactResult          │
│  {summary_message, compacted_msgs,  │
│   summary_text, token_estimate}     │
└─────────────────────────────────────┘
```

---

## 2. 第一步：`package_summarize_message_no_counts`——摘要的结构化包装

**源码位置**：`letta/system.py`

```python
summary_message_str_packed = package_summarize_message_no_counts(
    summary=summary, timezone=timezone,
    compaction_stats=compaction_stats, mode=summarization_mode_used,
)
```

### 2.1 根据 mode 选提示语

| mode 类型 | 提示语文案 | 是否给驱逐条数 |
|-----------|-----------|:---:|
| 含 `"sliding_window"`（`sliding_window` / `self_compact_sliding_window`） | "前面 N 条消息因为内存限制被隐藏了，以下是摘要" | ✅ 用 `compaction_stats.messages_count_before/after` 算出差值 |
| `all` / self 全量模式 | "之前的消息因为内存限制被隐藏了，以下是摘要" | ❌ 不给具体条数（几乎所有历史都被摘要了，给数量无意义） |

### 2.2 加时间戳 + 打包成 JSON

```json
{
  "type": "system_alert",
  "message": "前面 3 条消息因为内存限制被隐藏了，以下是摘要：\n{summary正文}",
  "time": "2026-07-03 15:30:00 CST",
  "compaction_stats": {
    "messages_count_before": 12,
    "messages_count_after": 9,
    "token_estimate_before": 4500,
    "token_estimate_after": 1200
  }
}
```

> [!note] 设计意图
> 摘要不是以"裸文本"塞进消息里的，而是包成 Letta 惯用的 `system_alert` 结构化格式。agent 解析时能识别出"这是系统级提示，不是用户真实说的话"，还能把压缩统计（压缩了多少 token/消息）透传给 agent 自己参考。

---

## 3. 第二步：`use_summary_role`——新旧行为切换

### 3.1 `use_summary_role=True`（新行为，推荐路径）

```python
summary_message_obj = Message(
    role=MessageRole.summary,
    content=[TextContent(text=summary_message_str_packed)],
    agent_id=agent_id, run_id=run_id, step_id=step_id,
)
```

| 维度 | 说明 |
|------|------|
| **角色** | `MessageRole.summary`，与 `user`/`assistant`/`system`/`tool`/`approval` 并列的新枚举值 |
| **语义** | 数据库/前端能明确区分"这是自动生成的摘要"，方便 UI 折叠显示、"已压缩"标签 |
| **发给 LLM** | `Message.to_*_dicts` 里有专门分支，可转成 user 角色（`convert_summary_to_user` 控制），但存储层保留 `summary` 身份 |
| **过滤便利** | `m.role not in (MessageRole.system, MessageRole.summary)` 精确排除摘要，不误当正常对话 |

### 3.2 `use_summary_role=False`（legacy 行为）

```python
summary_messages = await convert_message_creates_to_messages(
    message_creates=[MessageCreate(
        role=MessageRole.user,
        content=[TextContent(text=summary_message_str_packed)]
    )],
    agent_id=agent_id, timezone=timezone,
    wrap_user_message=False, wrap_system_message=False,
    run_id=run_id,
)
```

老版本没有 `summary` 角色，只能伪装成 `role=user`。关键参数：
- `wrap_user_message=False` / `wrap_system_message=False`：关掉二次包装（第一步已手工拼好完整 `system_alert` 结构，不需要再加时间戳/"来自用户"标记）
- `if len(summary_messages) != 1: logger.error(...)`：防御性检查，只传入了一条 `MessageCreate`，正常情况返回恰好一条

> [!warning] 新旧对比
> 
> | | `summary_role=True` | `summary_role=False` |
> |---|---|---|
> | 角色 | `MessageRole.summary` | `MessageRole.user` |
> | 语义区分 | ✅ 数据库/前端/代码过滤均可精确识别 | ❌ 混在 user 消息里 |
> | 发给 LLM | 可控转换（`convert_summary_to_user`） | 直接就是 user |
> | 状态 | 推荐/默认 | 兼容旧客户端/旧数据 |

---

## 4. 第三步：拼装 `final_messages`

```python
final_messages = [compacted_messages[0], summary_message_obj]
if len(compacted_messages) > 1:
    final_messages += compacted_messages[1:]
```

`compacted_messages` 的前置约定（由各总结策略统一保证）：

```
[system_message, ...保留下来没被摘要掉的消息...]
```

拼装结果：

```
[system_message, summary_message, ...剩余未被摘要的消息]
```

| 序号 | 元素 | 说明 |
|------|------|------|
| `[0]` | `system_message` | 原始 system prompt，不动 |
| `[1]` | `summary_message` | 新插入的摘要（system_alert 格式） |
| `[2:]` | 剩余消息 | 被保护的 approval / 滑动窗口保留的近期消息 |

---

## 5. 第四步：返回 `CompactResult`

```python
return CompactResult(
    summary_message=summary_message_obj,
    compacted_messages=final_messages,
    summary_text=summary,
    context_token_estimate=context_token_estimate,
)
```

| 字段 | 类型 | 用途 |
|------|------|------|
| `summary_message` | `Message` | 摘要 Message 对象本身，调用方可单独持久化/记日志/展示 |
| `compacted_messages` | `list[Message]` | **真正落库**的消息列表，替换 agent 的 in-context messages |
| `summary_text` | `str` | 摘要原始纯文本（无 JSON 包装），方便别处直接引用 |
| `context_token_estimate` | `int` | 压缩后重新估算的 token 数，外层用于判断是否降到 `trigger_threshold` 以下 |

> [!note] `context_token_estimate` 的用途
> 这是 `count_tokens_with_tools` 算出的值。调用方拿到后与 `trigger_threshold` 比较：
> - 如果仍超阈值 → 继续压缩（比如从 `self_summarize_all` 降级到下一级）
> - 如果已低于阈值 → 压缩完成，用 `compacted_messages` 覆盖 agent 上下文

---

## 快速参考卡

| 问题 | 答案 |
|------|------|
| 摘要文本如何塞进消息？ | `package_summarize_message_no_counts` 包装成 `system_alert` JSON |
| summary 角色的意义？ | 存储/过滤/UI 上区分"自动生成摘要"和"真实对话" |
| 摘要插在消息列表什么位置？ | system 之后、剩余消息之前：`[system, summary, ...rest]` |
| `CompactResult` 四个字段的用途？ | `compacted_messages` 落库；`summary_message` 单独展示；`summary_text` 纯文本引用；`token_estimate` 阈值判断 |
| legacy 兼容路径的关键参数？ | `wrap_user_message=False, wrap_system_message=False` 避免二次包装 |

---

## 踩坑清单

1. **legacy 路防御性检查不够严格**：`if len(summary_messages) != 1: logger.error(...)` 只记日志不抛异常，如果转换逻辑真的出了 bug 返回了空列表，`summary_messages[0]` 会 IndexError 直接炸——应该加 `if not summary_messages: raise` 兜底。
2. **`compacted_messages[0]` 必须是 system message**：这是各策略函数的前置约定，但收尾代码没有显式校验——万一某个策略没遵守这个约定，`final_messages` 的结构就乱了。
3. **`compaction_stats` 为 None 时 sliding_window 提示语不给条数**：如果调用方传了 `compaction_stats=None`，sliding_window 模式也不会报错，只是提示语里不写具体驱逐条数——静默降级，排查时容易忽略。

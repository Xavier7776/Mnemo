---
title: Step循环完整调用链：消息列表分工、请求构建与响应解析
summary: 基于 letta/agents/letta_agent.py，覆盖 step loop 完整调用链、消息列表分工、LLM 请求构建、响应解析、_handle_ai_response 执行流程
project: letta
tags: [letta, agent-loop, step, source-code, memory, llm]
created: 2026-06-29
updated: 2026-06-29
status: completed
confidence: high
---

# Step循环完整调用链：消息列表分工、请求构建与响应解析

> 基于 `letta/agents/letta_agent.py` 及相关模块

---

## 一、整体架构

一次用户请求的完整生命周期：

```
用户输入
  ↓
get_agent_by_id                    → 加载 agent 配置（tools/memory/llm_config）
  ↓
_prepare_in_context_messages       → current = DB历史, new = 用户输入(未持久化)
  ↓
ToolRulesSolver / LLMClient        → 初始化工具规则和LLM客户端
  ↓
for i in range(max_steps):         → Step Loop
    ↓
    _build_and_request_from_llm    → 构建请求 + 发给LLM
    ↓
    convert_response_to_chat_completion → 解析LLM响应
    ↓
    _handle_ai_response            → 执行工具 + 持久化 + 决定是否继续
    ↓
    should_continue ?              → True继续, False退出loop
```

---

## 二、两个核心列表

```python
current_in_context_messages  # 已持久化在 DB 的历史消息（agent 的"记忆"）
new_in_context_messages      # 本次对话新产生的消息（用户输入 + 本轮LLM生成）
```

两者分开维护，只在需要喂给 LLM 时拼接：

```python
in_context_messages = current_in_context_messages + new_in_context_messages
```

### 为什么分开？

**① 错误恢复时的边界清晰**

上下文超长触发压缩时，summarizer 知道哪些是可以压缩的老历史（current），哪些是本次对话必须保留的（new），不会把用户刚发的消息压缩掉。

**② 去重逻辑**

`initial_messages` 是第一个 step 前 new 的快照，`persisted_messages[new_message_idx:]` 跳过已有消息，只追加新生成的部分。

**③ step loop 中的增长规律**

```
step 1 结束后：new = [userA, asst_B, tool_C]
step 2 结束后：new = [userA, asst_B, tool_C, asst_D, tool_E]
step 3 结束后：new = [userA, asst_B, tool_C, asst_D, tool_E, asst_F]
```

### 防止无限膨胀的机制

| 机制 | 说明 |
|------|------|
| `ContextWindowExceededError` 重试 | 超长时自动压缩历史，summarizer 将 current 压成 summary 消息 |
| `message_buffer_autoclear` | 开启后每次只保留 system message，current 永远不膨胀 |
| `max_steps` 硬上限 | 单次请求最多走 N 个 step |
| long-term memory 卸载 | 重要信息写入向量 DB，不留在 context |

---

## 三、`_build_and_request_from_llm`

### 职责

把"构建上下文 → 构建请求体 → 发请求给 LLM"打包成一个带重试的原子操作。

### 重试机制

```python
for attempt in range(self.max_summarization_retries + 1):
    try:
        ...
    except Exception as e:
        if attempt == self.max_summarization_retries:
            raise e
        current_in_context_messages = await self._handle_llm_error(...)
        new_in_context_messages = []   # 已合并进 current，清空
```

错误处理分支：

- `ContextWindowExceededError` → `_rebuild_context_window` → `summarizer.summarize()` 压缩历史
- `LLMError` → 直接 raise
- 其他 → `llm_client.handle_llm_error` 包装后 raise

压缩前后对比：

```
压缩前 current: [sys, user1, asst1, user2, asst2]  new: [userA]
压缩后 current: [sys, summary, userA]               new: []
```

---

## 四、`_create_llm_request_data_async`

### 四个步骤

**① `_rebuild_memory_async` — 刷新 system message**

从 DB 拉最新 memory blocks，与当前 `current[0]` 对比，有变化则重写 system message 并更新 DB。

```python
# 检测到 memory 变化
curr_memory_str = agent_state.memory.compile(...)
if curr_memory_str not in curr_system_message_text:
    # 重建 system message 并写 DB
    new_system_message = await self.message_manager.update_message_by_id_async(...)
    return [new_system_message, *in_context_messages[1:]]
```

**② `scrub_inner_thoughts_from_messages` — 清理思考文本**

reasoning 禁用时，剔除历史 assistant 消息里的 TextContent，只保留 tool_calls：

```python
# 禁用 reasoning 时
msg.content = []         # TextContent 被移除
msg.tool_calls = [...]   # 保留
```

**③ `ToolRulesSolver.get_allowed_tool_names` — 计算本轮可用工具**

| 规则类型 | 作用 |
|----------|------|
| `InitToolRule` | 第一次 tool call 只能用指定工具 |
| `ChildToolRule` | 上一个工具完成后允许哪些工具 |
| `ConditionalToolRule` | 根据工具返回值动态决定 |
| `TerminalToolRule` | 调用后终止 agent loop |
| `ParentToolRule` | 过滤掉某些工具 |
| `RequiredBeforeExitToolRule` | 退出前必须调用的工具 |

所有规则取交集。只剩一个合法工具时设 `force_tool_call`，强制 LLM 调用它。

**④ `llm_client.build_request_data` — 转成 provider 格式**

`to_openai_dict` 转换规则：

| Letta role | OpenAI role |
|------------|-------------|
| system | system / developer（o1系列） |
| user | user |
| summary | user |
| assistant | assistant |
| approval（无tool_call） | 过滤掉（返回None） |

---

## 五、LLM 响应解析

### `convert_response_to_chat_completion`

做五件事：

| 步骤 | 说明 |
|------|------|
| 格式适配 | OpenAI Responses API（output[]）vs Chat Completions API（choices[]）分别处理 |
| 空响应检测 | content=None 且无 tool_calls → 抛 `LLMEmptyResponseError` |
| 截断 JSON 修复 | 补全缺失的引号和大括号 |
| inner thought 解包 | `put_inner_thoughts_in_kwargs` 模式下从 arguments 里解包回 content |
| reasoning_content 提取 | 兼容 vLLM/OpenRouter 代理的字段名差异 |

### reasoning 多 provider 适配

```python
有 reasoning_content          → ReasoningContent(is_native=True)   # Claude
有 content（无 reasoning）    → TextContent                         # 旧模型 legacy
omitted_reasoning_content     → OmittedReasoningContent()           # o1/o3
都没有但有 signature          → TextContent(text="", sig)           # Gemini
都没有                        → None
```

Gemini 特殊处理：哪怕思考内容为空，signature 也必须保留，否则下次请求报 `400 INVALID_ARGUMENT`。

---

## 六、`_handle_ai_response`

### 职责

执行工具、决定是否继续 loop、持久化消息到 DB。

### 五个步骤

**① 解析 tool_call 参数**

```python
tool_call_name = tool_call.function.name
tool_args = _safe_load_tool_call_str(tool_call.function.arguments)  # 容错JSON解析
request_heartbeat = _pop_heartbeat(tool_args)    # 弹出，不传给工具
tool_args.pop(INNER_THOUGHTS_KWARG, None)        # 弹出，不传给工具
```

**② 执行工具（三条分支）**

```
需要人工审批  → 创建 approval_request 消息，停止 loop
违反 tool rules → 构造错误结果，强制继续（让LLM知道它选错了）
正常执行      → _execute_tool → ToolExecutionManager
```

**③ 处理工具返回值**

```python
function_response_string = validate_function_response(
    tool_execution_result.func_return,
    return_char_limit=return_char_limit,
    truncate=truncate,   # 搜索类工具不截断
)
self.last_function_response = package_function_response(...)
# 供下一轮 ConditionalToolRule 判断用
```

**④ `_decide_continuation` — 决定是否继续 loop**

优先级从高到低：

```
tool_rule_violated      → 强制继续
is_terminal_tool        → 强制停止
has_children_tools      → 强制继续
is_continue_tool        → 强制继续
request_heartbeat=True  → 继续
request_heartbeat=False → 停止
--- 硬覆盖 ---
is_final_step=True      → 无论如何停止（max_steps）
uncalled required tools → 强制继续
```

**⑤ 创建消息并持久化**

本轮产生两条消息：

```python
# assistant 消息
Message(
    role="assistant",
    content=[TextContent(text="内心独白...")],  # reasoning_content
    tool_calls=[ToolCall(name="get_weather", arguments="{...}")]
)

# tool 消息
Message(
    role="tool",
    content=[ToolReturnContent(content="晴天25°C", status="success")],
    tool_call_id="call_abc123"
)
```

拼接规则：

```python
# 第一个 step
messages_to_persist = [userA] + [asst_B, tool_C]   # initial_messages + 本轮消息

# 后续 step
messages_to_persist = [] + [asst_D, tool_E]         # initial_messages=None
```

批量写入 DB 后返回 `persisted_messages`，追加进 `new_in_context_messages`。

---

## 七、可观测性体系

Letta 有三层可观测性，互相独立不影响业务：

| 层级 | 实现 | 存什么 |
|------|------|--------|
| OTel Metrics | `MetricRegistry().message_output_tokens.record(...)` | token 数、耗时等数值指标，推 Prometheus/Datadog |
| OTel Tracing | `agent_step_span.add_event(...)` | 请求链路 span |
| Provider Trace | `telemetry_manager.create_provider_trace_async(...)` | 完整 request_data + response_data，存 DB |

`get_ctx_attributes()` 从 Python `ContextVar` 取当前请求的标签（project_id、agent_id 等），由 HTTP 中间件在请求进来时设置。

---

## 八、ID 体系

| ID | 粒度 | 用途 |
|----|------|------|
| `run_id` | 异步 Job 级别 | 取消任务、计费归属、关联 usage 统计 |
| `current_run_id` | agent 实例级别 | 同 run_id，挂在 agent 上 |
| `step_id` | 单次 LLM 调用级别 | 每个 for 循环迭代生成一个 |
| `effective_step_id` | step_id 的安全版 | step 写 DB 失败时为 None，避免使用不存在的 ID |

层级关系：

```
一次用户请求
└── run_id（可选，异步后台任务才有）
    ├── step_id_1（第1次LLM调用）
    ├── step_id_2（第2次LLM调用）
    └── step_id_3（第3次LLM调用）
```

---

## 九、完整调用链

```
_build_and_request_from_llm
│
├── [loop] attempt 0..max_retries
│   ├── _create_llm_request_data_async
│   │   ├── _rebuild_memory_async          ← 刷新 system prompt
│   │   ├── scrub_inner_thoughts           ← 清理思考文本
│   │   ├── get_allowed_tool_names         ← 计算合法工具集
│   │   └── build_request_data             ← 转 OpenAI 格式
│   │
│   ├── request_async_with_telemetry       ← 发请求 + 记遥测
│   │
│   └── [on error] _handle_llm_error
│       └── _rebuild_context_window
│           └── summarizer.summarize()     ← 压缩历史
│
convert_response_to_chat_completion        ← 解析响应 + 多格式适配
│
_handle_ai_response
├── 解析 tool_call 参数
├── 执行工具（审批/规则违反/正常执行）
├── 处理返回值
├── _decide_continuation                   ← 决定 should_continue
├── create_letta_messages_from_llm_response
└── create_many_messages_async             ← 批量持久化到 DB
```

---
title: Recall Memory混合检索：双入口架构、Turbopuffer降级与RRF分数融合
summary: Letta 模块四 Recall Memory 源码学习总结，覆盖 Message vs Passage 区别、Agent 级 vs 组织级双检索入口、Turbopuffer 降级策略、vector_rank/fts_rank/rrf_score 融合公式
project: letta
tags: [letta, recall-memory, hybrid-search, turbopuffer, rrf, bm25, vector-search, source-code]
created: 2026-07-03
updated: 2026-07-03
status: completed
confidence: high
---

# Recall Memory混合检索：双入口架构、Turbopuffer降级与RRF分数融合

## 一句话概括

Recall Memory 不是简单的关键词搜索，而是**向量语义检索 + 全文检索（FTS/BM25）+ RRF 分数融合**的混合检索，底层依赖 Turbopuffer；未启用 Turbopuffer 时退化为纯 SQL 查询。检索对象是 `Message`（对话流水账），不是 `Passage`（Archival 知识条目）。

---

## 1. Message vs Passage 的本质区别

| 维度 | Message | Passage |
|------|---------|---------|
| **源码位置** | `letta/schemas/message.py`（2710 行，无需通读） | `letta/schemas/passage.py` |
| **存的是什么** | 对话历史本身——已发生的对话记录 | 主动写入 Archival Memory 的知识片段 |
| **核心字段** | `role`（user/assistant/tool/approval 等）、`content`、`tool_calls`、`step_id`、`created_at` | `text`、`embedding`、`embedding_config`、`tags`、`archive_id` |
| **产生方式** | 自动产生的对话流水账 | LLM 主动决定要长期保存的精选内容 |
| **检索归属** | **Recall Memory** 检索的对象 | **Archival Memory** 检索的对象 |

> [!note] 本质区分
> Message 是**自动产生的对话流水账**，Passage 是**精选沉淀的知识条目**。Recall Memory 检索的对象是前者。

---

## 2. 两个检索入口：Agent 级 vs 组织级

Letta 里实际有两个平行的检索方法，容易混淆，需要对照着看：

### 2.1 对照表

| 维度 | `search_messages_async`（Agent 级，1142 行） | `search_messages_org_async`（组织级，1262 行） |
|------|----------------------------------------------|-----------------------------------------------|
| **检索范围** | 单个 agent 的消息 | 整个 organization 下所有消息 |
| **Turbopuffer 未启用** | 有 SQL fallback（走 `list_messages` + `_combine_assistant_tool_messages`） | 没有 fallback，直接 `raise ValueError` |
| **Turbopuffer 异常** | 有 try/except，捕获后退化到 SQL 查询 | 无额外 try/except，异常直接抛出 |
| **返回类型** | `List[Tuple[PydanticMessage, dict]]`，metadata 是裸字典 | `List[MessageSearchResult]`，有类型的 Pydantic 对象 |
| **Message 对象来源** | 直接用 Turbopuffer 返回的 `msg_dict` 字段（role/text/created_at）现场拼装简化版 Message，**不查数据库** | 先拿 Turbopuffer 结果里的 id 列表，再 `get_messages_by_ids_async` 回数据库查完整对象，字段更全（step_id、tool_calls 等 TP 里没存的字段） |
| **过滤参数** | `roles`、`project_id`、`template_id` | 多了 `agent_id`、`conversation_id`（可在组织级搜索时限定某个 agent 或某个会话） |
| **search_mode** | `vector` / `fts` / `hybrid` / `timestamp` 四种 | `vector` / `fts` / `hybrid` 三种（`timestamp` 是 Agent 级独有） |

### 2.2 核心差异原因

```
Agent 级检索（conversation_search 工具用）
  → 要求"任何配置下都能用" → 必须有 SQL fallback
  → 为了性能 → 直接用 Turbopuffer 现有字段拼装，不回库

组织级检索（跨 agent 审计 / 后台分析）
  → 假设生产环境已具备 Turbopuffer → 硬依赖，不做 fallback
  → 跨 agent 聚合 → Turbopuffer 精简字段不够用 → 必须回库查完整 Message
```

> [!tip] 一句话记忆
> Agent 级 = **高可用 + 快**（有 fallback + 不回库）；组织级 = **字段全 + 硬依赖**（回库查 + 没 fallback）。

---

## 3. vector_rank、fts_rank、rrf_score 及融合方式

### 3.1 三个分数的含义

来自 `TurbopufferClient._reciprocal_rank_fusion`（`tpuf_client.py:1489-1558`）：

| 分数 | 含义 |
|------|------|
| `vector_rank` | 该消息在**向量检索**结果里的名次（1-based），未命中为 `None` |
| `fts_rank` | 该消息在**全文检索（BM25）**结果里的名次，未命中为 `None` |
| `rrf_score` | 两路名次融合后的**最终分数** |

### 3.2 融合公式（标准 RRF，Cormack et al. 2009）

```python
k = 60  # 标准常数

vector_rrf_score = vector_weight / (k + vector_rank)  # 未命中为 0
fts_rrf_score    = fts_weight    / (k + fts_rank)      # 未命中为 0
combined_score   = vector_rrf_score + fts_rrf_score     # 即 rrf_score
```

默认 `vector_weight = fts_weight = 0.5`，等权融合。

### 3.3 为什么用排名而不是原始分数

> [!note] 量纲问题
> 向量距离（cosine similarity）和 BM25 分数的**量纲完全不同**，没法直接相加。用排名可以规避这个问题——排名是无量纲的，两路排名融合只需要一个常数 `k=60` 控制收敛。

### 3.4 单一模式 vs 混合模式

> [!warning] 两种模式下 rrf_score 量纲不同
> - **hybrid 模式**：走标准 RRF 公式（`k=60`，带权重融合）
> - **单一模式**（纯 `vector` 或纯 `fts`）：走另一段逻辑，`combined_score = 1.0/(idx+1)`，是简单倒数排名分
>
> 两种模式下 `rrf_score` 的量纲**不能直接比较**。

```
hybrid 模式:  rrf_score = 0.5/(60+vector_rank) + 0.5/(60+fts_rank)
单一模式:     rrf_score = 1.0/(idx+1)    ← 完全不同的公式
```

---

## 4. 检索流程全景图

```
用户调用 conversation_search 工具
        │
        ▼
┌───────────────────────────────────────┐
│ conversation_search (core_tool_executor)│
│  → 委托 message_manager                │
│    .search_messages_async(...)         │
└───────────────────────────────────────┘
        │
        ▼
┌───────────────────────────────────────┐
│ search_messages_async (message_manager)│
│                                        │
│  Turbopuffer 启用?                     │
│  ├── YES → 调 TurbopufferClient        │
│  │         ├── vector 检索 → vector_rank│
│  │         ├── fts 检索   → fts_rank    │
│  │         └── RRF 融合   → rrf_score   │
│  │             (try/except → SQL fallback)│
│  │                                     │
│  └── NO  → SQL fallback                │
│            list_messages +             │
│            _combine_assistant_tool_messages│
└───────────────────────────────────────┘
        │
        ▼
返回 List[Tuple[Message, metadata_dict]]
  metadata 含 vector_rank / fts_rank / rrf_score
```

---

## 5. 检索结果怎么返回给 LLM

搜索结果**不会自动进 system prompt**——和 Archival Memory 一样，搜索结果作为 tool_return 消息返回给 LLM，LLM 在下一轮推理时看到。

这点和 Core Memory（始终编译进 system prompt）形成对比：

| 记忆类型 | 进 system prompt？ | 检索方式 |
|----------|:---:|------|
| Core Memory | ✅ 始终可见 | 直接编译，不需要搜索 |
| Archival Memory | ❌ | LLM 主动调用 `archival_memory_search` |
| Recall Memory | ❌ | LLM 主动调用 `conversation_search` |

---

## 快速参考卡

| 问题 | 答案 |
|------|------|
| Recall Memory 用什么检索方式？ | 混合检索：向量 + FTS/BM25 + RRF 融合 |
| 底层依赖什么？ | Turbopuffer；未启用时退化为纯 SQL |
| Message 和 Passage 的区别？ | Message = 对话流水账（自动产生）；Passage = 知识条目（主动写入 Archival） |
| Agent 级和组织级检索的核心差异？ | Agent 级有 SQL fallback + 不回库；组织级硬依赖 TP + 回库查完整对象 |
| RRF 公式是什么？ | `0.5/(60+vector_rank) + 0.5/(60+fts_rank)`，k=60 |
| 为什么用排名不用原始分数？ | 向量距离和 BM25 量纲不同，排名融合规避量纲问题 |
| 单一模式和混合模式的 rrf_score 能比吗？ | 不能——单一模式走 `1/(idx+1)`，量纲不同 |
| 搜索结果进 system prompt 吗？ | 不进——作为 tool_return 返回给 LLM |

---

## 踩坑清单

1. **`timestamp` 模式只有 Agent 级有**：组织级 `search_messages_org_async` 只支持 `vector`/`fts`/`hybrid` 三种，传 `timestamp` 会报错。跨入口调用时注意模式兼容性。
2. **Agent 级的 Message 是简化版**：Turbopuffer 返回的 `msg_dict` 只有 `role`/`text`/`created_at` 等精简字段，`step_id`/`tool_calls` 等字段缺失。如果下游逻辑依赖这些字段，要用组织级接口或手动回库补全。
3. **单一模式与混合模式 rrf_score 不可比较**：同一批消息在 `hybrid` 模式下的 `rrf_score` 和在纯 `vector` 模式下的 `rrf_score` 公式不同、量纲不同，做跨模式排序对比会出错。
4. **Turbopuffer 异常降级是静默的**：Agent 级检索在 TP 异常时 try/except 捕获后退化到 SQL，但不会通知调用方——如果 SQL fallback 的检索质量和 TP 差距大，调用方可能不知道结果质量下降了。

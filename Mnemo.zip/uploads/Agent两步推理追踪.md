---
title: Agent两步推理追踪：从天气查询到消息回复的完整消息流
summary: 以"北京今天天气怎么样"为例，完整追踪两个 step 的 agent loop，涵盖消息列表变化、LLM 请求构建、工具执行、持久化、异常处理
project: letta
tags: [letta, agent-loop, step, example, walkthrough]
created: 2026-06-29
updated: 2026-06-29
status: completed
confidence: high
---

# Agent两步推理追踪：从天气查询到消息回复的完整消息流

> 场景：用户发送 "北京今天天气怎么样"，agent 调用 `get_weather` 查询天气，再调用 `send_message` 回复用户，共两个 step。

---

## 一、数据结构说明

在进入流程之前，先明确贯穿全程的核心变量。

### 三个消息列表

| 变量 | 职责 | 初始值 |
|------|------|--------|
| `current_in_context_messages` | 已持久化在 DB 的历史消息，agent 的"长期记忆" | 从 DB 加载 |
| `new_in_context_messages` | 本次对话新产生的消息，随 step 不断追加 | 用户本次输入 |
| `self.response_messages` | 最终返回给 API 调用方的消息，不含用户输入 | `[]` |
| `initial_messages` | `new` 在进入 step loop 前的快照，仅用于计算跳过索引，永远不变 | 同 `new` 初始值 |

### StepProgression 状态机

```
START(1) → RESPONSE_RECEIVED(2) → STEP_LOGGED(3) → LOGGED_TRACE(4) → FINISHED(5)
```

| 值 | 含义 | 设置时机 |
|----|------|---------|
| `START` | step 刚开始 | 每个 step 开头 |
| `RESPONSE_RECEIVED` | LLM 响应完整收到 | `_build_and_request_from_llm` 成功后 |
| `STEP_LOGGED` | 工具执行完，消息已持久化入 DB | `_handle_ai_response` 成功后 |
| `LOGGED_TRACE` | telemetry trace 已记录 | trace 写完后 |
| `FINISHED` | 整个 step 正常结束 | `_record_step_metrics` 成功后 |

异常发生时，根据当前 `step_progression` 决定补救策略。

---

## 二、准备阶段（Step Loop 外）

### 2.1 加载 Agent 状态

```python
agent_state = await agent_manager.get_agent_by_id_async(
    agent_id=self.agent_id,
    include_relationships=["tools", "memory", "tool_exec_environment_variables", "sources"],
)
```

从 DB 拉取 agent 完整配置：

```
agent_state.tools       = [get_weather, send_message, archival_memory_search]
agent_state.llm_config  = {model: "gpt-4o", context_window: 128000}
agent_state.memory      = {用户名: "Xavier", 城市: "北京"}
agent_state.tool_rules  = [
    ChildToolRule(tool="get_weather", children=["send_message"]),
    TerminalToolRule(tool="send_message"),
]
```

### 2.2 初始化消息列表

```python
current_in_context_messages, new_in_context_messages = \
    await _prepare_in_context_messages_no_persist_async(input_messages, agent_state, ...)
```

**`current`** — 从 DB 按 `agent_state.message_ids` 加载历史：

```
msg_0: [system]    "你是助手，memory: {用户名: Xavier, 城市: 北京}"
msg_1: [user]      "你好"
msg_2: [assistant] "你好！有什么可以帮你？"
```

**`new`** — 把用户输入包装成 Message 对象，**此时不写 DB**：

```
msg_A: [user] "北京今天天气怎么样"
```

```python
initial_messages       = [msg_A]   # new 的快照，永远不变
self.response_messages = []
```

### 2.3 初始化工具规则和 LLM 客户端

```python
tool_rules_solver = ToolRulesSolver(agent_state.tool_rules)
# 内部维护规则链：get_weather → 只允许 send_message → 终止

llm_client = LLMClient.create(provider_type="openai")
# 根据 llm_config.model_endpoint_type 选择对应的 client 实现
```

---

## 三、Step 1：调用 get_weather

### 3.1 创建 Step 记录

```python
step_progression = StepProgression.START

logged_step = await step_manager.log_step_async(
    step_id   = step_id_1,
    agent_id  = agent_state.id,
    model     = "gpt-4o",
    status    = StepStatus.PENDING,
    usage     = UsageStatistics(completion_tokens=0, prompt_tokens=0, total_tokens=0),
)
effective_step_id = step_id_1   # step 创建成功，使用真实 id
```

在 DB 的 Step 表里预先占位，状态为 `PENDING`，后续根据结果更新。

### 3.2 `_build_and_request_from_llm`

#### attempt 0

**拼接完整上下文：**

```python
in_context_messages = current + new = [
    msg_0: [system]    "你是助手，memory: {用户名: Xavier, 城市: 北京}"
    msg_1: [user]      "你好"
    msg_2: [assistant] "你好！有什么可以帮你？"
    msg_A: [user]      "北京今天天气怎么样"    ← new
]
```

**`_rebuild_memory_async` — 刷新 system message：**

```python
# 从 DB 拉最新 memory blocks
curr_memory_str = agent_state.memory.compile()
# = "{用户名: Xavier, 城市: 北京}"

# 和 msg_0.content 对比，内容一致，不需要重写
# in_context_messages[0] 保持不动
```

**`scrub_inner_thoughts_from_messages`：**

```python
# msg_2 是旧的 assistant 消息，没有 inner thought TextContent
# reasoning 未禁用，不做任何处理
```

**`ToolRulesSolver.get_allowed_tool_names`：**

```python
# tool_call_history 为空（第一次 step，没有历史调用记录）
# 没有 InitToolRule 约束
# → 所有工具都可用

valid_tool_names = ["get_weather", "send_message", "archival_memory_search"]
# 多于一个工具 → force_tool_call = None，LLM 自由选择
```

**`llm_client.build_request_data` — 转成 OpenAI 格式：**

```python
request_data = {
    "model": "gpt-4o",
    "messages": [
        {"role": "system",    "content": "你是助手，memory: {用户名: Xavier, 城市: 北京}"},
        {"role": "user",      "content": "你好"},
        {"role": "assistant", "content": "你好！有什么可以帮你？"},
        {"role": "user",      "content": "北京今天天气怎么样"},
    ],
    "tools": [
        {"type": "function", "function": {"name": "get_weather",  "parameters": {...}}},
        {"type": "function", "function": {"name": "send_message", "parameters": {...}}},
        {"type": "function", "function": {"name": "archival_memory_search", "parameters": {...}}},
    ]
    # tool_choice 不设置，LLM 自由选择
}
```

**`request_async_with_telemetry` — 发请求：**

```python
async with AsyncTimer() as timer:
    response_data = await llm_client.request_async(request_data, llm_config)
# timer.elapsed_ns = 820_000_000 ns (820ms)
step_metrics.llm_request_ns = 820_000_000

# 同时写入 telemetry（request_data + response_data 完整记录）
await telemetry_manager.create_provider_trace_async(
    request=request_data, response=response_data, ...
)
```

**返回五元组：**

```python
return (
    request_data,
    response_data,
    current_in_context_messages,   # [msg_0, msg_1, msg_2]，未变
    new_in_context_messages,       # [msg_A]，未变
    valid_tool_names,              # ["get_weather", "send_message", ...]
)
```

```python
step_progression = StepProgression.RESPONSE_RECEIVED
```

### 3.3 `convert_response_to_chat_completion`

LLM 原始响应 `response_data`：

```json
{
  "choices": [{
    "message": {
      "content": "用户想知道北京的天气，我应该调用 get_weather 工具来获取实时数据。",
      "tool_calls": [{
        "id": "call_001",
        "type": "function",
        "function": {
          "name": "get_weather",
          "arguments": "{\"city\": \"北京\"}"
        }
      }]
    },
    "finish_reason": "tool_calls"
  }],
  "usage": {
    "prompt_tokens": 210,
    "completion_tokens": 45,
    "total_tokens": 255
  }
}
```

**格式校验和修复：**

```python
# 空响应检测：content 有值，tool_calls 有值，通过
# 截断 JSON 修复：{"city": "北京"} 完整，不需要修复
# inner thought 解包：put_inner_thoughts_in_kwargs=False，不需要解包
```

**reasoning 解析（四分支判断）：**

```python
response.choices[0].message.reasoning_content          # = None（OpenAI 不返回）
response.choices[0].message.omitted_reasoning_content  # = False

# 走第二分支：content 有值
reasoning = [TextContent(
    text="用户想知道北京的天气，我应该调用 get_weather 工具来获取实时数据。"
)]
```

**OTel Metrics 上报：**

```python
MetricRegistry().message_output_tokens.record(
    45,   # completion_tokens
    {"project_id": "proj_xxx", "agent_id": "agent_xxx", "model.name": "gpt-4o"}
)
# 写入 Histogram，异步推送到 Prometheus
```

**提取 tool_call：**

```python
tool_call = response.choices[0].message.tool_calls[0]
# tool_call.function.name      = "get_weather"
# tool_call.function.arguments = '{"city": "北京"}'
```

### 3.4 `_handle_ai_response`

**① 解析参数：**

```python
tool_call_name    = "get_weather"
tool_args         = _safe_load_tool_call_str('{"city": "北京"}')
                  = {"city": "北京"}

request_heartbeat = _pop_heartbeat(tool_args)   # = False，参数里没有 heartbeat
tool_args.pop(INNER_THOUGHTS_KWARG, None)       # 没有 inner thought kwarg，跳过

# 最终传给工具的参数
tool_args = {"city": "北京"}
```

**② 执行前校验：**

```python
tool_rules_solver.is_requires_approval("get_weather")  # False，不需要人工审批

"get_weather" in valid_tool_names                       # True，未违反规则
```

**③ 执行工具：**

```python
tool_execution_result = await self._execute_tool(
    tool_name="get_weather",
    tool_args={"city": "北京"},
    agent_state=agent_state,
)
# 内部创建 ToolExecutionManager，运行工具代码
# 耗时记录：step_metrics.tool_execution_ns = 230_000_000 (230ms)

# 返回结果
tool_execution_result.func_return  = {"weather": "晴天", "temperature": "25°C", "humidity": "40%"}
tool_execution_result.success_flag = True
```

**④ 处理返回值：**

```python
function_response_string = validate_function_response(
    {"weather": "晴天", "temperature": "25°C", "humidity": "40%"},
    return_char_limit=5000,
    truncate=True,
)
# = '{"weather": "晴天", "temperature": "25°C", "humidity": "40%"}'
# 未超出长度限制，不截断

self.last_function_response = package_function_response(
    was_success=True,
    response_string=function_response_string,
    timezone=agent_state.timezone,
)
# last_function_response 供下一轮 ConditionalToolRule 判断使用
```

**⑤ `_decide_continuation`：**

```python
# 优先级从高到低检查：
tool_rule_violated      = False     # 未违规，跳过
is_terminal_tool        = False     # get_weather 不是 terminal tool
has_children_tools      = True      # ChildToolRule: get_weather → [send_message]
                                    # → 强制继续！

continue_stepping = True
heartbeat_reason  = "Continuing: child tool rule requires send_message next."
stop_reason       = None

# 硬覆盖检查
is_final_step = (0 == max_steps - 1)  # False（假设 max_steps > 1）
# uncalled required tools → 无 RequiredBeforeExit 规则，跳过
```

**⑥ 创建消息：**

```python
msg_B = Message(
    id="msg_b_xxx",
    role="assistant",
    content=[
        TextContent(text="用户想知道北京的天气，我应该调用 get_weather 工具来获取实时数据。")
    ],
    tool_calls=[
        ToolCall(
            id="call_001",
            function=FunctionCall(name="get_weather", arguments='{"city": "北京"}')
        )
    ],
    step_id=step_id_1,
    agent_id=agent_state.id,
)

msg_C = Message(
    id="msg_c_xxx",
    role="tool",
    content=[
        ToolReturnContent(
            content='{"weather": "晴天", "temperature": "25°C", "humidity": "40%"}',
            status="success",
        )
    ],
    tool_call_id="call_001",
    # continue_stepping=True → 附加 heartbeat 提示，告知 LLM 继续思考
    step_id=step_id_1,
    agent_id=agent_state.id,
)
```

**⑦ 批量持久化：**

```python
messages_to_persist = initial_messages + tool_call_messages
                    = [msg_A]         + [msg_B, msg_C]
                    = [msg_A, msg_B, msg_C]

# 批量写入 DB
persisted_messages = await message_manager.create_many_messages_async(
    [msg_A, msg_B, msg_C],
    actor=self.actor,
    project_id=agent_state.project_id,
)
# 返回带 DB id 的完整 Message 对象列表
# 同时后台异步 embedding → Turbopuffer（向量DB）
```

**⑧ 更新三个列表：**

```python
new_message_idx = len(initial_messages)   # = len([msg_A]) = 1
# 跳过 msg_A（已在 new_in_context_messages 里），只追加新产生的

new_in_context_messages.extend(persisted_messages[1:])
# new = [msg_A] + [msg_B, msg_C] = [msg_A, msg_B, msg_C]

self.response_messages.extend(persisted_messages[1:])
# response_messages = [] + [msg_B, msg_C] = [msg_B, msg_C]

# initial_messages 永远不变 = [msg_A]
```

### 3.5 Step 1 收尾

```python
step_progression = StepProgression.STEP_LOGGED

# 记录 telemetry trace
await _log_request(request_start_timestamp_ns, request_span, job_update_metadata=None)
step_progression = StepProgression.LOGGED_TRACE

# 更新 Step 表状态
await step_manager.update_step_status(step_id_1, StepStatus.COMPLETED, stop_reason=None)
step_progression = StepProgression.FINISHED

# 记录 step metrics 到 StepMetrics 表
step_metrics.step_ns = 1_200_000_000  # 整个 step 耗时 1200ms
await _record_step_metrics(
    step_id=step_id_1,
    step_metrics=StepMetrics(
        llm_request_ns   = 820_000_000,   # LLM 请求耗时
        tool_execution_ns= 230_000_000,   # 工具执行耗时
        step_ns          = 1_200_000_000, # 总耗时
    )
)
```

### Step 1 结束时各变量状态

```
current_in_context_messages = [msg_0, msg_1, msg_2]           ← 未变
new_in_context_messages     = [msg_A, msg_B, msg_C]           ← 追加了 B, C
self.response_messages      = [msg_B, msg_C]                  ← 追加了 B, C
initial_messages            = [msg_A]                         ← 永远不变
should_continue             = True                            ← 继续 loop
step_progression            = FINISHED
```

---

## 四、Step 2：调用 send_message

### 4.1 创建 Step 记录

```python
step_progression = StepProgression.START

logged_step = await step_manager.log_step_async(
    step_id = step_id_2,
    status  = StepStatus.PENDING,
    ...
)
effective_step_id = step_id_2
```

### 4.2 `_build_and_request_from_llm`

**拼接完整上下文：**

```python
in_context_messages = current + new = [
    msg_0: [system]    "你是助手，memory: {用户名: Xavier, 城市: 北京}"
    msg_1: [user]      "你好"
    msg_2: [assistant] "你好！有什么可以帮你？"
    msg_A: [user]      "北京今天天气怎么样"
    msg_B: [assistant] inner_thought + tool_call(get_weather)
    msg_C: [tool]      "晴天25°C..."   ← 上一个 step 的结果，LLM 能看到
]
```

**`_rebuild_memory_async`：**

memory 未变，`msg_0` 不更新。

**`ToolRulesSolver.get_allowed_tool_names`：**

```python
# 上一轮调用了 get_weather
# ChildToolRule: get_weather → children=[send_message]
# 现在只允许 send_message

valid_tool_names = ["send_message"]   # 只剩一个！
force_tool_call  = "send_message"     # 强制 LLM 调用它，不给选择
```

**`build_request_data`：**

```python
request_data = {
    "model": "gpt-4o",
    "messages": [
        {"role": "system",    "content": "你是助手，memory: {...}"},
        {"role": "user",      "content": "你好"},
        {"role": "assistant", "content": "你好！有什么可以帮你？"},
        {"role": "user",      "content": "北京今天天气怎么样"},
        {"role": "assistant", "content": "...", "tool_calls": [{"name": "get_weather"}]},
        {"role": "tool",      "content": "晴天25°C...", "tool_call_id": "call_001"},
    ],
    "tools": [{"type": "function", "function": {"name": "send_message", "parameters": {...}}}],
    "tool_choice": {
        "type": "function",
        "function": {"name": "send_message"}  # 强制调用
    }
}
```

**发请求，LLM 响应：**

```python
# step_metrics.llm_request_ns = 780_000_000 (780ms)

response_data = {
    "choices": [{
        "message": {
            "content": "我已经获取到天气信息，现在应该把结果告诉 Xavier。",
            "tool_calls": [{
                "id": "call_002",
                "function": {
                    "name": "send_message",
                    "arguments": "{\"message\": \"北京今天天气晴天，气温25°C，湿度40%，适合外出！\"}"
                }
            }]
        },
        "finish_reason": "tool_calls"
    }],
    "usage": {"prompt_tokens": 310, "completion_tokens": 52, "total_tokens": 362}
}
```

```python
step_progression = StepProgression.RESPONSE_RECEIVED
```

### 4.3 `convert_response_to_chat_completion`

```python
reasoning = [TextContent(text="我已经获取到天气信息，现在应该把结果告诉 Xavier。")]

tool_call = ToolCall(
    id="call_002",
    function=FunctionCall(
        name="send_message",
        arguments='{"message": "北京今天天气晴天，气温25°C，湿度40%，适合外出！"}'
    )
)

# OTel 上报
MetricRegistry().message_output_tokens.record(52, {"model.name": "gpt-4o", ...})
```

### 4.4 `_handle_ai_response`

**① 解析参数：**

```python
tool_call_name    = "send_message"
tool_args         = {"message": "北京今天天气晴天，气温25°C，湿度40%，适合外出！"}
request_heartbeat = False
```

**② 执行前校验：**

```python
is_requires_approval("send_message") = False
"send_message" in ["send_message"]   = True   # valid_tool_names 只有一个
```

**③ 执行工具：**

```python
tool_execution_result = await self._execute_tool("send_message", {"message": "北京今天..."})
# 内置工具，直接执行，不走外部 MCP
# step_metrics.tool_execution_ns = 15_000_000 (15ms)

tool_execution_result.func_return  = "消息已发送给用户"
tool_execution_result.success_flag = True
```

**④ `_decide_continuation`：**

```python
tool_rule_violated  = False
is_terminal_tool    = True    # TerminalToolRule(tool="send_message")
                              # → 强制停止！

continue_stepping = False
stop_reason = LettaStopReason(stop_reason=StopReasonType.tool_rule.value)

# 硬覆盖检查
is_final_step = (1 == max_steps - 1)  # 假设 max_steps=10，False，跳过
# RequiredBeforeExit 已满足（send_message 调用过了）
```

**⑤ 创建消息：**

```python
msg_D = Message(
    role="assistant",
    content=[TextContent(text="我已经获取到天气信息，现在应该把结果告诉 Xavier。")],
    tool_calls=[ToolCall(id="call_002", function=FunctionCall(
        name="send_message",
        arguments='{"message": "北京今天天气晴天..."}'
    ))],
    step_id=step_id_2,
)

msg_E = Message(
    role="tool",
    content=[ToolReturnContent(
        content="消息已发送给用户",
        status="success",
    )],
    tool_call_id="call_002",
    # continue_stepping=False → 不附加 heartbeat，告知 LLM 对话结束
    step_id=step_id_2,
)
```

**⑥ 批量持久化：**

```python
messages_to_persist = (initial_messages or []) + [msg_D, msg_E]
# initial_messages = None（第二个 step 及以后都是 None）
                  = [] + [msg_D, msg_E]
                  = [msg_D, msg_E]

persisted_messages = await message_manager.create_many_messages_async([msg_D, msg_E])
```

**⑦ 更新三个列表：**

```python
new_message_idx = len(None 的话取 0) = 0   # 不跳过任何消息

new_in_context_messages.extend(persisted_messages[0:])
# new = [msg_A, msg_B, msg_C] + [msg_D, msg_E]
#     = [msg_A, msg_B, msg_C, msg_D, msg_E]

self.response_messages.extend(persisted_messages[0:])
# response_messages = [msg_B, msg_C] + [msg_D, msg_E]
#                   = [msg_B, msg_C, msg_D, msg_E]
```

### 4.5 Step 2 收尾

```python
step_progression = StepProgression.STEP_LOGGED

await _log_request(...)
step_progression = StepProgression.LOGGED_TRACE

await step_manager.update_step_status(
    step_id_2, StepStatus.COMPLETED,
    stop_reason=StopReasonType.tool_rule
)
step_progression = StepProgression.FINISHED

step_metrics.step_ns = 950_000_000  # 950ms
await _record_step_metrics(
    step_id=step_id_2,
    step_metrics=StepMetrics(
        llm_request_ns   = 780_000_000,
        tool_execution_ns= 15_000_000,
        step_ns          = 950_000_000,
    )
)
```

`should_continue = False` → **`break`，退出 loop**

---

## 五、异常处理策略

每个 step 的 `try/except` 根据 `step_progression` 决定补救力度。

### 5.1 `step_progression <= RESPONSE_RECEIVED`

消息**尚未入库**，用户输入 `msg_A` 从未写 DB。

```python
if settings.track_errored_messages and initial_messages:
    for message in initial_messages:
        message.is_err = True           # 标记为失败消息
        message.step_id = effective_step_id
    await message_manager.create_many_messages_async(initial_messages, ...)
    # 把 msg_A 打上 is_err=True 写入 DB，用于调试追踪
```

**发生场景举例：**
- `_build_and_request_from_llm` 网络超时
- LLM 返回空响应，`convert_response_to_chat_completion` 抛 `LLMEmptyResponseError`

### 5.2 `step_progression <= LOGGED_TRACE`

消息**已入库**，只需更新 Step 表状态。

```python
if stop_reason is None:
    stop_reason = LettaStopReason(stop_reason=StopReasonType.error.value)

if logged_step:
    await step_manager.update_step_stop_reason(self.actor, step_id, stop_reason.stop_reason)
    # 把 PENDING → 更新为实际的 stop reason，step 有明确终态
```

**发生场景举例：**
- `_record_step_metrics` 写 DB 超时（FINISHED 之前出错）
- telemetry trace 写入失败

### 5.3 收尾操作本身出错

```python
try:
    await self._log_request(..., is_error=True)
    await self._record_step_metrics(...)   # 记录残缺耗时
except Exception as e:
    self.logger.error("Failed to update step: %s", e)
    # 只 log，不 raise
    # 不能让收尾失败覆盖掉原始业务异常
```

### 5.4 所有异常最终 `raise`

```python
raise   # 原样往上抛，让 HTTP handler 决定如何响应给用户
```

---

## 六、最终状态汇总

### 消息列表

```
current_in_context_messages = [msg_0, msg_1, msg_2]
                               system  打招呼  打招呼回复
                               （全程未变）

new_in_context_messages     = [msg_A, msg_B, msg_C, msg_D, msg_E]
                               用户输入 step1查天气  step2回复用户

self.response_messages      = [msg_B, msg_C, msg_D, msg_E]
                               step1查天气  step2回复用户
                               （不含 msg_A，用户自己发的不算响应）
```

### DB 写入记录

| 表 | 写入内容 |
|----|---------|
| `Message` | msg_A, msg_B, msg_C（step1），msg_D, msg_E（step2） |
| `Step` | step_id_1（COMPLETED），step_id_2（COMPLETED, tool_rule） |
| `StepMetrics` | step_id_1（llm=820ms, tool=230ms, total=1200ms），step_id_2（llm=780ms, tool=15ms, total=950ms） |
| `Turbopuffer`（向量DB） | msg_A~E 的 embedding（后台异步） |

### 监控指标（OTel）

```
message_output_tokens: 45  {model: gpt-4o, agent: xxx}   ← step 1
message_output_tokens: 52  {model: gpt-4o, agent: xxx}   ← step 2
```

---

## 七、完整调用链

```
用户请求："北京今天天气怎么样"
│
├── 准备阶段
│   ├── get_agent_by_id              → 加载 tools/memory/llm_config
│   ├── _prepare_in_context_messages → current=[sys,u1,a1], new=[msgA]
│   └── ToolRulesSolver / LLMClient  → 初始化规则和客户端
│
├── Step 1（step_id_1）
│   ├── log_step_async(PENDING)
│   │
│   ├── _build_and_request_from_llm
│   │   ├── current+new=[sys,u1,a1,msgA]
│   │   ├── _rebuild_memory_async    → memory未变，sys不更新
│   │   ├── valid_tools=[get_weather,send_message,...]  force=None
│   │   ├── build_request_data       → OpenAI格式
│   │   └── request_async            → LLM选择 get_weather  [820ms]
│   │
│   ├── convert_response_to_chat_completion
│   │   ├── 格式校验/修复
│   │   ├── reasoning=[TextContent("...")]
│   │   ├── tool_call=get_weather(city=北京)
│   │   └── OTel: completion_tokens=45
│   │
│   ├── _handle_ai_response
│   │   ├── 解析参数: tool_args={city:北京}, heartbeat=False
│   │   ├── 校验: 未违规，不需审批
│   │   ├── _execute_tool(get_weather) → "晴天25°C"  [230ms]
│   │   ├── _decide_continuation: ChildToolRule→强制继续
│   │   ├── 生成 [msg_B(asst), msg_C(tool)]
│   │   └── create_many_messages([msgA,B,C]) → DB
│   │
│   ├── new=[msgA,B,C]  response=[B,C]
│   └── _record_step_metrics(llm=820ms,tool=230ms,total=1200ms)
│
├── Step 2（step_id_2）
│   ├── log_step_async(PENDING)
│   │
│   ├── _build_and_request_from_llm
│   │   ├── current+new=[sys,u1,a1,msgA,B,C]
│   │   ├── ChildToolRule→valid_tools=[send_message]  force=send_message
│   │   ├── build_request_data       → tool_choice强制send_message
│   │   └── request_async            → LLM调用 send_message  [780ms]
│   │
│   ├── convert_response_to_chat_completion
│   │   ├── reasoning=[TextContent("...")]
│   │   ├── tool_call=send_message(message="北京晴天25°C...")
│   │   └── OTel: completion_tokens=52
│   │
│   ├── _handle_ai_response
│   │   ├── 解析参数: tool_args={message:"北京晴天..."}
│   │   ├── _execute_tool(send_message) → "消息已发送"  [15ms]
│   │   ├── _decide_continuation: TerminalToolRule→强制停止
│   │   ├── 生成 [msg_D(asst), msg_E(tool)]
│   │   └── create_many_messages([D,E]) → DB
│   │
│   ├── new=[msgA,B,C,D,E]  response=[B,C,D,E]
│   └── _record_step_metrics(llm=780ms,tool=15ms,total=950ms)
│
└── should_continue=False → break
    返回 response_messages=[B,C,D,E] 给调用方
```

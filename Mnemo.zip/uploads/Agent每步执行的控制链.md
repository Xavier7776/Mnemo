---
title: Agent每步执行的控制链：审批挂起、取消信号与工具规则状态机
summary: Letta agent.py _step() 主循环源码精读，包括 tool_rules、LLMClient、approval 机制、_handle_ai_response、Step 生命周期
project: letta
tags: [letta, agent-loop, step, source-code, memory]
created: 2026-06-28
updated: 2026-06-28
status: completed
confidence: high
---

# Agent每步执行的控制链：审批挂起、取消信号与工具规则状态机

## 1. tool_rules — 工具调用规则集

`tool_rules` 是控制 agent 工具调用行为的**规则集合**，本质是一套有限状态机约束。

### 规则类型

| 规则 | 作用 |
|------|------|
| `InitToolRule` | 第一次调用必须使用某个工具 |
| `TerminalToolRule` | 调用该工具后必须终止当前 step |
| `ChildToolRule` | 调用 A 之后下一个只能调用 B |
| `MaxStepsPerToolRule` | 某工具最多调用 N 次 |

### 与工具本身的关系

- `agent_state.tools` — 工具的实际实现/schema
- `agent_state.tool_rules` — 只存工具名引用，是门卫而非执行者

`ToolRulesSolver` 接收规则，在每次工具调用前后过滤可用工具列表、更新状态机、判断是否终止。

---

## 2. LLMClient.create() — 创建 LLM 客户端

```python
llm_client = LLMClient.create(
    provider_type=agent_state.llm_config.model_endpoint_type,
    put_inner_thoughts_first=True,
    actor=self.actor,
)
```

### 参数说明

- `provider_type` — 提供商类型（`openai` / `anthropic` / `ollama` 等），决定使用哪套 API 格式
- `put_inner_thoughts_first` — agent 先输出内心独白再输出工具调用（先想后做）
- `actor` — 操作者身份，用于权限校验和审计追踪

工厂模式创建对应提供商的客户端，屏蔽不同 API 差异。

### model_endpoint_type vs model

```python
llm_config.model_endpoint_type = "openai"                        # 提供商类型
llm_config.model               = "gpt-4o"                        # 具体模型名
llm_config.model_endpoint      = "https://api.openai.com/v1"     # 接口地址
```

---

## 3. 调用前的准备工作

```python
request_span = tracer.start_span("time_to_first_token")
stop_reason = None
job_update_metadata = None
usage = LettaUsageStatistics()
```

| 变量 | 作用 |
|------|------|
| `request_span` | OpenTelemetry 追踪 span，记录首 token 耗时和模型配置 |
| `stop_reason` | LLM 停止原因（stop / tool_calls / length），先置 None |
| `job_update_metadata` | 任务元信息，先置 None |
| `usage` | Token 用量统计容器，初始化为空 |

---

## 4. 取消检查

```python
if await self._check_run_cancellation():
    stop_reason = LettaStopReason(stop_reason=StopReasonType.cancelled.value)
    break
```

每步循环开头主动轮询数据库，检查当前 run 是否被标记为 `cancelled`。

### 取消信号链路

```
用户点停止
    │
POST /runs/{run_id}/cancel
    │
数据库 run.status = cancelled
    │
下次轮询检测到 → break
```

协作式取消机制，最坏情况多跑完当前步，不会继续往后走。

---

## 5. approval 消息处理

当 `in_context_messages[-1].role == "approval"` 时，说明 agent 上次暂停在等待人工审批节点。

### 场景

```
Agent 要调用敏感工具 → 暂停发出 approval 请求
    │
人类审核：同意 or 拒绝
    │
本轮循环处理审批结果
```

### new_message_idx 防重复机制

`persisted_messages` 包含历史消息 + 新消息，用 `len(initial_messages)` 做偏移切片，只取新增部分：

```python
new_message_idx = len(initial_messages) if initial_messages else 0
persisted_messages[new_message_idx:]   # 只取新产生的消息
```

### 具体例子

初始状态：
```
msg1: user "帮我删除所有日志文件"
msg2: assistant "好的，我来执行"
msg3: approval  tool_call=delete_files()   ← 上次停在这里
```

同意后 `_handle_ai_response` 产生：
```
msg4: tool_result "已删除 128 个文件"
msg5: assistant "删除完成"
```

`persisted_messages[3:]` 只取 msg4、msg5，不重复。

拒绝时则产生：
```
msg4: tool_result "操作被拒绝：这个操作太危险"
msg5: assistant "好的，我换个方式处理..."
```

---

## 6. dry_run 模式

```python
if dry_run:
    request_data, valid_tool_names = await self._create_llm_request_data_async(...)
    return request_data
```

只构造 LLM 请求体，不发送，直接返回。

### 用途

- 调试：检查消息拼装是否正确
- 估算 token：提前判断是否超出上下文限制
- 测试：不打 API 只验证请求构造逻辑
- 预览：让用户确认即将发送的内容

---

## 7. _handle_ai_response — 核心执行函数

处理 LLM 响应，是 agent loop 每一步的"执行器 + 决策器"。

### 内部步骤

1. **处理审批** — 同意则执行工具，拒绝则构造拒绝消息跳过执行
2. **识别工具类型** — send_message / 内置记忆工具 / 外部自定义工具
3. **执行工具** — 调用对应函数拿到结果
4. **检查 tool_rules** — 更新状态机，判断是否触发终止规则
5. **持久化消息** — 把 assistant 消息和 tool_result 消息写库
6. **判断是否需要审批** — 若需要则构造 approval 消息挂起

### 返回值

```python
return persisted_messages, should_continue, stop_reason
#       持久化后的消息列表   是否继续循环    停止原因
```

---

## 8. log_step_async — 提前创建 Step 记录

```python
logged_step = await self.step_manager.log_step_async(
    ...
    usage=UsageStatistics(completion_tokens=0, prompt_tokens=0, total_tokens=0),
    status=StepStatus.PENDING,
)
```

### 为什么提前创建

先占位，即使 LLM 调用途中崩溃，数据库里也留有 `PENDING` 记录便于排查。

### Step 生命周期

```
写入(token全0, PENDING)
    │
LLM 调用完成
    │
更新(真实token, COMPLETED / FAILED)
```

### 参数分类

| 类别 | 参数 | 作用 |
|------|------|------|
| 身份类 | `actor`, `agent_id`, `run_id`, `step_id`, `project_id` | 说明 step 归属 |
| 模型类 | `provider_name`, `model`, `model_endpoint`, `model_handle` | 审计和计费 |
| 资源类 | `context_window_limit`, `usage` | 资源消耗追踪 |
| 状态类 | `status` | 进度标记 |

### 层级关系

```
project_id
    └── run_id          (一个 project 有多次 run)
            └── step_id (一次 run 有多个 step)
                    ├── agent_id
                    ├── model
                    └── usage
```

### effective_step_id 降级处理

```python
effective_step_id = step_id if logged_step else None
```

数据库写入失败时不中断主流程，记录失败不影响 agent 继续运行。

---

## 整体 Agent Loop 流程

```
for i in range(max_steps):
    │
    ├─ 检查取消信号 → cancelled? break
    │
    ├─ 提前创建 Step 记录(PENDING)
    │
    ├─ approval 消息? → _handle_ai_response(处理审批结果)
    │
    └─ 正常流程:
        ├─ dry_run? → 构造请求体直接返回
        │
        ├─ 构造 LLM 请求(消息+工具列表)
        │
        ├─ 调用 LLM
        │
        ├─ _handle_ai_response(执行工具、持久化)
        │
        └─ should_continue? → 继续 or break
```

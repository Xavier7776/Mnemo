---
title: _rebuild_memory_async场景走读：内存刷新、System Message重建与轻量diff过滤
summary: 以"Xavier换工作"为完整场景，逐步走读 _rebuild_memory_async 的七步流程：刷新内存块、收集上下文、编译内存字符串、子串过滤、统计元数据、生成新 system message、diff 比对落库
project: letta
tags: [letta, _rebuild_memory_async, system-message, memory, core-memory, diff, agent-loop]
created: 2026-07-04
updated: 2026-07-04
status: completed
confidence: high
---

# `_rebuild_memory_async` 场景走读：内存刷新、System Message重建与轻量diff过滤

用一个完整、具体的场景把整个 `_rebuild_memory_async` 函数从头到尾走一遍。

---

## 场景设定

- Agent：一个叫 "Sam" 的助手，agent_id = `agent-001`
- 触发时机：Xavier 刚才对话中说了"我换工作了，去了一家对冲基金"，agent 调用了 `core_memory_replace` 工具，把 human block 更新了
- 现在这一轮新的用户消息进来，agent 在真正调用 LLM 之前，先执行 `_rebuild_memory_async` 来确保 system message 是最新的

---

## 第 1 步：刷新内存块

```python
agent_state = await self.agent_manager.refresh_memory_async(agent_state=agent_state, actor=self.actor)
```

数据库里 human block 已经被工具调用更新为：

```
User's name is Xavier. Xavier just switched jobs to a hedge fund.
```

（旧版本是 `"User's name is Xavier. Xavier works on time series forecasting."`）

这一步把最新的 blocks 拉进 `agent_state.memory.blocks`。

---

## 第 2 步：收集额外上下文

```python
tool_constraint_block = tool_rules_solver.compile_tool_rule_prompts()
# 假设返回： "Rule: use send_message as last step"

archive = await archive_manager.get_default_archive_for_agent_async(agent_id="agent-001", ...)
# 假设该 agent 绑定了一个 archive，里面存过一些历史笔记

archive_tags = await self.passage_manager.get_unique_tags_for_archive_async(archive_id=archive.id, ...)
# 假设返回： ["career", "forecasting", "meetings"]
```

---

## 第 3 步：取出旧的 system message，编译新的内存字符串

```python
curr_system_message = in_context_messages[0]
curr_system_message_text = curr_system_message.content[0].text
```

假设数据库里存的旧 `curr_system_message_text`（上一轮生成、还没更新）是：

```
You are a helpful assistant named Sam.

<memory_blocks>
<persona>
I am Sam, a friendly assistant.
</persona>
<human>
User's name is Xavier. Xavier works on time series forecasting.
</human>
</memory_blocks>

<tool_usage_rules>
Rule: use send_message as last step
</tool_usage_rules>
```

现在重新编译：

```python
curr_memory_str = agent_state.memory.compile(
    tool_usage_rules=tool_constraint_block,
    sources=agent_state.sources,
    max_files_open=agent_state.max_files_open,
    llm_config=agent_state.llm_config,
)
```

因为 human block 已经变了，`curr_memory_str` 现在是：

```
<memory_blocks>
<persona>
I am Sam, a friendly assistant.
</persona>
<human>
User's name is Xavier. Xavier just switched jobs to a hedge fund.
</human>
</memory_blocks>

<tool_usage_rules>
Rule: use send_message as last step
</tool_usage_rules>
```

---

## 第 4 步：判断是否需要重建

```python
system_prompt_changed = agent_state.system not in curr_system_message_text
# agent_state.system = "You are a helpful assistant named Sam."
# 这句话原封不动地在旧文本里 → False（没变）

memory_changed = curr_memory_str not in curr_system_message_text
# 新编译出的这一整段（包含"just switched jobs to a hedge fund"）
# 在旧文本里根本找不到 → True（变了！）

if (not system_prompt_changed) and (not memory_changed):
    # False and False = False，条件不成立，不会走这里
    return in_context_messages
```

判断结果：**需要重建**，继续往下走。

---

## 第 5 步：统计消息数和 archival 数量

```python
memory_edit_timestamp = get_utc_time()
# 假设 = 2026-07-04T10:30:00Z

num_messages = await self.message_manager.size_async(actor=..., agent_id="agent-001")
# 假设整个对话历史总共有 150 条消息

num_archival_memories = await self.passage_manager.agent_passage_size_async(...)
# 假设 archive 里存了 42 条 passage
```

---

## 第 6 步：生成完整新 system message

```python
new_system_message_str = PromptGenerator.get_system_message_from_compiled_memory(
    system_prompt=agent_state.system,
    memory_with_sources=curr_memory_str,
    agent_id="agent-001",
    conversation_id="conv-abc",
    in_context_memory_last_edit=memory_edit_timestamp,
    timezone=agent_state.timezone,
    previous_message_count=num_messages - len(in_context_messages),
    # 假设 in_context_messages 只有 20 条（因为之前 summarize 过），150 - 20 = 130
    archival_memory_size=42,
    archive_tags=["career", "forecasting", "meetings"],
)
```

假设拼装结果为：

```
You are a helpful assistant named Sam.

<memory_blocks>
<persona>
I am Sam, a friendly assistant.
</persona>
<human>
User's name is Xavier. Xavier just switched jobs to a hedge fund.
</human>
</memory_blocks>

<tool_usage_rules>
Rule: use send_message as last step
</tool_usage_rules>

<memory_metadata>
- last_modified: 2026-07-04T10:30:00Z
- previous_message_count: 130
- archival_memory_size: 42
- archive_tags: career, forecasting, meetings
</memory_metadata>
```

---

## 第 7 步：diff 比对 + 落库

```python
diff = united_diff(curr_system_message_text, new_system_message_str)
```

`difflib.unified_diff` 会输出类似：

```diff
- User's name is Xavier. Xavier works on time series forecasting.
+ User's name is Xavier. Xavier just switched jobs to a hedge fund.
```

（还会包括 metadata 部分因为时间戳、message_count、archival_size 也都变了，所以 diff 不为空）

```python
if len(diff) > 0:
    logger.debug(f"Rebuilding system with new memory...\nDiff:\n{diff}")

    new_system_message = await self.message_manager.update_message_by_id_async(
        curr_system_message.id,
        message_update=MessageUpdate(content=new_system_message_str),
        actor=self.actor,
        project_id=agent_state.project_id,
    )
    return [new_system_message, *in_context_messages[1:]]
```

**结果**：数据库里 `curr_system_message.id` 对应的那条消息内容被更新成新文本；函数返回一个新的消息列表，第一条是刚更新的 system message，后面 19 条历史消息原样不动（`in_context_messages[1:]`）。

---

## 对照：如果本轮内存根本没变会怎样

如果 Xavier 只是随便问了句 "今天天气怎么样"，没有触发任何内存修改工具调用：

- 第 1 步刷新完，blocks 内容跟上次一模一样
- 第 3 步编译出的 `curr_memory_str` 跟旧文本里的内存部分完全相同
- 但是！`system_prompt_changed` 和 `memory_changed` 只检查这两块**内容本身**，不检查 metadata（时间戳、message_count 这些）
- 所以哪怕这两个判断都是 `False`（直接在第 4 步就 `return in_context_messages`，甚至都不会走到第 5、6、7 步去重新拉 message 数量、生成新字符串），**完全不碰数据库**，这轮请求走的是最快路径。

---

## 设计要点总结

| 要点 | 说明 |
|------|------|
| 轻量级子串过滤 | 第 4 步用 `in` 操作符做子串检查，O(n) 成本，拦截掉绝大多数无变化场景，避免不必要的 DB 查询 |
| 精确 diff 只做一次 | 只有子串检查发现变化后，才调用 `unified_diff` 做精确比对，且只在 diff 非空时写库 |
| metadata 不参与过滤 | `system_prompt_changed` 和 `memory_changed` 只检查核心内容，时间戳/message_count 等元数据变化**不会**触发重建——这是有意为之，避免每次请求都因为时间戳变了而重写 system message |
| 就地更新而非追加 | `update_message_by_id_async` 直接覆盖原 system message 的 content，而不是新增一条，保证 `in_context_messages[0]` 始终是唯一且最新的 system message |
| 拼接方式 | `[new_system_message, *in_context_messages[1:]]` 只替换第一条，后面历史消息引用不变，避免不必要的对象拷贝 |

这就是这个函数设计的巧妙之处：**用一个"轻量级子串检查"做第一道过滤（避免大部分无变化场景下的数据库查询和字符串拼接开销），只有真正怀疑变化时才去精确计算并写库**。
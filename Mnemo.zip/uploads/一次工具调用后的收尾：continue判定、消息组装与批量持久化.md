---
title: 一次工具调用后的收尾：continue判定、消息组装与批量持久化
summary: _decide_continuation 与 create_letta_messages_from_llm_response 的完整解析：多规则优先级叠加决定是否继续 step 循环，以及本轮 assistant/tool 消息的组装与持久化
project: letta
tags: [letta, agent-loop, step, _decide_continuation, create_letta_messages_from_llm_response, persistence]
created: 2026-07-04
updated: 2026-07-04
status: completed
confidence: high
---

# 一次工具调用后的收尾：continue判定、消息组装与批量持久化

这段代码在做两件事：**① 决定这一步之后 agent 要不要继续跑；② 把这一轮的所有产出（assistant 消息 + tool 消息）组装并持久化**

---

## 一、`_decide_continuation` —— 决定要不要继续 step 循环

Letta 的 agent 是"多步自循环"的：一次工具调用执行完之后，到底是就此打住等用户说话，还是自己接着推理下一步，取决于好几个规则的**优先级叠加**。这个函数把散落各处的判断逻辑收拢到一起：

```python
continue_stepping = request_heartbeat   # 起点：模型自己在 tool_call 参数里声明的意愿
```

### 1.1 规则违反优先（最高优先级之一）

```python
if tool_rule_violated:
    continue_stepping = True
    heartbeat_reason = "...tool rule violation."
```

如果模型调用了一个当前不允许调用的工具（比如工具依赖链顺序不对），Letta 强制继续跑一步——目的是把"报错信息"喂回给模型，让它有机会自己纠正，而不是直接卡死在这里。

### 1.2 正常情况下走工具规则引擎（`tool_rules_solver`）

- `tool_rules_solver.register_tool_call(...)`：登记这次调用了哪个工具，供后续规则判断状态机用。
- **终止工具（terminal tool）**：如果这个工具被标记为"调用完就该结束"（比如 `send_message`），强制 `continue_stepping = False`。但注意如果模型自己之前想继续（`continue_stepping` 之前是 `True`），这里还会补一个 `stop_reason = tool_rule`，明确记录"是因为工具规则才停下的"，而不是模型自己决定停的。
- **有子工具依赖（children tools）**：这个工具后面必须紧跟着调用别的工具，强制继续。
- **continue 类型工具**：某些工具被显式标记为"调用完必须继续"，同样强制继续。

### 1.3 硬性覆盖（hard stop overrides）——优先级最高

会覆盖上面所有判断：

```python
if is_final_step:
    continue_stepping = False
    stop_reason = LettaStopReason(stop_reason=StopReasonType.max_steps.value)
```

如果已经跑到了这个 run 允许的最大步数，不管前面怎么判断，强制停止，并标记停止原因是"达到步数上限"（防止死循环、防止无限消耗 token）。

否则再检查：

```python
uncalled = tool_rules_solver.get_uncalled_required_tools(...)
if not continue_stepping and uncalled:
    continue_stepping = True
    heartbeat_reason = f"...user expects these tools: [...] to be called still."
    stop_reason = None
```

如果 agent 配置里有"必须调用"的工具（`required_tools`）还没被调用过，即使前面判定要停，这里也强制继续，并把之前可能设置的 `stop_reason` 清空——因为还没真正结束。

### 1.4 返回值

```
(continue_stepping, heartbeat_reason, stop_reason)
```

- `continue_stepping`：是否继续
- `heartbeat_reason`：如果继续的话给模型看的"继续理由"提示语
- `stop_reason`：如果停止的话记录的停止原因

---

## 二、`create_letta_messages_from_llm_response` —— 组装这一轮真正要落库/发给模型的消息

拿到 `continue_stepping` 之后，就该把这一整轮的产出打包成消息对象了。这个函数干了几件事：

### 2.1 重新校正 `request_heartbeat`

```python
if force_set_request_heartbeat:
    function_arguments[REQUEST_HEARTBEAT_PARAM] = continue_stepping
```

注意：这里**不是**用模型自己原本传的 `request_heartbeat` 值，而是用刚刚 `_decide_continuation` **计算出来的最终值**覆盖回去。这很关键——因为模型自己想不想继续，只是众多输入之一，最终落库存档的 `tool_call.arguments` 里的 `request_heartbeat` 必须反映**系统综合判断后的真实结果**，这样以后回放这条历史消息时（比如做审计、做 few-shot、或者被审批重放）能看到的是"最终生效的决定"，而不是模型一开始拍脑袋的意愿。

### 2.2 构造 assistant 消息（代表"模型这一步做了什么"）

- 把 `function_name` + 更新过的 `function_arguments` 序列化成一个标准 `OpenAIToolCall`；
- 把 `reasoning_content`（模型的思考过程/推理内容）挂到 `content` 上，同时过滤掉空文本内容；
- 如果外部已经提前算好了 `pre_computed_assistant_message_id`（用于跟前端流式展示的 message id 对齐），就复用它，而不是生成新 id。

### 2.3 构造 tool 消息（代表"工具执行的结果"）

```python
packaged_function_response = package_function_response(tool_execution_result.success_flag, function_response, timezone)
tool_message = Message(role=MessageRole.tool, content=[TextContent(text=packaged_function_response)], ...)
```

把 `function_response_string`（前面已经按 `return_char_limit` 裁剪过的工具返回值）连同成功/失败状态、时区信息一起包装成一段标准格式的文本（大概率是加了 `status: success/error` 之类的元信息前缀），作为 `role=tool` 的消息挂进去，之后会被塞进对话历史发回给 LLM，让它在下一轮"看到"工具执行结果。

### 2.4 `is_approval_response=is_approval or is_denial`

如果这一轮本身就是"审批通过后的重放"或者"审批被拒绝"这两种特殊情况之一，就跳过重复生成 assistant 消息那一段（`if not is_approval_response:` 那个大分支），因为对应的 assistant 消息在**发起审批请求的那一轮**就已经存过一次了，这里不需要再存一遍重复的"模型调用了这个工具"的消息，只需要处理 tool 消息（结果）部分。

---

## 三、两步合起来看

```
_decide_continuation
   → 综合"模型自己的意愿 + 工具规则引擎 + 步数上限 + 必调工具"
     算出这一轮结束后到底继续还是停止，以及为什么

create_letta_messages_from_llm_response
   → 用这个最终决定，把 request_heartbeat 重新写回参数里落库
   → 组装出这一轮真正该持久化的 assistant 消息（模型做了什么）+ tool 消息（结果是什么）

messages_to_persist = (initial_messages or []) + tool_call_messages
persisted_messages = await self.message_manager.create_many_messages_async(...)
return persisted_messages, continue_stepping, stop_reason
```

最后统一批量写库（`create_many_messages_async`），并把 `continue_stepping` 和 `stop_reason` 一起返回给外层的 `step()` 主循环——外层就靠这两个值决定：是直接结束这次请求返回给用户，还是自动发起下一轮 LLM 调用继续跑下去。

---

## 四、一句话总结

**这段代码是"一次工具调用结束后，决定 agent 接下来该停还是该继续，并把这一步产生的模型消息和工具结果消息打包持久化"的收尾逻辑——是整个多步 agent loop 能不能正确推进、正确停止的核心决策点。**
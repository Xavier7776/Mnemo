---
title: 三种记忆联动：工具路由工厂、System Prompt组装管线与内置/沙箱执行分离
summary: Letta 模块六源码学习总结，覆盖 ToolExecutorFactory 七类映射、_handle_ai_response 五步处理链、_execute_tool 按 name 匹配、_rebuild_memory_async 重新编译 system prompt、BASE_MEMORY_TOOLS 四代工具集、三种记忆在 system prompt 中的各自位置
project: letta
tags: [letta, tool-routing, system-prompt, memory-compile, tool-executor, factory-pattern, source-code]
created: 2026-07-03
updated: 2026-07-03
status: completed
confidence: high
---

# 三种记忆联动：工具路由工厂、System Prompt组装管线与内置/沙箱执行分离

## 一句话概括

Letta 没有统一的"路由表"——LLM 返回的 tool name 先在 `_execute_tool` 里靠 `agent_state.tools` 列表线性匹配找到 `Tool` 对象，再由 `ToolExecutorFactory` 按 `tool.tool_type` 分发到七种 executor；三种记忆在 system prompt 里的位置各不相同：Core Memory 编译成 XML 直接注入，Archival/Recall 只在 metadata 块里告诉 agent "有多少条、用什么工具搜"。

---

## 1. 工具路由全景：从 LLM 返回到函数执行

```
LLM 返回 tool_call (name + args)
        │
        ▼
┌─────────────────────────────────────────┐
│ _handle_ai_response (letta_agent.py)    │
│  1. 解析 tool_call_name / tool_args     │
│  2. 弹出 request_heartbeat / inner_thoughts │
│  3. 检查是否需要 approval               │
│  4. 检查 tool_rules 是否违规            │
│  5. 调用 _execute_tool                  │
└─────────────────────────────────────────┘
        │
        ▼
┌─────────────────────────────────────────┐
│ _execute_tool (letta_agent.py:1995)     │
│  → next(x for x in agent_state.tools    │
│         if x.name == tool_name)         │
│  → 找不到返回 "Tool not found" error    │
│  → 构造 ToolExecutionManager            │
│  → 调 execute_tool_async                │
└─────────────────────────────────────────┘
        │
        ▼
┌─────────────────────────────────────────┐
│ ToolExecutionManager.execute_tool_async │
│  (tool_execution_manager.py:95)         │
│  → ToolExecutorFactory.get_executor(    │
│      tool.tool_type)                    │
│  → executor.execute(name, args, tool)   │
└─────────────────────────────────────────┘
        │
        ▼
┌─────────────────────────────────────────┐
│ 具体 Executor（七选一）                  │
│  LettaCoreToolExecutor                  │
│  SandboxToolExecutor                    │
│  LettaBuiltinToolExecutor               │
│  LettaFileToolExecutor                  │
│  ExternalMCPToolExecutor                │
└─────────────────────────────────────────┘
```

> [!note] 关键设计
> **没有特殊的路由表**。LLM 返回的 tool name → `_execute_tool` 里用 `next((x for x in agent_state.tools if x.name == tool_name), None)` **线性遍历** `agent_state.tools` 列表，按 name 匹配找到 `Tool` 对象。找到后，真正的"路由"发生在 `ToolExecutorFactory`——按 `tool.tool_type` 字段分发。

---

## 2. ToolExecutorFactory：七类 tool_type 到 executor 的映射

**源码位置**：`tool_execution_manager.py:32-65`

```python
class ToolExecutorFactory:
    _executor_map: ClassVar[Dict[ToolType, Type[ToolExecutor]]] = {
        ToolType.LETTA_CORE:            LettaCoreToolExecutor,
        ToolType.LETTA_MEMORY_CORE:     LettaCoreToolExecutor,
        ToolType.LETTA_SLEEPTIME_CORE:  LettaCoreToolExecutor,
        ToolType.LETTA_MULTI_AGENT_CORE: SandboxToolExecutor,
        ToolType.LETTA_BUILTIN:         LettaBuiltinToolExecutor,
        ToolType.LETTA_FILES_CORE:      LettaFileToolExecutor,
        ToolType.EXTERNAL_MCP:          ExternalMCPToolExecutor,
    }

    @classmethod
    def get_executor(cls, tool_type, ...) -> ToolExecutor:
        executor_class = cls._executor_map.get(tool_type, SandboxToolExecutor)
        return executor_class(...)
```

| ToolType | Executor | 说明 |
|----------|----------|------|
| `LETTA_CORE` | `LettaCoreToolExecutor` | 基础对话工具（send_message、conversation_search、archival_memory_insert/search） |
| `LETTA_MEMORY_CORE` | `LettaCoreToolExecutor` | Core Memory 写入工具（core_memory_append/replace、memory、memory_apply_patch 等） |
| `LETTA_SLEEPTIME_CORE` | `LettaCoreToolExecutor` | Sleeptime 专用工具集 |
| `LETTA_MULTI_AGENT_CORE` | `SandboxToolExecutor` | 多 agent 通信工具（send_message_to_agent 等） |
| `LETTA_BUILTIN` | `LettaBuiltinToolExecutor` | 内置工具（run_code、web_search、fetch_webpage） |
| `LETTA_FILES_CORE` | `LettaFileToolExecutor` | 文件操作工具（open_files、grep_files、semantic_search_files） |
| `EXTERNAL_MCP` | `ExternalMCPToolExecutor` | 外部 MCP 服务器工具 |
| **其他/未知** | `SandboxToolExecutor`（默认） | 用户自定义工具 → 沙箱执行 |

> [!tip] 三个核心 / 三个记忆类型的对应关系
> - `LETTA_CORE`：包含 Recall（conversation_search）和 Archival（archival_memory_search/insert）的检索工具
> - `LETTA_MEMORY_CORE`：包含 Core Memory 的读写工具
> - 三种都路由到同一个 `LettaCoreToolExecutor`，因为它们的执行逻辑都在同一个 `function_map` 字典里

---

## 3. LettaCoreToolExecutor 的 function_map

**源码位置**：`core_tool_executor.py:29-76`

```python
class LettaCoreToolExecutor(ToolExecutor):
    async def execute(self, function_name, function_args, tool, actor, agent_state, ...):
        function_map = {
            "send_message":           self.send_message,
            "conversation_search":    self.conversation_search,        # Recall Memory
            "archival_memory_search": self.archival_memory_search,     # Archival Memory
            "archival_memory_insert": self.archival_memory_insert,     # Archival Memory
            "core_memory_append":     self.core_memory_append,         # Core Memory v1
            "core_memory_replace":    self.core_memory_replace,        # Core Memory v1
            "memory_replace":         self.memory_replace,             # Core Memory v2
            "memory_insert":          self.memory_insert,              # Core Memory v2
            "memory_apply_patch":     self.memory_apply_patch,         # Core Memory unified-diff
            "memory_str_replace":     self.memory_str_replace,
            "memory_str_insert":      self.memory_str_insert,
            "memory_rethink":         self.memory_rethink,
            "memory_finish_edits":    self.memory_finish_edits,
            "memory":                 self.memory,                     # Core Memory v3 统一入口
        }
        function_response = await function_map[function_name](agent_state, actor, **function_args_copy)
```

> [!note] 内置记忆工具 vs 自定义工具的本质区别
> - **内置记忆工具**（`LettaCoreToolExecutor`）：`function_map` 字典直接映射到 Python 方法，**进程内直接调用**，不需要序列化/反序列化、不需要沙箱
> - **自定义工具**（`SandboxToolExecutor`）：需要在沙箱（Modal/E2B/Local）里执行用户提供的 Python/TypeScript 源码，有完整的沙箱生命周期管理（创建→执行→销毁）、凭证注入、内存完整性校验

---

## 4. SandboxToolExecutor 的执行链路

**源码位置**：`sandbox_tool_executor.py:24-147`

```
SandboxToolExecutor.execute()
  │
  ├── 1. 记录原始 memory 状态（orig_memory_str = memory.compile()）
  │
  ├── 2. 获取凭证（SandboxCredentialsService.fetch_credentials）
  │     合并 sandbox_env_vars + fetched_credentials + PROJECT_ID
  │
  ├── 3. 选择沙箱后端（优先级）
  │     ├── Modal（如果 tool metadata 请求 + Modal 已配置）
  │     ├── E2B（如果 sandbox_type == E2B）
  │     └── Local（默认 fallback）
  │
  ├── 4. 在沙箱中执行 tool.run(agent_state_copy)
  │
  ├── 5. 内存完整性校验
  │     assert orig_memory_str == new_memory_str
  │     "Memory should not be modified in a sandbox tool"
  │
  └── 6. 如果 tool_execution_result.agent_state 有变更 → update_memory_if_changed_async
```

> [!warning] 沙箱工具不能直接改 Core Memory
> 第 5 步的 assert 是一道防线：沙箱工具执行前后，`memory.compile()` 的输出必须一致。沙箱工具如果需要修改 Core Memory，必须通过返回 `agent_state` 让 `update_memory_if_changed_async` 来做——不能在沙箱里直接改。这保证了 Core Memory 的写入只走 `LettaCoreToolExecutor` 这条受控路径。

---

## 5. _handle_ai_response 的五步处理链

**源码位置**：`letta_agent.py:1788-1946`

| 步骤 | 做什么 | 关键代码 |
|:---:|------|------|
| 1 | **解析工具调用** | `tool_call_name = tool_call.function.name`<br>`tool_args = _safe_load_tool_call_str(tool_call.function.arguments)` |
| 2 | **弹出非真实参数** | `request_heartbeat = _pop_heartbeat(tool_args)`<br>`tool_args.pop(INNER_THOUGHTS_KWARG, None)` |
| 3 | **审批检查** | `if tool_rules_solver.is_requires_approval_tool(tool_call_name):`<br>→ 生成 approval_request，停止 stepping |
| 4 | **工具规则校验 + 执行** | `if tool_call_name not in valid_tool_names:` → 规则违规<br>否则 → `self._execute_tool(...)` |
| 5 | **准备响应 + 决定是否继续** | `validate_function_response` → `package_function_response`<br>`_decide_continuation` 判断是否继续 stepping |

> [!note] 三种"非正常"路径
> - **is_denial**：用户拒绝审批 → 生成 error result + heartbeat continue
> - **is_requires_approval**：需要审批但用户还没批 → 生成 approval_request + stop
> - **tool_rule_violated**：工具名不在 valid_tool_names 里 → 生成 rule violation result + heartbeat continue

---

## 6. _rebuild_memory_async：每次请求前重新编译 system prompt

**源码位置**：`base_agent.py:93-186`

```
_rebuild_memory_async(in_context_messages, agent_state)
  │
  ├── 1. 从 DB 刷新 blocks → agent_state.memory.blocks
  │     agent_manager.refresh_memory_async(agent_state)
  │
  ├── 2. 编译 tool rules（如果有）
  │     tool_rules_solver.compile_tool_rule_prompts()
  │
  ├── 3. 获取 archival tags（如果有 archive）
  │     passage_manager.get_unique_tags_for_archive_async()
  │
  ├── 4. 编译 memory → XML 字符串
  │     curr_memory_str = agent_state.memory.compile(
  │         tool_usage_rules=tool_constraint_block,
  │         sources=agent_state.sources,
  │         max_files_open=agent_state.max_files_open,
  │         llm_config=agent_state.llm_config,
  │     )
  │
  ├── 5. 变更检测（跳过优化）
  │     if system_prompt 没变 and memory 没变:
  │         return in_context_messages  # 不重建
  │
  ├── 6. 调 PromptGenerator.get_system_message_from_compiled_memory
  │     把 memory_str + metadata 拼成完整 system message
  │
  └── 7. 更新 DB 中的 system message
        message_manager.update_message_by_id_async(curr_system_message.id, ...)
        return [new_system_message, *in_context_messages[1:]]
```

> [!tip] 变更检测优化
> 第 5 步是性能优化：如果 system prompt 和 memory 自上次以来都没变（字符串包含检查），直接返回原消息列表，跳过 DB 写入。避免了每步都无谓地重建 system prompt。

---

## 7. System Prompt 的最终结构

`PromptGenerator.get_system_message_from_compiled_memory` 组装的最终 system prompt：

```
┌─────────────────────────────────────────────────────┐
│ 用户定义的 system prompt 模板                        │
│ （含 {core_memory} 占位符，或自动追加到末尾）         │
│                                                     │
│ ┌─────────────────────────────────────────────────┐ │
│ │ <memory_blocks>          ← Core Memory 编译     │ │
│ │   <persona>                                     │ │
│ │     <description>...</description>              │ │
│ │     <metadata>                                  │ │
│ │       - chars_current=XXX                       │ │
│ │       - chars_limit=XXXX                        │ │
│ │     </metadata>                                 │ │
│ │     <value>实际内容</value>                      │ │
│ │   </persona>                                    │ │
│ │   <human>...</human>                            │ │
│ │ </memory_blocks>                                │ │
│ │                                                 │ │
│ │ <tool_usage_rules>  ← 工具规则（如果有）          │ │
│ │   ...                                           │ │
│ │ </tool_usage_rules>                             │ │
│ │                                                 │ │
│ │ <file_directories>   ← 文件源（如果有）           │ │
│ │   ...                                           │ │
│ │ </file_directories>                             │ │
│ │                                                 │ │
│ │ <memory_metadata>     ← 三种记忆的元数据          │ │
│ │   - AGENT_ID: xxx                              │ │
│ │   - CONVERSATION_ID: xxx                       │ │
│ │   - System prompt last recompiled: 时间戳       │ │
│ │   - N previous messages in recall memory       │ │
│ │   - M total memories in archival memory        │ │
│ │   - Available archival memory tags: ...         │ │
│ │ </memory_metadata>                              │ │
│ └─────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────┘
```

### 三种记忆在 system prompt 里的位置

| 记忆类型 | 在 system prompt 里的位置 | LLM 怎么访问 |
|----------|--------------------------|:---:|
| **Core Memory** | `<memory_blocks>` XML 标签，**全文直接注入** | 始终可见，不需搜索 |
| **Archival Memory** | `<memory_metadata>` 里只写"M 条存在 archival memory"+ 可用 tags | 调 `archival_memory_search` |
| **Recall Memory** | `<memory_metadata>` 里只写"N 条存在 recall memory" | 调 `conversation_search` |

> [!note] 设计意图
> Core Memory 是"始终在眼前的便签"——LLM 每轮都能看到，不调工具就能读写。Archival 和 Recall 是"知道存在哪、知道有多少条、但需要主动搜索才能看到内容"——system prompt 里只放元数据（条数 + tags），不放内容，省 token。

---

## 8. BASE_MEMORY_TOOLS 四代工具集

**源码位置**：`constants.py:115-131`

| 常量 | 工具列表 | 用途 |
|------|---------|------|
| `BASE_TOOLS` | `send_message`, `conversation_search`, `archival_memory_insert`, `archival_memory_search` | 基础工具（不可编辑），覆盖 Recall + Archival |
| `BASE_MEMORY_TOOLS` | `core_memory_append`, `core_memory_replace`, `memory`, `memory_apply_patch` | v1 Core Memory 工具（可编辑） |
| `BASE_MEMORY_TOOLS_V2` | `memory_replace`, `memory_insert` | v2 精细编辑工具（配合 memgpt_v2 prompt） |
| `BASE_MEMORY_TOOLS_V3` | `memory` | v3 统一入口（Anthropic 专用，一个工具分发所有操作） |
| `BASE_SLEEPTIME_TOOLS` | `memory_replace`, `memory_insert`, `memory_rethink`, `memory_finish_edits` | Sleeptime agent 专用 |
| `BUILTIN_TOOLS` | `run_code`, `run_code_with_tools`, `web_search`, `fetch_webpage` | 内置能力工具 |
| `FILES_TOOLS` | `open_files`, `grep_files`, `semantic_search_files` | 文件操作工具 |
| `MULTI_AGENT_TOOLS` | `send_message_to_agent_and_wait_for_reply` 等 | 多 agent 通信 |

> [!note] 工具集演进趋势
> v1 → v2 → v3 的趋势是**从多工具到统一入口**：v1 有 `core_memory_append`/`replace` 两个独立工具，v2 增加了 `memory_replace`/`insert`/`rethink` 更精细的编辑，v3 则收敛成一个 `memory` 万能工具——LLM 通过子命令（create/str_replace/insert/delete/rename）分发。减少了 LLM 需要记住的工具数量，降低了误用率。

---

## 快速参考卡

| 问题 | 答案 |
|------|------|
| LLM 返回 tool name 怎么找到具体函数？ | `_execute_tool` 里 `next(x for x in agent_state.tools if x.name == tool_name)` 线性匹配，再由 `ToolExecutorFactory` 按 `tool_type` 分发 |
| 内置记忆工具和自定义工具的区别？ | 内置 → `LettaCoreToolExecutor` 的 `function_map` 字典，进程内直接调用；自定义 → `SandboxToolExecutor`，沙箱（Modal/E2B/Local）里执行 |
| 三种记忆在 system prompt 里各占什么位置？ | Core Memory → `<memory_blocks>` 全文注入；Archival/Recall → `<memory_metadata>` 只写条数 + tags |
| 工厂模式有几种 executor？ | 7 种 tool_type 映射到 5 种 executor（3 种 CORE 共用 LettaCoreToolExecutor） |
| 沙箱工具能直接改 Core Memory 吗？ | 不能——assert 校验 `memory.compile()` 执行前后一致，只能通过返回 agent_state 让框架代改 |
| _rebuild_memory_async 什么时候跳过重建？ | system prompt 和 memory 字符串都没变时（变更检测优化） |
| 为什么 v3 只有一个 `memory` 工具？ | 统一入口 + 子命令分发，减少 LLM 需要记住的工具数量 |

---

## 踩坑清单

1. **`_execute_tool` 是 O(n) 线性匹配**：`next(x for x in agent_state.tools if x.name == tool_name)` 是线性扫描。工具数量多时（比如 50+ 个自定义工具），每次 tool call 都要遍历——虽然实际上 agent 的工具列表通常不会那么长，但如果做了工具动态加载/卸载的场景需要注意。
2. **`LETTA_MULTI_AGENT_CORE` 走的是 SandboxToolExecutor 而不是 LettaCoreToolExecutor**：多 agent 通信工具虽然名字里带 "CORE"，但执行走沙箱——因为这些工具需要访问其他 agent 的状态，涉及跨 agent 通信，不能像 Core Memory 工具那样直接在进程内操作。
3. **`_rebuild_memory_async` 的变更检测用 `in` 而不是 `==`**：`system_prompt_changed = agent_state.system not in curr_system_message_text`——用的是 `not in`（子字符串检查），不是精确匹配。这是因为 system message 里除了 system prompt 本身还有 memory 编译结果，所以只能做包含检查。如果 system prompt 恰好是 system message 的子串（短 prompt + 长 memory），可能误判为"没变"而跳过重建。
4. **`memory_metadata` 里 Recall Memory 的条数是 `previous_message_count`**：这个值是 `num_messages - len(in_context_messages)`——即"不在上下文里的消息数"，不是总消息数。如果消息全在上下文里（比如刚初始化），这个值是 0，agent 会以为 recall memory 是空的。

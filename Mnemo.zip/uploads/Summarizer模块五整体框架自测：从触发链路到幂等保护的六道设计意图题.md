---
title: Summarizer模块五整体框架自测：从触发链路到幂等保护的六道设计意图题
summary: Letta 源码模块五（Summarizer）整体框架自测，覆盖 compact_messages 降级链路、self 与 非 self 的 context_window 选择、role=summary 的工程意义、Core Memory 保护、token 预算口径、双层幂等保护，含自答 + 代码纠错反馈
project: letta
tags: [letta, summarizer, compact, self-test, token-budget, idempotent, source-code]
created: 2026-07-03
updated: 2026-07-03
status: completed
confidence: high
---

# Summarizer模块五整体框架自测：从触发链路到幂等保护的六道设计意图题

## 快速总结

六道框架题，不抠行号细节，考"设计意图"和"模块之间怎么咬合"。每题含**自答** + **代码核实后的纠错/补充**。

| 题号 | 主题 | 自评 | 关键遗漏/纠错 |
|:---:|------|:---:|------|
| Q1 | 触发链路与降级 | ✅ | 漏了"验效降级"——成功但 token 仍不达标也会触发再次降级 |
| Q2 | self vs 非 self 的 context_window 选择 | ⚠️ | 答了"不一样"但没答"不一致会怎样"——消费方窗口 vs 生产方窗口，分母必须是 agent 的 |
| Q3 | `role=summary` 解决了什么 | ✅ | 补充"伪造成 user 会污染用户行为分析/统计"的场景 |
| Q4 | Core Memory 会不会被摘要掉 | ✅ | 完全正确 |
| Q5 | token 预算怎么算 | ⚠️ | 答对了"tools 不算会低估"的后半句，漏了前半句——`trigger_threshold` 来源（`thresholds.py`） |
| Q6 | 幂等检查为什么必须存在 | ❌ | 未知 → 补充"主动检测防重复" + "被动触发有重试上限"两层保护 |

---

## Q1. 触发链路与降级

### 题干

`compact_messages` 支持四种 mode。配置 `mode="self_compact_all"`，最坏情况下可能实际经历的完整调用链（含所有可能的降级），并说明每一级降级触发的条件。

### 自答 ✅（大部分对）

> 首先调用 self_compact_all，失败是因为上下文窗口太大导致无法压缩成功 → 降级 self_sliding_window（滑动窗口保留最近 tool/assistant 内容） → 如果还是失败，直接降级到 all 模式用小模型纯文本兜底。

### 纠错：漏了"验效降级"这条路径

降级不只有"异常触发"一条路。`compact_messages` 在后面还做一次**验效检查**：

```python
if trigger_threshold is not None and context_token_estimate >= trigger_threshold:
    # 虽然没报错，但没把 token 压下去
    if summarization_mode_used == "sliding_window":
        summary, compacted_messages = await summarize_all(...)  # 再兜底
```

```mermaid
flowchart TD
    A[self_compact_all] -->|异常| B[self_compact_sliding_window]
    A -->|成功但 token 不达标| B
    B -->|异常| C[all 模式 独立小模型兜底]
    B -->|成功但 token 不达标| C
    C -->|成功| D[返回 CompactResult]
```

> [!note] 关键区分
> - **异常降级**：当前模式内部抛异常 → 进入 except 分支换下一级
> - **验效降级**：当前模式没报错跑完了，但 `context_token_estimate >= trigger_threshold` 说明压缩无效 → 也从滑动窗口再降级到全量

另外：滑动窗口 cutoff 找的是 **assistant 或 approval** 消息（`is_valid_cutoff`），不是 tool——tool 消息必须跟触发它的那条带 `tool_calls` 的 assistant 消息配对，不能单独做 cutoff。

---

## Q2. self vs 非 self 的 context_window 选择

### 题干

`self_compact_*` 和普通 `all`/`sliding_window` 除了"用不用 agent 自己的模型"，还各自依赖了**哪个 LLMConfig 的 context_window** 来做 token 预算判断？两者不一致会不会出问题？为什么 self 模式的滑动窗口 cutoff 始终用 `agent_llm_config.context_window`？

### 自答 ⚠️（方向对，没答到点子上）

> self 用的是 Agent 本身的模型和配置，不是 self 用的是 summary 的 config。模型配置不一样所以 context_window 不一样，以此作为区分。

### 纠错：答了"是什么"，没答"为什么不能反过来"

推理链条应如此：

| 概念 | 角色 | 作用 |
|------|------|------|
| `agent_llm_config.context_window` | **消费方**窗口 | 决定"压缩完之后，agent 自己还能装多少"——这个就是 `goal_tokens` 的分母 |
| `summarizer_llm_config.context_window` | **生产方**窗口 | 只影响"总结这个动作本身能不能塞得下待总结的那批消息" |

> [!danger] 如果两者不一致会怎样
> 假设总结模型窗口比 agent 大（Haiku 200k → agent 只有 32k）。如果 cutoff 计算错误地用了 `summarizer_llm_config.context_window` 做分母：
> - `goal_tokens` 偏大（分母大 → 目标 token 多 → 驱逐比例少）
> - 驱逐得不够狠
> - 压缩完 agent 那 32k 窗口还是会爆
>
> 所以 `self_summarize_sliding_window` 和 `summarize_via_sliding_window` 都**统一用 `agent_llm_config.context_window`** 来算 `goal_tokens`。

> [!tip] 一句话记忆
> **"窗口预算算给谁用，就用谁的 context_window"**——不管总结用什么模型，省出来的空间永远是为了给 agent 主模型腾地方。`llm_config`/`summarizer_llm_config` 只负责"怎么生成摘要"，不负责"生成后剩多少空间"。

---

## Q3. `role=summary` 解决了什么

### 题干

如果一直用 legacy 的"伪装成 user 消息"方案，会带来哪些实际的麻烦？

### 自答 ✅（核心两点都对了）

> 语义清晰，前端和数据库都能识别这是 summary。发给 LLM 时有专门方法转为 user，后端和数据库保留 summary 角色。需要筛选消息时可以传 summary 角色做精准过滤。

### 补充：第三个工程场景

> [!warning] 污染下游逻辑
> legacy 方案把 summary 伪装成 `role=user`，数据库/API 层面**完全分不清"这是真实用户说的话"还是"系统自动生成的摘要"**。不只是"找起来不方便"——会污染所有需要"用户原始输入"的下游逻辑：
>
> - 统计用户消息数：摘要消息被误算
> - 发送用户的聊天记录列表：摘要混进去
> - 用户行为分析/对话质量评估：摘要被当成真实对话处理
>
> 如果没有 `role=summary`，每次都要靠字符串前缀（`"Note: prior messages..."`）去猜测识别，脆弱且容易漏判。`role=summary` 从数据模型层面就杜绝了"猜内容识别身份"的做法。

`_convert_summary_message(as_user_message=...)` 设计体现了核心思路：**存储身份和发送给 LLM 时的表现形式解耦**。

---

## Q4. Core Memory 会不会被摘要掉

### 题干

上下文满了触发压缩时，Core Memory 的 block 会不会被压缩掉？

### 自答 ✅（完全正确）

> 系统提示词不会被压缩（除非超过 context window）。压缩的是系统提示词后面的内容。具体怎么压缩根据选择的 mode 决定。

### 确认：推理链条正确

`compile()` 把 Core Memory 编译成 XML→压成 system prompt→始终是 `messages[0]`。所有摘要逻辑（不管哪个 mode）都是 `messages[1:]` 起步处理，`system_message` 全程被单独摘出来、原样保留、最后拼回 `final_messages[0]`。

唯一例外：如果 system prompt 本身就超过 context window（`SystemPromptTokenExceededError`），直接报错让人工介入——因为 Core Memory 是"必须始终对 LLM 可见"的，压缩它就违背了它存在的意义。

---

## Q5. token 预算的"账"怎么算

### 题干

`trigger_threshold` 大概率是在哪个更上层调用点算出来的？如果它没把 tools 的 token 数算进去会怎样？

### 自答 ⚠️（后半句对，前半句没答）

> tools 如果没有算上去就会严重低估真实的 token 值，因为调用模型时 tool_call 的很多函数如果传的很多也会造成大量 token。

### 补全：trigger_threshold 的来源

```python
# letta/services/summarizer/thresholds.py
def get_compaction_trigger_threshold(llm_config, *, force_proactive=False) -> int:
    return int(llm_config.context_window * SUMMARIZATION_TRIGGER_MULTIPLIER)
```

调用点在 `letta_agent_v3.py`，每次 `step()` 开始时就算好：

```python
compaction_trigger_threshold = get_compaction_trigger_threshold(
    self.agent_state.llm_config
)
```

两个触发点：

| 触发点 | 机制 | 代码位置 |
|--------|------|------|
| **主动检测** | `post_step_context_check`：每步跑完后 `context_token_estimate > threshold` → 触发压缩 | `letta_agent_v3.py` |
| **被动触发** | `context_window_exceeded`：LLM 真的报了超限才触发 | `letta_agent_v3.py` |

> [!note] 为什么阈值的"缺口"靠 `count_tokens_with_tools` 补齐
> `trigger_threshold` 算的时候只用了 `context_window * 百分比`，没额外加 tools 的 token。但实际比较时：
> - 阈值：`context_window * MULTIPLIER`（不含 tools）
> - 实际值：`count_tokens_with_tools`（**含** tools）
>
> 如果 `context_token_estimate` 漏算了 tools：会导致"实际早就超了，但估计值显示还没到 → 不触发压缩 → 直到真的发生 `ContextWindowExceededError` 才被动触发"。这就是 `count_tokens_with_tools` 这个函数存在的必要性——把阈值和实际值拉到同一个"含 tools"的口径下比较。

---

## Q6. 幂等检查

### 自答 ❌（未知）

### 补全：两层幂等保护

**第一层：主动检测本身就是"检查后再触发"，不是"无条件触发"**

```python
# post_step_context_check
if context_token_estimate is not None and \
   context_token_estimate > compaction_trigger_threshold:
    # 才触发压缩
```

每步跑完重新检查 `context_token_estimate`（压缩后这个值会被更新）。如果上一步已压缩过、现在已经低于阈值了，这一步就不会再触发——最基本的幂等保护。

**第二层：被动触发有重试次数上限**

```python
if isinstance(e, ContextWindowExceededError) and \
   llm_request_attempt < summarizer_settings.max_summarizer_retries:
    # 才允许重试压缩
```

压缩后还是超限（摘要生成本身失败 / 压缩力度不够），不会无限循环 → 有 `max_summarizer_retries` 上限。

> [!danger] 没有这两层保护会怎样
>
> **没有第一层**：
> - 每一步都无脑触发压缩，哪怕 token 早就够了
> - 浪费 LLM 调用（压缩本身要调模型生成摘要），费钱 + 拖慢响应
> - **更严重**：反复压缩同一段已被摘要过的历史 → "摘要的摘要的摘要..." → 信息逐渐失真
>
> **没有第二层**：
> - 某次压缩没起到效果（总结模型返回了很长的摘要 → 没省多少 token）
> - "超限 → 压缩 → 还超限 → 再压缩 → ..." 死循环
> - 直到进程挂掉或请求超时，而不是优雅报错

---

## 快速参考卡

| 问题 | 一句话答案 |
|------|------|
| 降级有几条路径？ | 两条：异常降级 + 验效降级（成功但 token 不达标） |
| 滑动窗口 cutoff 找什么消息？ | assistant 或 approval，不是 tool（tool 必须跟 assistant 配对） |
| self 模式窗口分母为什么用 agent 的？ | 省出来的空间是给 agent 用的——消费方窗口决定预算 |
| 如果用了错误的 context_window？ | 分母偏大 → 驱逐不够 → agent 窗口仍爆 |
| `role=summary` 最大好处？ | 数据模型层面杜绝"猜文本内容识别身份"，不污染下游统计 |
| Core Memory 会被压缩吗？ | 不会——始终 `messages[0]`，除非自身超窗口（报错不压缩） |
| `trigger_threshold` 从哪来？ | `thresholds.py` 的 `get_compaction_trigger_threshold`，每次 `step()` 算 |
| 幂等保护有哪两层？ | 主动检测（压缩后不重复触发）+ 被动触发有重试上限 |

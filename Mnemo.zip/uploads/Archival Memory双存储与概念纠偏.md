---
title: 模块三问答归档：Archival Memory双存储、Embedding缓存与Core Memory概念纠偏
summary: 基于源码精读与问答梳理，覆盖 Archival Memory 持久化/检索流程、SQL+Turbopuffer 双存储、embedding 缓存、Core Memory 定义、与论文架构图对照
project: letta
tags: [letta, memory, module3, archival, core-memory, embedding, sql, turbopuffer]
created: 2026-07-01
updated: 2026-07-01
status: completed
confidence: high
---

# 模块三问答归档：Archival Memory双存储、Embedding缓存与Core Memory概念纠偏

> 对应学习计划「模块三：Archival Memory」源码精读 + 自测纠偏 + Core Memory 概念补充

---

## Q1：`pad_embeddings` 校验器解释

**提问代码**：
```python
@field_validator("embedding", mode="before")
@classmethod
def pad_embeddings(cls, embedding: List[float], info) -> List[float]:
    """Pad embeddings to `MAX_EMBEDDING_SIZE`."""
    if embedding is None:
        return embedding
    data = info.data if hasattr(info, "data") else {}
    is_archival = data.get("archive_id") is not None
    is_file = data.get("file_id") is not None
    if settings.letta_pg_uri_no_default:
        from letta.helpers.tpuf_client import should_use_tpuf
        should_pad = is_archival or (is_file and not should_use_tpuf())
        if should_pad:
            import numpy as np
            np_embedding = np.array(embedding)
            if np_embedding.shape[0] != MAX_EMBEDDING_DIM:
                padded_embedding = np.pad(np_embedding, (0, MAX_EMBEDDING_DIM - np_embedding.shape[0]), mode="constant")
                return padded_embedding.tolist()
    return embedding
```

**答案要点**：

`letta/schemas/passage.py` 中 `Passage` 模型的字段验证器，作用是在写入前把 embedding 向量 pad 到统一维度，只在特定存储后端条件下生效。

- `mode="before"`：在 pydantic 校验前拦截原始值，`info.data` 携带同一模型上已解析的其他字段
- 通过 `archive_id`/`file_id` 是否非空判断这是 archival memory passage 还是 file/知识库 passage
- 只有配置了 Postgres（`settings.letta_pg_uri_no_default` 非空，即用 pgvector）才可能触发 pad
- `should_pad = is_archival or (is_file and not should_use_tpuf())`：
  - archival passage：只要用 pgvector 就一定 pad，不管有没有同时用 turbopuffer
  - file passage：只有在没用 turbopuffer 做检索时才 pad
- 实际 pad：`np.pad(..., mode="constant")`，默认用 0 右侧补齐到 `MAX_EMBEDDING_DIM`

**核心设计动机**：pgvector 建表要求固定维度列（`Vector(MAX_EMBEDDING_DIM)`），但 Letta 支持多种 embedding 模型（维度不同）。用统一 pad 到最大维度的方式兼容，而不是为每种模型建不同维度的表。副作用：查询时 query embedding 也要做同样的 pad 才能维度对齐；turbopuffer 原生支持变长向量，是这套 pad hack 的"逃生舱"。

---

## Q2：`get_openai_embedding_async` + `@async_redis_cache` 解释

**提问**："这个不就是传入文本获得embedding后的结果吗，上面的装饰器是什么"

**提问代码**：
```python
@async_redis_cache(key_func=lambda text, model, endpoint: f"{model}:{endpoint}:{text}")
async def get_openai_embedding_async(text: str, model: str, endpoint: str) -> list[float]:
    from letta.settings import model_settings
    client = AsyncOpenAI(api_key=model_settings.openai_api_key, base_url=endpoint, max_retries=0)
    response = await client.embeddings.create(input=text, model=model)
    return response.data[0].embedding
```

**答案要点**：

`async_redis_cache` 是装饰器工厂（`letta/helpers/decorators.py`），给函数外面套了一层透明 Redis 缓存：

1. **key_func**：把入参映射成 Redis key，这里是 `model:endpoint:text` 拼接——同一文本+模型+endpoint 命中同一 key
2. **wrapper 流程**：
   - Redis 不可用 → 走 `NoopAsyncRedisClient`，直接调用原函数（优雅降级）
   - 先查缓存，命中直接反序列化返回，**不会真正调用 OpenAI API**
   - 未命中才执行原函数，真正发请求拿 embedding
   - 结果写回 Redis（`ttl_s=600`，10分钟过期），全程 OpenTelemetry 打点
3. **为什么这么做**：embedding 计算幂等（相同文本+模型→结果一定相同），天然适合缓存，省钱省延迟
4. **附加能力**：`cache_invalidate()`（手动失效）、`cache_stats`（hits/misses/invalidations 计数）

本质：装饰器模式实现的透明缓存层，对调用方函数签名和行为完全不变，内部悄悄加了"先查 Redis、没有再算、算完存回去"的逻辑，且对 Redis 不可用做容错。

---

## Q3：`create_agent_passage_async` 解释

**提问代码**（节选核心逻辑）：
```python
@enforce_types
@trace_method
async def create_agent_passage_async(self, pydantic_passage, actor) -> PydanticPassage:
    if not pydantic_passage.archive_id:
        raise ValueError("Agent passage must have archive_id")
    if pydantic_passage.source_id:
        raise ValueError("Agent passage cannot have source_id")
    data = pydantic_passage.model_dump(to_orm=True)
    tags = data.get("tags")
    if tags:
        tags = list(set(tags))
    embedding = data["embedding"]
    if embedding:
        if not should_use_tpuf():
            # pad embedding to MAX_EMBEDDING_DIM
            ...
    text = data["text"]
    if text and "\x00" in text:
        text = text.replace("\x00", "")
    ...
    async with db_registry.async_session() as session:
        passage = await passage.create_async(session, actor=actor)
        if tags:
            await self._create_tags_for_passage(...)
        return passage.to_pydantic()
```

**答案要点**：

负责把一条 pydantic `Passage` 对象真正落库为 archival memory 记录。

- **装饰器**：`@enforce_types`（运行期类型校验）、`@trace_method`（OpenTelemetry 埋点）
- **前置校验**：必须有 `archive_id`，不能有 `source_id`——用运行期断言把 archival / file 两条分支硬性分开
- **`model_dump(to_orm=True)`**：pydantic → dict，适配 ORM 层字段名（如 `metadata` → `metadata_` 别名映射）
- **tags 去重**：`list(set(tags))`，因为 tags 要"双存储"（JSON 列 + junction table），去重防止 junction table 插入重复行
- **embedding pad**：这里是**手动内联重复实现**，因为 `model_dump()` 之后已脱离 pydantic validator 触发链路，需要在写库前再 pad 一次，是需要同步维护的技术债
- **文本清洗**：去除 `\x00` 空字节，因为 PostgreSQL 拒绝含 NUL 字节的文本，可能来自上传文件/网页抓取内容混入非法字节
- **事务写入**：同一 session 里先插 `ArchivalPassage` 主记录，再插 tags 到 `PassageTag` junction table，保证原子性
- **"双存储"含义**：tags 既存 passage 的 JSON 列（整条读出用），又存独立 junction table（支持高效 DISTINCT / tag 过滤查询）

---

## Q4：`insert_passage` 逻辑解释

**提问代码**（节选核心逻辑）：
```python
@enforce_types
@trace_method
async def insert_passage(self, agent_state, text, actor, tags=None, created_at=None, strict_mode=False):
    archive = await self.archive_manager.get_or_create_default_archive_for_agent_async(...)
    text_chunks = [text]
    if agent_state.embedding_config is not None:
        embedding_client = LLMClient.create(...)
        embeddings = await embedding_client.request_embeddings(text_chunks, agent_state.embedding_config)
    else:
        embeddings = [None] * len(text_chunks)
    passages = []
    for chunk_text, embedding in zip(text_chunks, embeddings):
        passage = await self.create_agent_passage_async(PydanticPassage(**passage_data), actor=actor)
        passages.append(passage)
    if archive.vector_db_provider == VectorDBProvider.TPUF:
        try:
            await tpuf_client.insert_archival_memories(...)
        except Exception as e:
            logger.error(f"Failed to insert passages to Turbopuffer: {e}")
            if strict_mode:
                raise
    return passages
```

**答案要点**：

`insert_passage` 是外部调用创建 archival memory 的主入口，是 `create_agent_passage_async` 之上一层封装：

1. **获取/创建默认 archive**：每个 agent 至少挂一个 archive
2. **`text_chunks = [text]`**：目前是**伪分块**，还没实现真正的长文本自动切分（TODO 注释印证），给未来支持长文本预留接口形状
3. **生成 embedding（可选）**：有 `embedding_config` 才生成向量；没有则 `embedding=None`，只能靠纯文本检索，这是优雅降级设计
4. **先写 SQL（永远的真源）**：注释"Always write to SQL database first"——SQL 是权威数据源，不管后面用不用 turbopuffer，关系型库里必须有一份完整记录
5. **双写 Turbopuffer（条件触发）**：
   - 只有 `archive.vector_db_provider == VectorDBProvider.TPUF` 才双写
   - passage_id 在 SQL 和 tpuf 两边保持一致，方便关联/同步删除
   - embedding 只算一次，复用给 tpuf，不重复调 API
   - **容错策略非对称**：tpuf 写失败默认只记日志不抛异常（SQL 已写成功，数据不丢，只是暂时两边不一致）；只有 `strict_mode=True` 才抛异常

**架构含义**：典型的"SQL 为主、向量库为辅助索引"双存储模式（dual-write pattern）——SQL 保证完整性/持久性/事务性，是唯一真源；Turbopuffer 只是加速语义检索的二级索引，允许短暂不一致，失败也不影响主流程。

---

## Q5："SQL不就是存入db数据吗"

**答案要点**：

对，"SQL"就是关系型数据库（Letta 支持 Postgres 或 SQLite），本质就是"存入 db"。"SQL 是权威数据源"不是说它特殊，而是相对 Turbopuffer 的**架构角色划分**：

- **SQL**：存完整数据，事务保证（ACID），删除/更新都在这里做
- **Turbopuffer**：专用向量检索服务（第三方 serverless 向量数据库），不是关系型数据库，没有事务/外键约束，只存"能支持语义检索"所需最小字段

**设计权衡**：Turbopuffer 检索性能/成本更好，但不适合做"唯一真实数据源"；于是折中——SQL 永远保留完整权威记录（哪怕 tpuf 挂了也能从 SQL 重建索引），Turbopuffer 只是加速检索的"影子副本"，允许偶尔写失败、暂时不一致。

一句话：**写 SQL 失败 → 整个 `insert_passage` 抛异常，记忆没建成功；写 Turbopuffer 失败 → 只记日志报警，SQL 那条记忆依然算建成功，只是没同步进检索索引（除非 strict_mode=True）。**

---

## Q6：模块三自测（对照学习计划）

### 提问 1：Archival vs Core Memory 的根本区别

**我的原答案**："archival是持久化记忆，一直存在数据库中的，不会消失。core memory是在内存中的记忆，不是持久化的，agent和会话都会去archival中读取持久化的记忆而不是core memory"

**纠正**：❌ 方向偏了。两者**都持久化到 DB**，Core Memory 的 Block 对象照样落库，agent 重启、换会话依然还在。真正分界线是**"要不要每次请求都塞进 system prompt"**：
- Core Memory：每次请求都编译进 system prompt，LLM 无需主动操作就能看见
- Archival Memory：默认不在 prompt 里，LLM 必须主动调用 `archival_memory_search` 工具，搜索结果才作为工具返回消息出现

"agent 和会话都会去 archival 中读取"这句也反了——每一轮对话 Core Memory 都会被读取编译进 prompt，Archival 反而是默认不读，主动搜才读。

### 提问 2：embedding 生成时机

**我的原答案**："在写入的时候生成的，生成的时候会把embedding结果放入redis中，没设置embedding-config就不会存储向量化后的结果，会把原文存储进去，进行关键词匹配"

**纠正**：✅ 大方向对（写入时生成、没配置走文本检索）。但"放入 redis"这句要小心——`@async_redis_cache` 加在底层原始函数 `get_openai_embedding_async` 上，而 `insert_passage` 实际调的是 `LLMClient.request_embeddings` 封装，是否最终经过被缓存装饰的函数取决于内部实现，**未验证**，不能直接等同。

### 提问 3：SQL/Turbopuffer 非对称容错

**纠正**：✅ 完全正确，理解扎实。

### 提问 4：padding 触发条件

**我的原答案**："当选择archival的时候强制进行padding至最大维度，file类型的时候不进行padding"

**纠正**：❌ 记反且简化过头。实际三层判断：
- 外层前提：`settings.letta_pg_uri_no_default`（用 pgvector 后端），不成立则完全不 pad
- archival passage：只要用 pgvector 就一定 pad
- file passage：**只有在没用 turbopuffer 时才 pad**——file 也是会 pad 的，不是"file 一定不 pad"

### 提问 5：搜索结果是否自动进 system prompt

**我的原答案**："这个问题我不太清楚...archival_memory会在持久化后更新system memory，core memory不清楚"

**纠正**：诚实说不知道的态度是对的。补充：
- 搜索结果**不会**写进 Core Memory 的固定渲染 block，而是以**工具调用返回消息**的形式出现在当前这轮对话上下文里
- **好处**：不搜索就不占 token 预算，不像 Core Memory 那样永久占位，可以存海量记忆不撑爆 context window
- **代价**：这条结果是临时的，之后触发 Summarizer 压缩时可能被折叠/丢弃，LLM 这轮"看到"不代表下轮还记得，除非主动写回 Core Memory 或再搜一次
- `archival_memory_insert` 后调 `rebuild_system_prompt_async(force=True)` 与"搜索结果进 prompt"是两码事，大概率是因为 archive 的元信息（条目数、chars 统计）变了需要重新编译，跟"把 passage 内容塞进 prompt"无关，**具体重渲染了什么尚未验证**

---

## Q7："什么是core memory"

**答案要点**：

Core Memory 是 Letta 三种记忆里唯一每次请求都会被编译进 system prompt、LLM 无需主动操作就能"看见"的部分，可理解为 agent 的"随身笔记本"。

- **结构**：由若干 Block 对象组成（`letta/schemas/block.py`），字段包括 `label`（标签，如 `human`/`persona`）、`value`（实际内容）、`limit`（最大字符数）、`read_only`（是否允许 LLM 修改）；多个 Block 由 `Memory` 类统一管理
- **持久化**：Block 持久化到数据库，不是纯内存态临时数据
- **渲染**：`Memory.compile()`（第688行起）把所有 block 渲染成 `<label>value</label>` 形式，附带 `chars_current`/`chars_limit` 统计信息暴露给 LLM
- **为什么叫"Core"**：存的是 agent 人格、用户画像等最基础、需要每轮保持一致性的信息，不能等 LLM 主动去搜才拿到
- **修改方式**：LLM 通过内置工具（`core_memory_append`、`memory_replace`、`memory_insert`、`rethink_memory` 等，实现在 `core_tool_executor.py`）编辑 Block 的 `value`

---

## Q8：MemGPT 架构图 —— "core memory不是system prompt吧，是图中的哪一块"

**答案要点**：

图为 MemGPT 原始论文架构图，可用来把术语说精确：

**Core Memory = 橙色的 "Working Context"**，不是黑色的 "System Instructions"。

图中划分：
- **System Instructions**（黑色）：`Read-Only (static)`，标注 "MemGPT System Prompt"——这才是狭义的 system prompt，固定不变
- **Working Context**（橙色）= Core Memory：`Read-Write`，`Write via Functions`（LLM 调工具改写）
- **FIFO Queue**（蓝色）：对话历史滚动队列，对应 Recall Memory 在当前上下文里的部分
- 三者一起构成大括号框住的 **Prompt Tokens**，即喂给 LLM 的完整 context window 输入部分

**更准确的说法**：Core Memory 不等于（狭义的）system prompt，而是和 system prompt 并列存在于同一个 prompt/context window 里的另一个独立区域。

**对应 Letta 代码实现**：Working Context（Core Memory）的渲染结果实际拼接进了**同一个 system role 的消息**里（Core Memory 的 XML 内容和其他固定指令是同一条 system 消息的一部分，不是分开发送的两条消息）。所以更严谨说法：**System Instructions（固定指令）+ Working Context（Core Memory）共同组成了最终那条 system 消息的内容**，两者概念上独立、可写性不同，只是最终落地成同一条消息。

---

## 待验证的开放问题汇总

- [ ] `insert_passage` → `LLMClient.request_embeddings` 调用链，是否最终经过 `@async_redis_cache` 装饰的 `get_openai_embedding_async`
- [ ] `archival_memory_insert` 后触发的 `rebuild_system_prompt_async(force=True)`，具体重新渲染了 system 消息里的哪部分内容

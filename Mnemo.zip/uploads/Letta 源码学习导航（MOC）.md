---
title: Letta 源码学习导航（MOC）
summary: Letta 主分支源码学习笔记的地图页（Map of Content），按六大模块 + 主循环 + 工具执行链路分组串联全部 24 篇笔记，作为知识图谱的 hub
project: letta
tags: [letta, moc, index, source-code, navigation]
created: 2026-07-08
updated: 2026-07-08
status: completed
confidence: high
---

# Letta 源码学习导航（MOC）

> [!info] 这是 Letta 源码学习笔记的地图页
> 全部笔记位于 `个人学习笔记/Letta/`。本页按六大模块 + 主循环 + 工具执行链路分组，点击双向链接跳转。每篇都对照 `letta-ai/letta` 主分支源码核实过。

---

## 📌 总览与汇总

- [[⭐ Letta 记忆系统完整流程总结]] — 六模块整合，记忆系统完整生命周期 + 五大设计原则
- [[⭐⭐ Letta 记忆系统 —— 一次完整请求的详细跑通示例]] — 一次端到端请求的逐步跑通
- [[计划]] — 六大模块学习路线图
- [[MemGPT 架构理解总结]] — MemGPT 原始架构对照

---

## 🧩 模块一：Core Memory 数据结构

> 无独立笔记；相关细节散落在以下两篇：
> - [[Agent每步执行的控制链]]（block/tool_rules 状态机）
> - [[三种记忆联动：工具路由工厂、System Prompt组装管线与内置沙箱执行分离]]（compile 渲染成 XML）

## 🛠 模块二：Core Memory 工具执行层

- [[Core Memory工具执行层]] — 接口与执行分离、写操作三层状态、三代工具集

## 🗄 模块三：Archival Memory

- [[Archival Memory双存储与概念纠偏]] — 双存储、Embedding 缓存、Core Memory 概念纠偏
- [[模块三知识体系总结]] — 双存储架构、优雅降级、持久化可见性分离

## 🔍 模块四：Recall Memory（对话历史检索）

- [[Recall Memory混合检索：双入口架构、Turbopuffer降级与RRF分数融合]] — Agent 级 vs 组织级、RRF 融合

## 🗜 模块五：Summarizer 压缩保护

- [[Agent自压缩：Prompt Cache复用与三级降级兜底的上下文管理机制]] — self-compact 三级降级、token 预算
- [[compact_messages收尾：摘要结构化包装与消息列表拼装的四步收束]] — 收尾四步、role=summary、CompactResult
- [[Summarizer模块五整体框架自测：从触发链路到幂等保护的六道设计意图题]] — 六道框架题自测

## ⚙️ 模块六：工具路由 + 联动 + 执行链路

**路由与系统提示组装**
- [[三种记忆联动：工具路由工厂、System Prompt组装管线与内置沙箱执行分离]] — 工厂映射、system prompt 结构、BASE_MEMORY_TOOLS
- [[工具执行器工厂：ToolType七类映射、沙箱兜底默认与策略注入解耦设计]] — get_executor 工厂模式、策略注入
- [[工具执行异常兜底与完整调用链：CancelledError吸收、finally打点与双层裁剪机制]] — 异常三段、complete 调用链、双层裁剪
- [[_execute_tool详解：工具查找、沙箱环境准备与分层trace打点的编排层]] — 工具查找、sandbox_env_vars、trace 打点

**参数清洗与审批**
- [[假参数清洗：request_heartbeat信号传递与thinking内心独白注入的执行前剥离机制]] — pop 两行、schema 注入
- [[审批挂起机制：request_heartbeat回塞重放、approval消息持久化与step循环挂起]] — 审批持久化、重放

**内存重建与收尾**
- [[_rebuild_memory_async场景走读：内存刷新、System Message重建与轻量diff过滤]] — 每次请求重编译、变更检测
- [[一次工具调用后的收尾：continue判定、消息组装与批量持久化]] — continue 判定、批量持久化
- [[模块六课后题：工具路由、内存重建时机与三种记忆联动的五道设计意图题]] — 五道框架题自测

---

## 🔄 Agent Loop / Step 主循环

- [[Agent每步执行的控制链]] — 审批挂起、取消信号、tool_rules 状态机
- [[Step循环完整调用链]] — 消息列表分工、请求构建、响应解析
- [[Agent两步推理追踪]] — 天气查询到回复的完整消息流
- [[推理前上下文准备]] — Approval 幂等检查、压缩兜底、输入分流

---

## 🔗 跨模块关联速查

| 想理解… | 先看 | 再看 |
|---------|------|------|
| 工具怎么被找到并执行 | [[三种记忆联动：工具路由工厂、System Prompt组装管线与内置沙箱执行分离]] | [[工具执行器工厂：ToolType七类映射、沙箱兜底默认与策略注入解耦设计]] |
| 执行失败后怎么兜底 | [[工具执行异常兜底与完整调用链：CancelledError吸收、finally打点与双层裁剪机制]] | [[一次工具调用后的收尾：continue判定、消息组装与批量持久化]] |
| 上下文满了怎么压 | [[Agent自压缩：Prompt Cache复用与三级降级兜底的上下文管理机制]] | [[compact_messages收尾：摘要结构化包装与消息列表拼装的四步收束]] |
| 参数里的假字段是什么 | [[假参数清洗：request_heartbeat信号传递与thinking内心独白注入的执行前剥离机制]] | [[审批挂起机制：request_heartbeat回塞重放、approval消息持久化与step循环挂起]] |
| 记忆怎么进 system prompt | [[_rebuild_memory_async场景走读：内存刷新、System Message重建与轻量diff过滤]] | [[三种记忆联动：工具路由工厂、System Prompt组装管线与内置沙箱执行分离]] |

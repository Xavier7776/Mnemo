---
title: _execute_tool详解：工具查找、沙箱环境准备与分层trace打点的编排层
summary: 夹在 _handle_ai_response 和 ToolExecutionManager 之间的封装层，负责工具对象查找、沙箱环境变量准备、双层 trace 打点，以及分层职责的完整梳理
project: letta
tags: [letta, _execute_tool, tool-execution, tracing, sandbox, agent-loop]
created: 2026-07-04
updated: 2026-07-04
status: completed
confidence: high
---

# `_execute_tool` 详解

这个函数是"工具执行"这一层的**封装/编排层**，夹在 `_handle_ai_response`（调用方）和 `ToolExecutionManager.execute_tool_async`（真正干活的地方）之间。逐段看：

---

## 一、装饰器与签名

```python
@trace_method
async def _execute_tool(
    self, tool_name: str, tool_args: JsonDict, agent_state: AgentState,
    agent_step_span: Optional["Span"] = None, step_id: str | None = None,
) -> "ToolExecutionResult":
```

- `@trace_method`：给这个方法自动包一层 OpenTelemetry span（自动记录方法名、耗时、异常等），是 Letta 里几乎所有关键方法都会加的通用装饰器，跟函数内部逻辑无关，纯粹是可观测性基础设施。
- `agent_step_span`：调用方（`_handle_ai_response`）传进来的**上一级 span**（代表"这一整个 agent step"）。这里传进来是为了在这个更大的 span 上手动打点事件（不是新开 span，而是往已有 span 里加 event），方便在 trace 系统里把"某个具体工具的执行开始/结束"精确标记在"这个 step"的时间线上。
- 返回值统一是 `ToolExecutionResult`（跟前面几层保持一致，不抛异常，出错也是返回一个带 `status="error"` 的结果对象）。

---

## 二、查找目标工具

```python
target_tool = next((x for x in agent_state.tools if x.name == tool_name), None)
if not target_tool:
    return ToolExecutionResult(func_return=f"Tool {tool_name} not found", status="error")
```

- `agent_state.tools` 是这个 agent 当前配置绑定的所有 `Tool` 对象列表（不是全局工具表，是这个 agent 实际拥有的工具集合）。
- 用生成器表达式 + `next(..., None)` 做一次线性查找，按名字匹配。这里没有做成 dict 查找（`O(1)`），说明工具数量通常不多，性能不是关键路径。
- **防御性检查**：万一 LLM 幻觉出一个不存在的工具名（模型编造了一个从没见过的函数名），这里会兜底，直接返回一个 `status="error"` 的结果，而不会往下继续走（不会尝试去实例化 executor）。注意这里的错误信息写得比较简陋（`"Tool {tool_name} not found"`），代码里那行 `# TODO: fix this error message` 也承认了这一点——没有走 `get_friendly_error_msg` 统一格式化，是个待改进点。

---

## 三、记录"工具开始执行"的 trace 事件

```python
if agent_step_span:
    start_time = get_utc_timestamp_ns()
    agent_step_span.add_event(name="tool_execution_started")
```

- 只有调用方确实传了 `agent_step_span`（说明这次 step 本身开启了 tracing）才记录，否则跳过整段 tracing 逻辑（避免空指针）。
- `start_time` 先记下来，为了后面算耗时用（注意这个耗时统计和 `AsyncTimer` 那个是**不同层级的两套计时**：`AsyncTimer` 在 `execute_tool_async` 内部只包住 `executor.execute(...)` 这一段最核心的执行时间；这里的 `start_time`/`end_time` 包住的是**从这里到 `execute_tool_async` 整个返回**的时间，范围更大一点，因为还包含了 `ToolExecutionManager` 实例化、`get_executor` 查表等开销）。

---

## 四、准备环境变量（沙箱要用的 secrets）

```python
sandbox_env_vars = {var.key: var.value or "" for var in agent_state.secrets}
```

- `agent_state.secrets` 是这个 agent 配置的一批环境变量（`AgentEnvironmentVariable` 对象列表），代码注释说明这些值是"**预先解密好**的"（`Use pre-decrypted environment variable values (populated in from_orm_async)`）——也就是说加密存储在数据库里的敏感值（比如 API key），在更早的 `agent_state.from_orm_async(...)` 阶段就已经统一解密过一次了，这里只是简单转成 `{key: value}` 的字典形式，供沙箱执行用户自定义 Python 代码时作为环境变量注入（比如用户工具里要用 `os.environ["OPENAI_API_KEY"]`）。
- `var.value or ""`：如果某个变量值是 `None`，兜底用空字符串，避免传 `None` 给沙箱环境变量导致类型错误。

---

## 五、构造 `ToolExecutionManager` 并调用 `execute_tool_async`

```python
tool_execution_manager = ToolExecutionManager(
    agent_state=agent_state, message_manager=self.message_manager, agent_manager=self.agent_manager,
    block_manager=self.block_manager, job_manager=self.job_manager, passage_manager=self.passage_manager,
    sandbox_env_vars=sandbox_env_vars, actor=self.actor,
)
log_event(name=f"start_{tool_name}_execution", attributes=tool_args)
tool_execution_result = await tool_execution_manager.execute_tool_async(
    function_name=tool_name, function_args=tool_args, tool=target_tool, step_id=step_id,
)
```

- 这里就是把你前面几轮问过的整条链路串起来的地方：`ToolExecutionManager` 每次都**重新实例化**（不复用），把当前 agent 的各种 manager（`message_manager`/`agent_manager`/`block_manager`/`job_manager`/`passage_manager`）和刚准备好的 `sandbox_env_vars`、`actor`（当前操作的身份/权限主体）一起注入进去。
- `log_event(name=f"start_{tool_name}_execution", attributes=tool_args)`：这是另一套更轻量的 trace 打点方式（`letta/otel/tracing.py` 里的 `log_event`，直接往"当前活跃 span"上加事件，不需要显式传 span 对象），把 `tool_args`（工具的实际调用参数）也记录进去，方便日后在 trace 平台上直接看到"这次调用传了什么参数"，用于调试。
- 然后调用 `execute_tool_async`（也就是前几轮我们详细拆解过的那个方法：内部会 `get_executor` 选执行器、`AsyncTimer` 计时执行、按 `return_char_limit` 裁剪结果、异常兜底成 `ToolExecutionResult`）。

---

## 六、记录"工具执行完成"的 trace 事件

```python
if agent_step_span:
    end_time = get_utc_timestamp_ns()
    agent_step_span.add_event(
        name="tool_execution_completed",
        attributes={
            "tool_name": target_tool.name,
            "duration_ms": ns_to_ms(end_time - start_time),
            "success": tool_execution_result.success_flag,
            "tool_type": target_tool.tool_type,
            "tool_id": target_tool.id,
        },
    )
log_event(name=f"finish_{tool_name}_execution", attributes=tool_execution_result.model_dump())
return tool_execution_result
```

- 跟第三步对应，在同一个 `agent_step_span` 上补一个"结束事件"，附带耗时（纳秒转毫秒 `ns_to_ms`）、是否成功（`success_flag`，一个基于 `status` 计算出来的布尔便捷属性）、工具类型、工具 id 等结构化标签——这样在 trace 可视化界面里，一个 step 的时间线上就能清楚看到"哪个工具、什么时候开始、耗时多久、成不成功"。
- 最后再用 `log_event` 把完整的 `tool_execution_result.model_dump()`（整个 `ToolExecutionResult` 对象序列化成字典，包含 `func_return`、`stdout`、`stderr`、`status` 等所有字段）打到当前 span 上，作为最详细的调试信息留档。
- 最终把 `tool_execution_result` 原样返回给调用方（`_handle_ai_response`），自己不做任何加工（裁剪、错误转换等都已经在下一层 `execute_tool_async` 里做完了）。

---

## 七、双层 trace 打点对比

| 维度 | `agent_step_span.add_event` | `log_event(...)` |
|------|---------------------------|-------------------|
| 触发条件 | 需要 `agent_step_span` 不为空 | 总是执行（自动找当前活跃 span） |
| 记录内容 | 结构化属性（tool_name, duration_ms, success, tool_type, tool_id） | 工具参数（开始）+ 完整 ToolExecutionResult（结束） |
| 可见性 | 在 step span 的时间线上显示为事件节点 | 也挂在 span 上，但更偏向调试日志 |
| 设计意图 | 给 trace 仪表盘做过滤/聚合用 | 给 debug 时排查具体参数/返回值用 |

---

## 八、这个函数在整体架构里的定位

结合前几轮的内容，可以看出这是一个清晰的**分层职责**设计：

| 层级 | 函数 | 职责 |
|---|---|---|
| 上层 | `_handle_ai_response` | 解析 LLM 输出、处理审批/拒绝、决定 continue_stepping、组装持久化消息 |
| **本层** | **`_execute_tool`** | **查找工具对象、准备沙箱环境变量、打 span 级别的粗粒度 trace（开始/结束事件+耗时）、编排调用** |
| 下层 | `ToolExecutionManager.execute_tool_async` | 选执行器(`get_executor`)、精确计时执行(`AsyncTimer`)、异常兜底、结果裁剪、打指标(counter/histogram) |
| 最底层 | 具体 `Executor.execute()` | 真正跑代码（内存编辑/沙箱/MCP/内置工具等） |

`_execute_tool` 本身不处理任何"业务逻辑"（不管审批、不管 heartbeat、不管消息持久化），它唯一的"业务判断"就是第二步的"工具是否存在"这个兜底检查，其余全是**编排 + 可观测性打点**。这也解释了代码里那句 `# TODO: This temp. Move this logic and code to executors`——作者自己也认为像"准备 sandbox_env_vars"这种逻辑理论上应该下沉到 executor 层去做，现在放在这里是历史遗留的临时安排。
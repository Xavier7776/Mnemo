---
title: 工具执行器工厂：ToolType七类映射、沙箱兜底默认与策略注入解耦设计
summary: 深入拆解 ToolExecutorFactory.get_executor 的工厂模式实现——三步逻辑（查表→兜底→实例化）、七类 ToolType 到五种 Executor 的映射表、SandboxToolExecutor 兜底默认、策略模式+依赖注入的解耦设计
project: letta
tags: [letta, tool-executor, factory-pattern, strategy-pattern, dependency-injection, source-code]
created: 2026-07-03
updated: 2026-07-03
status: completed
confidence: high
---

# 工具执行器工厂：ToolType七类映射、沙箱兜底默认与策略注入解耦设计

## 一、工厂模式的三步逻辑

**源码位置**：`letta/services/tool_executor/tool_execution_manager.py`

```python
class ToolExecutorFactory:
    _executor_map: ClassVar[Dict[ToolType, Type[ToolExecutor]]] = {
        ToolType.LETTA_CORE:             LettaCoreToolExecutor,
        ToolType.LETTA_MEMORY_CORE:      LettaCoreToolExecutor,
        ToolType.LETTA_SLEEPTIME_CORE:   LettaCoreToolExecutor,
        ToolType.LETTA_MULTI_AGENT_CORE: SandboxToolExecutor,
        ToolType.LETTA_BUILTIN:          LettaBuiltinToolExecutor,
        ToolType.LETTA_FILES_CORE:       LettaFileToolExecutor,
        ToolType.EXTERNAL_MCP:           ExternalMCPToolExecutor,
    }

    @classmethod
    def get_executor(cls, tool_type, message_manager, agent_manager,
                     block_manager, run_manager, passage_manager, actor) -> ToolExecutor:
        executor_class = cls._executor_map.get(tool_type, SandboxToolExecutor)
        return executor_class(
            message_manager=message_manager,
            agent_manager=agent_manager,
            block_manager=block_manager,
            run_manager=run_manager,
            passage_manager=passage_manager,
            actor=actor,
        )
```

### 1. 第一步：查表

用 `tool.tool_type`（一个 `ToolType` 枚举值）去 `_executor_map` 这个类级别字典里查对应的执行器**类**（不是实例）。`_executor_map` 是 `ClassVar[Dict[ToolType, Type[ToolExecutor]]]`——存的是类型本身，不是对象。

### 2. 第二步：兜底默认值

`dict.get(tool_type, SandboxToolExecutor)` 的第二个参数是 fallback。如果 `tool_type` 不在映射表里（比如 `ToolType.CUSTOM`，即用户自定义 Python 工具），自动 fallback 到 `SandboxToolExecutor`——自定义工具默认在沙箱里跑。

> [!warning] 兜底逻辑隐含的安全假设
> 未知 tool_type 一律走沙箱执行，意味着任何没有被显式注册为"内建可信"的工具，都默认被隔离。这是安全防御性的设计——宁可多一层沙箱开销，也不让未分类的代码直接在主进程里跑。

### 3. 第三步：实例化并返回

拿到类之后，用同一套依赖（各个 manager + actor）实例化出具体执行器对象。这些依赖从 `ToolExecutionManager` 自身透传下来（见 `execute_tool_async` 里的调用），本质是依赖注入——工厂不负责创建依赖，只负责把依赖传给选中的执行器。

---

## 二、七类 ToolType 到五种 Executor 的完整映射

| ToolType | Executor 类 | 行数 | 职责 |
|---|---|---|---|
| `LETTA_CORE` | `LettaCoreToolExecutor` | 1068 | 基础对话工具（`send_message`、`conversation_search`、`archival_memory_insert/search`），直接调用 `block_manager`/`agent_manager` 完成状态变更，不走沙箱 |
| `LETTA_MEMORY_CORE` | `LettaCoreToolExecutor` | ↑ | Core Memory 写入工具（`core_memory_append/replace`、`memory`、`memory_apply_patch` 等），与上面共用同一个 executor |
| `LETTA_SLEEPTIME_CORE` | `LettaCoreToolExecutor` | ↑ | Sleeptime 专用工具集，同样路由到 `LettaCoreToolExecutor` |
| `LETTA_MULTI_AGENT_CORE` | `SandboxToolExecutor` | 194 | 多智能体通信工具（`send_message_to_agent` 等），虽带 "CORE" 但走沙箱——因为涉及跨 agent 通信 |
| `LETTA_BUILTIN` | `LettaBuiltinToolExecutor` | 399 | 内置能力工具（`run_code`、`web_search`、`fetch_webpage`） |
| `LETTA_FILES_CORE` | `LettaFileToolExecutor` | 853 | 文件系统工具（`open_files`、`read_file`、`grep_files`、`semantic_search_files`） |
| `EXTERNAL_MCP` | `ExternalMCPToolExecutor` | 88 | 通过 MCP 协议连接的外部工具服务器 |
| **其他/未知（含 `CUSTOM`）** | `SandboxToolExecutor`（默认） | 194 | 用户自定义 Python 代码，在隔离沙箱环境（Modal/E2B/Local）中执行 |

> [!tip] 三个 CORE 共用一个 Executor 的原因
> `LETTA_CORE`、`LETTA_MEMORY_CORE`、`LETTA_SLEEPTIME_CORE` 三种 tool_type 都路由到 `LettaCoreToolExecutor`，因为它们的执行逻辑都在同一个 `function_map` 字典里（14 个内置工具直接映射 Python 方法）。三种 tool_type 的区分主要用于**注册阶段**（决定哪些工具出现在 agent 的 tools 列表里），而不是**执行阶段**——执行时大家共用一个 function_map。

---

## 三、为什么这么设计：策略模式 + 依赖注入

### 1. 统一抽象基类

所有执行器都继承同一个抽象基类 `ToolExecutor`（`tool_executor_base.py`，仅 46 行），构造函数签名和 `execute()` 方法签名完全一致。

```python
# 调用方代码（execute_tool_async 里）：
result = await executor.execute(
    function_name, function_args, tool, self.actor,
    self.agent_state, self.sandbox_config, self.sandbox_env_vars
)
```

调用方完全不关心底层是内存编辑、文件操作、沙箱执行还是 MCP 远程调用——一行代码统一调用。

### 2. 两件事解耦

| 关注点 | 谁负责 | 怎么做 |
|---|---|---|
| **选哪个执行器** | `ToolExecutorFactory` | 按 `tool_type` 查 `_executor_map` |
| **怎么用执行器** | `execute_tool_async` | 统一调 `executor.execute(...)` |

这是经典的策略模式 + 依赖注入组合：
- **策略模式**：`_executor_map` 是策略注册表，新增一种 tool_type 只需加一行映射
- **依赖注入**：manager 和 actor 作为依赖从外部传入，执行器本身不负责创建依赖，只负责使用

### 3. 扩展性

新增一种工具类型（比如未来加 `ToolType.LETTA_VECTOR_STORE_CORE`）只需要：
1. 写一个新的 `XxxToolExecutor` 继承 `ToolExecutor`
2. 在 `_executor_map` 里加一行 `ToolType.LETTA_VECTOR_STORE_CORE: XxxToolExecutor`

`get_executor`、`execute_tool_async`、`_execute_tool` 都不用改——开闭原则。

---

## 四、execute_tool_async 的完整调用链

```
execute_tool_async(tool, ...)
  │
  ├── 1. ToolExecutorFactory.get_executor(tool.tool_type, ...)
  │     → 查 _executor_map
  │     → 兜底 SandboxToolExecutor
  │     → 实例化（注入 managers + actor）
  │
  ├── 2. executor.execute(function_name, function_args, tool, actor, ...)
  │     → LettaCoreToolExecutor:    function_map[function_name](...)
  │     → SandboxToolExecutor:      沙箱内执行 tool.run(agent_state_copy)
  │     → LettaBuiltinToolExecutor:  内置能力调用
  │     → LettaFileToolExecutor:     文件系统操作
  │     → ExternalMCPToolExecutor:   MCP 协议远程调用
  │
  └── 3. 返回 ToolExecutionResult
```

> [!note] 依赖注入的传递链
> `execute_tool_async` 拿到的 `message_manager`、`agent_manager`、`block_manager`、`run_manager`、`passage_manager`、`actor` 这六个依赖，来自 `ToolExecutionManager` 的构造函数（在 `_execute_tool` 里实例化时传入）。这些 manager 是 Letta 的核心服务层对象，贯穿整个工具执行链路——只有 `LettaCoreToolExecutor` 真正用到了它们（直接调 manager 方法），`SandboxToolExecutor` 等虽然也收到了但不直接用，因为沙箱执行不需要访问这些 manager。

---

## 快速参考卡

| 问题 | 答案 |
|------|------|
| `get_executor` 做了什么？ | 三步：查 `_executor_map` → 未命中兜底 `SandboxToolExecutor` → 注入依赖实例化 |
| 七类 ToolType 映射到几种 Executor？ | 5 种（3 个 CORE 共用 `LettaCoreToolExecutor`，`MULTI_AGENT_CORE` 走 `SandboxToolExecutor`） |
| 未知 tool_type 默认走什么？ | `SandboxToolExecutor`（沙箱执行，安全隔离） |
| 为什么三个 CORE 共用一个 Executor？ | 执行逻辑在同一个 `function_map` 里，tool_type 区分主要用于注册阶段 |
| `MULTI_AGENT_CORE` 为什么走沙箱？ | 跨 agent 通信需要访问其他 agent 状态，不能像 Core Memory 那样直接进程内操作 |
| 工厂模式和调用方怎么解耦的？ | 策略模式（`_executor_map` 注册表）+ 依赖注入（manager/actor 外部传入）+ 统一基类（`execute()` 签名一致） |
| 新增一种 tool_type 要改什么？ | 写新 Executor + 加一行映射，`get_executor` 和 `execute_tool_async` 不用改 |

---

## 踩坑清单

1. **`_executor_map` 存的是类不是实例**：`ClassVar[Dict[ToolType, Type[ToolExecutor]]]` 类型标注明确说了是 `Type[ToolExecutor]`。每次 `get_executor` 都会 `new` 一个新实例——不是单例缓存。如果 executor 有昂贵的初始化逻辑（比如建连接池），每次工具调用都会重复初始化。目前各 executor 的构造函数只是存 manager 引用，开销可忽略。

2. **`MULTI_AGENT_CORE` 是唯一带 "CORE" 但走沙箱的类型**：容易误以为所有 `*_CORE` 都走 `LettaCoreToolExecutor`。实际上 `LETTA_MULTI_AGENT_CORE` 映射到 `SandboxToolExecutor`——因为多 agent 通信工具需要访问其他 agent 的状态，涉及跨 agent 通信，不能像 Core Memory 工具那样直接在进程内操作。

3. **`SandboxToolExecutor` 同时承担两个角色**：既是 `MULTI_AGENT_CORE` 的显式执行器，又是所有未知 tool_type 的兜底默认。如果未来新增一种 tool_type 但忘了在 `_executor_map` 注册，它会静默走沙箱——不会报错，但可能不是预期行为。

4. **`ExternalMCPToolExecutor` 只有 88 行**：是所有 executor 里最轻的，因为 MCP 协议本身做了序列化/网络通信的封装，executor 只需要转发请求。对比 `LettaCoreToolExecutor` 的 1068 行，差距悬殊——核心工具的复杂度在于 `function_map` 里 14 个方法各自的状态管理逻辑。

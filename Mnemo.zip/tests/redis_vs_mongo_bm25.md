# Redis BM25 vs MongoDB 全表扫描 BM25 延迟对比

> 测试时间: 2026-07-16 17:23:14  
> 数据集: 10 条查询  
> Redis 可用: 是

## 对比结果

| 指标 | Redis 倒排索引 | MongoDB 全表扫描 | 差异 |
| --- | ---: | ---: | ---: |
| avg 延迟 (ms) | 176.2 | 780.8 | -604.5 |
| p50 延迟 (ms) | 112.2 | 255.8 | -143.6 |
| p95 延迟 (ms) | 455.1 | 2423.2 | -1968.0 |
| min 延迟 (ms) | 57.8 | 195.8 | — |
| max 延迟 (ms) | 455.1 | 2423.2 | — |
| 命中率 | 100.0% | 100.0% | — |

## 加速比

- Redis 相对 MongoDB 加速: **4.43x**

## 说明

- **Redis 路径**：`_keyword_search` → Redis 倒排索引 HGETALL + BM25 打分 + MongoDB 回查 chunk 文本
- **MongoDB 路径**：`_keyword_search_mongo` → MongoDB `$or $regex` 全表扫描 + jieba 分词 + BM25 打分
- 两条路径使用完全相同的 BM25 算法（Okapi BM25, k1=1.5, b=0.75）
- 命中率应相同（同一数据集同一算法），差异仅在于检索速度


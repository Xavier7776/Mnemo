# RAG 检索质量指标测试报告

> 测试时间: 2026-07-16 17:17:38  
> 测试环境: Windows, Python 3.10  
> 数据集: `eval/retrieval_dataset.auto.json`  
> 集合名: `advanced_rag_knowledge`

## 一、检索召回率/准确率（三路混合 + RRF + CrossEncoder 重排）

| 指标 | 值 |
| --- | ---: |
| recall@1 | 1.0000 |
| precision@1 | 1.0000 |
| ndcg@1 | 1.0000 |
| recall@3 | 1.0000 |
| precision@3 | 0.3333 |
| ndcg@3 | 1.0000 |
| recall@5 | 1.0000 |
| precision@5 | 0.2000 |
| ndcg@5 | 1.0000 |
| recall@10 | 1.0000 |
| precision@10 | 0.1000 |
| ndcg@10 | 1.0000 |
| mrr | 1.0000 |
| avg_latency | 21371.8 ms |
| p50_latency | 20952.5 ms |
| p95_latency | 22932.2 ms |

## 二、三路并行检索 vs 单路检索的延迟对比

| 策略 | avg(ms) | p50(ms) | p95(ms) | recall@5 | mrr |
| --- | ---: | ---: | ---: | ---: | ---: |
| hybrid_auto | 7698.6 | 7952.6 | 8552.8 | 1.0000 | 0.9000 |
| vector_only | 73.2 | 71.5 | 83.2 | 0.0000 | 0.0000 |
| keyword_only | 165.6 | 106.6 | 423.8 | 1.0000 | 0.9000 |
| graph_only | 7239.1 | 7058.0 | 8502.4 | 0.0000 | 0.0000 |

## 三、RRF 融合 vs 无融合的效果对比

| 方式 | recall@5 | precision@5 | mrr | ndcg@5 |
| --- | ---: | ---: | ---: | ---: |
| rrf_fusion | 1.0000 | 0.2000 | 0.9000 | 0.9262 |
| no_fusion | 1.0000 | 0.2000 | 0.9000 | 0.9262 |

## 四、CrossEncoder 重排 vs 无重排的准确率提升

| 方式 | recall@5 | precision@5 | mrr | ndcg@5 | avg(ms) |
| --- | ---: | ---: | ---: | ---: | ---: |
| no_rerank | 1.0000 | 0.2000 | 0.9000 | 0.9262 | 7276.9 |
| rerank | 1.0000 | 0.2000 | 1.0000 | 1.0000 | 21424.7 |

## 五、Function Calling vs regex 解析的延迟对比

- 迭代次数: 2000

| 方式 | 平均延迟 | 总耗时 |
| --- | ---: | ---: |
| regex 解析 | 4.95 μs/次 | 9.89 ms |
| FC 聚合 | 12.98 μs/次 | 25.96 ms |

- 比率 (FC/regex): 2.62x

> 端到端 API 延迟未测试（后端未运行）

